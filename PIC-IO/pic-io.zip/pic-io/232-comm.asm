
; CC5X Version 3.2A, Copyright (c) B Knudsen Data
; C compiler for the PICmicro family
; ************  13. Nov 2004  11:58  *************

	processor  16F628
	radix  DEC

INDF        EQU   0x00
TMR0        EQU   0x01
PCL         EQU   0x02
STATUS      EQU   0x03
FSR         EQU   0x04
PORTA       EQU   0x05
TRISA       EQU   0x85
PORTB       EQU   0x06
TRISB       EQU   0x86
PCLATH      EQU   0x0A
Carry       EQU   0
Zero_       EQU   2
RP0         EQU   5
RP1         EQU   6
IRP         EQU   7
GIE         EQU   7
OPTION_REG  EQU   0x81
TXREG       EQU   0x19
RCREG       EQU   0x1A
SPBRG       EQU   0x99
RB2         EQU   2
RB5         EQU   5
RB7         EQU   7
PEIE        EQU   6
TXIF        EQU   4
RCIF        EQU   5
CREN        EQU   4
SPEN        EQU   7
TXIE        EQU   4
RCIE        EQU   5
BRGH        EQU   2
SYNC        EQU   4
TXEN        EQU   5
print_it    EQU   0
data_in     EQU   0x33
data_last1  EQU   0x34
data_last2  EQU   0x35
data_last3  EQU   0x36
mem_spot    EQU   0x3F
svrWREG     EQU   0x70
svrSTATUS   EQU   0x20
sv_FSR      EQU   0x21
millisec    EQU   0x7F
next        EQU   0x7F
n           EQU   0x7F
i           EQU   0x7F
x           EQU   0x7F
i_2         EQU   0x7F
want_ints   EQU   0
want_ints_2 EQU   0
nate        EQU   0x2F
x_2         EQU   0x2F
nate_2      EQU   0x26
my_byte     EQU   0x27
i_3         EQU   0x28
k           EQU   0x29
m           EQU   0x2A
high_byte   EQU   0x2B
low_byte    EQU   0x2C
y           EQU   0x2D
z           EQU   0x2E
C1cnt       EQU   0x2F
C2tmp       EQU   0x30
C3rem       EQU   0x31
C4cnt       EQU   0x2F
C5tmp       EQU   0x30
C6cnt       EQU   0x2F
C7tmp       EQU   0x30
C8rem       EQU   0x31
C9cnt       EQU   0x2F
C10tmp      EQU   0x30
i_4         EQU   0x7F
nate_3      EQU   0x7F
l           EQU   0x7F
nate_4      EQU   0x7F
my_byte_2   EQU   0x7F
i_5         EQU   0x7F
k_2         EQU   0x7F
m_2         EQU   0x7F
high_byte_2 EQU   0x7F
low_byte_2  EQU   0x7F
y_2         EQU   0x7F
z_2         EQU   0x7F
C11cnt      EQU   0x7F
C12tmp      EQU   0x7F
C13rem      EQU   0x7F
C14cnt      EQU   0x7F
C15tmp      EQU   0x7F
C16cnt      EQU   0x7F
C17tmp      EQU   0x7F
C18rem      EQU   0x7F
C19cnt      EQU   0x7F
C20tmp      EQU   0x7F
j           EQU   0x7F
nate_5      EQU   0x7F
count_2     EQU   0x7F
button_monitor EQU   0x23
aux         EQU   0x25
ci          EQU   0x2F

	GOTO main

  ; FILE C:\cc5x\232-comm.c
			;/*
			;    7-23-03
			;    Copyright Spark Fun Electronics� 2003
			;    
			;    Using the PIC and the RS232 Interface
			;
			;    Use Hyperterminal provided by Windows or some equivalent serial communications
			;    software. Set the correct com port to 9600 Baud 8-N-1.
			;    
			;    ==============================================================
			;
			;    Using hyperterminal, any button that the user presses is transmitted to the PIC.
			;    The PIC then responds with both the HEX value and the ASCII representation of the 
			;    letter that was pressed.
			;    
			;    All keys are stored in memory, and upon receiving a 'Z' key press the last 64 key presses
			;    will be dumped onto the hyperterminal screen.
			;    
			;*/
			;#define HS_Osc
			;#define Serial_Out_BB   RB2
			;#define Serial_In_BB   RB7
			;#define Baud_9600
			;
			;#include "c:\cc5x\16F628.h" //Compiler specific header file
			;#include "c:\cc5x\int16CXX.H" //General Interrupts header file
			;
			;#pragma origin 4 //Manditory when interrupts are used
	ORG 0x0004
			;
			;#define TRUE        1
			;#define FALSE       0
			;
			;bit print_it;
			;bit start_record;
			;
			;uns8 data_in;
			;uns8 data_last1;
			;uns8 data_last2;
			;uns8 data_last3;
			;
			;uns8 memory_array[8];
			;uns8 mem_spot;
			;
			;interrupt serverX(void)
			;{
serverX
			;    int_save_registers
	MOVWF svrWREG
	SWAPF STATUS,W
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF svrSTATUS
			;    char sv_FSR = FSR;  // save FSR if required
	MOVF  FSR,W
	MOVWF sv_FSR
			;
			;    if(RCIF) //UART Recieve Interrupt
	BTFSS 0x0C,RCIF
	GOTO  m001
			;    {
			;        data_in = RCREG;
	MOVF  RCREG,W
	MOVWF data_in
			;
			;        print_it = TRUE;
	BSF   0x32,print_it
			;            
			;        //No clearing RCIF, must clear RCREG        
			;        RCREG = 0;
	CLRF  RCREG
			;    }
			;
			;    FSR = sv_FSR;               // restore FSR if saved
m001	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  sv_FSR,W
	MOVWF FSR
			;    int_restore_registers 
	SWAPF svrSTATUS,W
	MOVWF STATUS
	SWAPF svrWREG,1
	SWAPF svrWREG,W
			;}
	RETFIE

  ; FILE c:\cc5x\Delay.c
			;/*
			;  DELAYS AND TIMING
			;  =================
			;
			;  Delays are frequently used. There are various
			;  ways to generate them:
			;     1. Instruction cycle counting
			;     2. Using the TMR0 timer
			;     3. Watchdog timeout for low power consumption
			;     4. Using variables achieves longer delays
			;*/
			;
			;
			;void delay_ms( uns16 millisec)
			;// Delays a multiple of 1 milliseconds at 4 MHz
			;// using the TMR0 timer
			;{
_const1
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF ci
	CLRF  PCLATH
	MOVF  ci,W
	ANDLW .3
	ADDWF PCL,1
	RETLW .37
	RETLW .117
	RETLW .0
	RETLW .0
_const2
	RETLW .0
delay_ms
			;    char next = 0;
	CLRF  next
			;
			;    OPTION = 2; // prescaler divide TMR0 rate by 8
	MOVLW .2
	BSF   0x03,RP0
	BCF   0x03,RP1
	MOVWF OPTION_REG
			;    TMR0 = 2;  // deduct 2*8 fixed instruction cycles delay
	MOVLW .2
	BCF   0x03,RP0
	MOVWF TMR0
			;    do  {
			;        next += 125;
m002	MOVLW .125
	ADDWF next,1
			;        clrwdt();  // needed only if watchdog is enabled
	CLRWDT
			;        while (TMR0 != next)   // 125 * 8 = 1000 (= 1 ms)
m003	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  TMR0,W
	XORWF next,W
	BTFSS 0x03,Zero_
			;            ;
	GOTO  m003
			;    } while ( -- millisec != 0);
	DECF  millisec,1
	INCF  millisec,W
	BTFSC 0x03,Zero_
	DECF  millisec+1,1
	MOVF  millisec,W
	IORWF millisec+1,W
	BTFSS 0x03,Zero_
	GOTO  m002
			;}
	RETURN
			;
			;
			;void delay10( char n)
			;/*
			;  Delays a multiple of 10 milliseconds using the TMR0 timer
			;  Clock : 4 MHz   => period T = 0.25 microseconds
			;  1 IS = 1 Instruction Cycle = 1 microsecond
			;  error: 0.16 percent
			;*/
			;{
delay10
	MOVWF n
			;    char i;
			;
			;    OPTION = 7;
	MOVLW .7
	BSF   0x03,RP0
	BCF   0x03,RP1
	MOVWF OPTION_REG
			;    do  {
			;        clrwdt();  // only if watchdog enabled
m004	CLRWDT
			;        i = TMR0 + 39; /* 256 microsec * 39 = 10 ms */
	MOVLW .39
	BCF   0x03,RP0
	BCF   0x03,RP1
	ADDWF TMR0,W
	MOVWF i
			;        while ( i != TMR0)
m005	MOVF  i,W
	BCF   0x03,RP0
	BCF   0x03,RP1
	XORWF TMR0,W
	BTFSS 0x03,Zero_
			;            ;
	GOTO  m005
			;    } while ( --n > 0);
	DECFSZ n,1
	GOTO  m004
			;}
	RETURN
			;
			;
			;void _delay10( char x)
			;/*
			;  Delays a multiple of 10 milliseconds
			;   using instruction cycle counting
			;  Clock : 32768 Hz   => period T = 30.518 microseconds
			;  1 Instruction Cycle = 1 IS = 4 * T = 122 microseconds
			;  10 ms = 82 IS (81.92) =>  error: 0.1 percent
			;*/
			;{
_delay10
	MOVWF x
			;    do  {
			;        char i = 26;            /* 2 IS */
m006	MOVLW .26
	MOVWF i_2
			;        do ; while ( --i > 0);  /* 26 * 3 - 1 = 77 IS */
m007	DECFSZ i_2,1
	GOTO  m007
			;    } while ( --x > 0);         /* 3 IS */
	DECFSZ x,1
	GOTO  m006
			;}
	RETURN

  ; FILE c:\cc5x\stdio.c
			;/*
			;    5/21/02
			;    Nathan Seidle
			;    nathan.seidle@colorado.edu
			;    
			;    Serial Out Started on 5-21
			;    rs_out Perfected on 5-24
			;    
			;    1Wire Serial Comm works with 4MHz Xtal
			;    Connect Serial_Out to Pin2 on DB9 Serial Connector
			;    Connect Pin5 on DB9 Connector to Signal Ground
			;    9600 Baud 8-N-1
			;    
			;    5-21 My first real C and Pic program.
			;    5-24 Attempting 20MHz implementation
			;    5-25 20MHz works
			;    5-25 Serial In works at 4MHz
			;    5-25 Passing Strings 9:20
			;    5-25 Option Selection 9:45
			;
			;    6-9  'Stdio.c' created. Printf working with %d and %h
			;    7-20 Added a longer delay after rs_out
			;         Trying to get 20MHz on the 16F873 - I think the XTal is bad.
			;         20MHz also needs 5V Vdd. Something I dont have.
			;    2-9-03 Overhauled the 4MHz timing. Serial out works very well now.
			;    
			;    6-16-03 Discovered how to pass string in cc5x
			;        void test(const char *str);
			;        test("zbcdefghij"); TXREG = str[1];
			;        
			;        Moved to hardware UART. Old STDIO will be in goodworks.
			;        
			;        Works great! Even got the special print characters (\n, \r, \0) to work.
			;        
			;
			;*/
			;
			;//Clock is defined in Delay.c!!!
			;
			;int count;
			;
			;//Setup the hardware UART TX module
			;void enable_uart_TX(bit want_ints)
			;{
enable_uart_TX
			;
			;#ifdef Crazy_Osc
			;    #ifdef Baud_9600
			;    SPBRG = 32; //20MHz for 9600 Baud
			;    #endif
			;#endif
			;
			;#ifdef HS_Osc
			;    #ifdef Baud_9600
			;    SPBRG = 32; //20MHz for 9600 Baud
	MOVLW .32
	BSF   0x03,RP0
	BCF   0x03,RP1
	MOVWF SPBRG
			;    #endif
			;
			;    #ifdef Baud_4800
			;    SPBRG = 64; //20MHz for 4800 Baud
			;    #endif
			;#endif
			;
			;
			;    BRGH = 0; //Normal speed UART
	BCF   0x98,BRGH
			;
			;    SYNC = 0;
	BCF   0x98,SYNC
			;    SPEN = 1;
	BCF   0x03,RP0
	BSF   0x18,SPEN
			;
			;    if(want_ints) //Check if we want to turn on interrupts
	BTFSS 0x26,want_ints
	GOTO  m008
			;    {
			;        TXIE = 1;
	BSF   0x03,RP0
	BSF   0x8C,TXIE
			;        PEIE = 1;
	BSF   0x0B,PEIE
			;        GIE = 1;
	BSF   0x0B,GIE
			;    }
			;
			;    TXEN = 1; //Enable transmission
m008	BSF   0x03,RP0
	BCF   0x03,RP1
	BSF   0x98,TXEN
			;}    
	RETURN
			;
			;//Setup the hardware UART RX module
			;void enable_uart_RX(bit want_ints)
			;{
enable_uart_RX
			;
			;#ifdef HS_Osc
			;    #ifdef Baud_9600
			;    SPBRG = 32; //20MHz for 9600 Baud
	MOVLW .32
	BSF   0x03,RP0
	BCF   0x03,RP1
	MOVWF SPBRG
			;    #endif
			;
			;    #ifdef Baud_4800
			;    SPBRG = 64; //20MHz for 4800 Baud
			;    #endif
			;#endif
			;
			;    BRGH = 0; //Normal speed UART
	BCF   0x98,BRGH
			;
			;    SYNC = 0;
	BCF   0x98,SYNC
			;    SPEN = 1;
	BCF   0x03,RP0
	BSF   0x18,SPEN
			;
			;    CREN = 1;
	BSF   0x18,CREN
			;
			;    //WREN = 1;
			;
			;    if(want_ints) //Check if we want to turn on interrupts
	BTFSS 0x26,want_ints_2
	GOTO  m009
			;    {
			;        RCIE = 1;
	BSF   0x03,RP0
	BSF   0x8C,RCIE
			;        PEIE = 1;
	BSF   0x0B,PEIE
			;        GIE = 1;
	BSF   0x0B,GIE
			;    }
			;
			;}    
m009	RETURN
			;
			;//Sends nate to the Transmit Register
			;void rs_out(uns8 nate)
			;{
rs_out
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF nate
			;    //TXEN = 1; //Enable transmission
			;    TXREG = nate;
	MOVF  nate,W
	MOVWF TXREG
			;    while(TXIF == 0);
m010	BCF   0x03,RP0
	BCF   0x03,RP1
	BTFSS 0x0C,TXIF
	GOTO  m010
			;
			;    //TXREG = 0;
			;    //TXEN = 0; //Disable transmission
			;}
	RETURN
			;
			;
			;//Returns ASCII Decimal and Hex values
			;uns8 bin2Hex(char x)
			;{
bin2Hex
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF x_2
			;   skip(x);
	CLRF  PCLATH
	MOVF  x_2,W
	ADDWF PCL,1
			;   #pragma return[16] = "0123456789ABCDEF"
	RETLW .48
	RETLW .49
	RETLW .50
	RETLW .51
	RETLW .52
	RETLW .53
	RETLW .54
	RETLW .55
	RETLW .56
	RETLW .57
	RETLW .65
	RETLW .66
	RETLW .67
	RETLW .68
	RETLW .69
	RETLW .70
			;}
			;
			;//Prints a string including variables
			;void printf(const char *nate, uns8 my_byte)
			;{
printf
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF my_byte
			;  
			;//#pragma rambank 1
			;    uns8 i, k, m;
			;    uns8 high_byte = 0, low_byte = 0;
	CLRF  high_byte
	CLRF  low_byte
			;    uns8 y, z;
			;    
			;    for(i = 0 ; ; i++)
	CLRF  i_3
			;    {
			;        k = nate[i];
m011	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  i_3,W
	ADDWF nate_2,W
	CALL  _const1
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF k
			;
			;        if (k == '\0') 
	MOVF  k,1
	BTFSC 0x03,Zero_
			;            break;
	GOTO  m033
			;
			;        else if (k == '%') //Print var
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .37
	BTFSS 0x03,Zero_
	GOTO  m031
			;        {
			;            i++;
	INCF  i_3,1
			;            k = nate[i];
	MOVF  i_3,W
	ADDWF nate_2,W
	CALL  _const1
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF k
			;
			;            if (k == '\0') 
	MOVF  k,1
	BTFSC 0x03,Zero_
			;                break;
	GOTO  m033
			;            else if (k == '\\') //Print special characters
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .92
	BTFSS 0x03,Zero_
	GOTO  m012
			;            {
			;                i++;
	INCF  i_3,1
			;                k = nate[i];
	MOVF  i_3,W
	ADDWF nate_2,W
	CALL  _const1
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVWF k
			;                
			;                rs_out(k);
	MOVF  k,W
	CALL  rs_out
			;                
			;
			;            } //End Special Characters
			;            else if (k == 'b') //Print Binary
	GOTO  m032
m012	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .98
	BTFSS 0x03,Zero_
	GOTO  m017
			;            {
			;                for( m = 0 ; m < 8 ; m++ )
	CLRF  m
m013	MOVLW .8
	BCF   0x03,RP0
	BCF   0x03,RP1
	SUBWF m,W
	BTFSC 0x03,Carry
	GOTO  m032
			;                {
			;                    if (my_byte.7 == 1) rs_out('1');
	BTFSS my_byte,7
	GOTO  m014
	MOVLW .49
	CALL  rs_out
			;                    if (my_byte.7 == 0) rs_out('0');
m014	BCF   0x03,RP0
	BCF   0x03,RP1
	BTFSC my_byte,7
	GOTO  m015
	MOVLW .48
	CALL  rs_out
			;                    if (m == 3) rs_out(' ');
m015	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  m,W
	XORLW .3
	BTFSS 0x03,Zero_
	GOTO  m016
	MOVLW .32
	CALL  rs_out
			;                    
			;                    my_byte = my_byte << 1;
m016	BCF   0x03,Carry
	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   my_byte,1
			;                }
	INCF  m,1
	GOTO  m013
			;            } //End Binary               
			;            else if (k == 'd') //Print Decimal
m017	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .100
	BTFSS 0x03,Zero_
	GOTO  m028
			;            {
			;                /*if (my_byte.7 == 1)
			;                {
			;                    rs_out('-');
			;                    my_byte.7 = 0;
			;                }*/
			;                
			;                z = my_byte;
	MOVF  my_byte,W
	MOVWF z
			;                
			;                y = z / 100;
	MOVF  z,W
	MOVWF C2tmp
	CLRF  C3rem
	MOVLW .8
	MOVWF C1cnt
m018	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   C2tmp,1
	RLF   C3rem,1
	MOVLW .100
	SUBWF C3rem,W
	BTFSS 0x03,Carry
	GOTO  m019
	MOVLW .100
	BCF   0x03,RP0
	BCF   0x03,RP1
	SUBWF C3rem,1
	BSF   0x03,Carry
m019	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   y,1
	DECFSZ C1cnt,1
	GOTO  m018
			;                z = z % 100;
	MOVF  z,W
	MOVWF C5tmp
	CLRF  z
	MOVLW .8
	MOVWF C4cnt
m020	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   C5tmp,1
	RLF   z,1
	MOVLW .100
	SUBWF z,W
	BTFSS 0x03,Carry
	GOTO  m021
	MOVLW .100
	BCF   0x03,RP0
	BCF   0x03,RP1
	SUBWF z,1
m021	BCF   0x03,RP0
	BCF   0x03,RP1
	DECFSZ C4cnt,1
	GOTO  m020
			;                if (y != 0)
	MOVF  y,1
	BTFSC 0x03,Zero_
	GOTO  m022
			;                    rs_out(bin2Hex(y)); //Print 100s
	MOVF  y,W
	CALL  bin2Hex
	CALL  rs_out
			;            
			;                y = z / 10;
m022	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  z,W
	MOVWF C7tmp
	CLRF  C8rem
	MOVLW .8
	MOVWF C6cnt
m023	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   C7tmp,1
	RLF   C8rem,1
	MOVLW .10
	SUBWF C8rem,W
	BTFSS 0x03,Carry
	GOTO  m024
	MOVLW .10
	BCF   0x03,RP0
	BCF   0x03,RP1
	SUBWF C8rem,1
	BSF   0x03,Carry
m024	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   y,1
	DECFSZ C6cnt,1
	GOTO  m023
			;                z = z % 10;
	MOVF  z,W
	MOVWF C10tmp
	CLRF  z
	MOVLW .8
	MOVWF C9cnt
m025	BCF   0x03,RP0
	BCF   0x03,RP1
	RLF   C10tmp,1
	RLF   z,1
	MOVLW .10
	SUBWF z,W
	BTFSS 0x03,Carry
	GOTO  m026
	MOVLW .10
	BCF   0x03,RP0
	BCF   0x03,RP1
	SUBWF z,1
m026	BCF   0x03,RP0
	BCF   0x03,RP1
	DECFSZ C9cnt,1
	GOTO  m025
			;                if (y != 0)
	MOVF  y,1
	BTFSC 0x03,Zero_
	GOTO  m027
			;                    rs_out(bin2Hex(y)); //Print 10s
	MOVF  y,W
	CALL  bin2Hex
	CALL  rs_out
			;            
			;                rs_out(bin2Hex(z)); //Print 1s 
m027	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  z,W
	CALL  bin2Hex
	CALL  rs_out
			;            } //End Decimal
			;            else if (k == 'h') //Print Hex
	GOTO  m032
m028	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .104
	BTFSS 0x03,Zero_
	GOTO  m029
			;            {
			;                high_byte.3 = my_byte.7;
	BCF   high_byte,3
	BTFSC my_byte,7
	BSF   high_byte,3
			;                high_byte.2 = my_byte.6;
	BCF   high_byte,2
	BTFSC my_byte,6
	BSF   high_byte,2
			;                high_byte.1 = my_byte.5;
	BCF   high_byte,1
	BTFSC my_byte,5
	BSF   high_byte,1
			;                high_byte.0 = my_byte.4;
	BCF   high_byte,0
	BTFSC my_byte,4
	BSF   high_byte,0
			;            
			;                low_byte.3 = my_byte.3;
	BCF   low_byte,3
	BTFSC my_byte,3
	BSF   low_byte,3
			;                low_byte.2 = my_byte.2;
	BCF   low_byte,2
	BTFSC my_byte,2
	BSF   low_byte,2
			;                low_byte.1 = my_byte.1;
	BCF   low_byte,1
	BTFSC my_byte,1
	BSF   low_byte,1
			;                low_byte.0 = my_byte.0;
	BCF   low_byte,0
	BTFSC my_byte,0
	BSF   low_byte,0
			;        
			;                rs_out('0');
	MOVLW .48
	CALL  rs_out
			;                rs_out('x');
	MOVLW .120
	CALL  rs_out
			;            
			;                rs_out(bin2Hex(high_byte));
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  high_byte,W
	CALL  bin2Hex
	CALL  rs_out
			;                rs_out(bin2Hex(low_byte));
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  low_byte,W
	CALL  bin2Hex
	CALL  rs_out
			;            } //End Hex
			;            else if (k == 'f') //Print Float
	GOTO  m032
m029	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .102
	BTFSS 0x03,Zero_
	GOTO  m030
			;            {
			;                rs_out('!');
	MOVLW .33
	CALL  rs_out
			;            } //End Float
			;            else if (k == 'u') //Print Direct Character
	GOTO  m032
m030	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	XORLW .117
	BTFSS 0x03,Zero_
	GOTO  m032
			;            {
			;                //All ascii characters below 20 are special and screwy characters
			;                if(my_byte > 20) rs_out(my_byte);
	MOVLW .21
	SUBWF my_byte,W
	BTFSS 0x03,Carry
	GOTO  m032
	MOVF  my_byte,W
	CALL  rs_out
			;            } //End Direct
			;                        
			;        } //End Special Chars           
			;
			;        else
	GOTO  m032
			;            rs_out(k);
m031	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  k,W
	CALL  rs_out
			;    }    
m032	BCF   0x03,RP0
	BCF   0x03,RP1
	INCF  i_3,1
	GOTO  m011
			;}
m033	RETURN
			;
			;
			;//Bit banging functions for direct connect from pic to serial port comm
			;//No MAX232 chip required - dirty, but it works
			;//==================================================
			;void rs_wait(void)
			;{
rs_wait
			;
			;#ifdef Clock_4MHz
			;    int i;
			;    //for(i = 0 ; i < count ; i++);
			;    for(i = 0 ; i < 6 ; i++);
			;#endif
			;
			;#ifdef HS_Osc
			;    int i;
			;    //for(i = 0 ; i < count ; i++);
			;    for(i = 0 ; i < 36 ; i++);
	CLRF  i_4
m034	BTFSC i_4,7
	GOTO  m035
	MOVLW .36
	SUBWF i_4,W
	BTFSC 0x03,Carry
	GOTO  m036
m035	INCF  i_4,1
	GOTO  m034
			;#endif
			;    
			;}
m036	RETURN
			;
			;//Sends nate out at 9600 Baud
			;void rs_out_bb(uns8 nate)
			;{
rs_out_bb
	MOVWF nate_3
			;#ifdef Clock_4MHz
			;#pragma rambank 1
			;    int l;
			;
			;    Serial_Out_BB = 1;
			;    delay_us(9);
			;    //rs_wait();
			;    nop();
			;    nop();
			;    nop();
			;
			;    for(l = 0 ; l < 8 ; l++)
			;    {
			;        Serial_Out_BB = !nate.0;
			;        nate = rr(nate);
			;        delay_us(9);
			;        //rs_wait();
			;    }
			;
			;    Serial_Out_BB = 0;
			;    //rs_wait();
			;    
			;    //6-20-02 Needed a long wait time. Stuff was getting messed up
			;    delay_us(10);
			;    //delay_ms(1);
			;   
			;#endif
			;
			;#ifdef HS_Osc
			;#pragma rambank 0
			;    int l;
			;
			;    Serial_Out_BB = 1;
	BCF   0x03,RP0
	BCF   0x03,RP1
	BSF   0x06,RB2
			;    rs_wait();
	CALL  rs_wait
			;
			;    for(l = 0 ; l < 8 ; l++)
	CLRF  l
m037	BTFSC l,7
	GOTO  m038
	MOVLW .8
	SUBWF l,W
	BTFSC 0x03,Carry
	GOTO  m039
			;    {
			;        Serial_Out_BB = !nate.0;
m038	BCF   0x03,RP0
	BCF   0x03,RP1
	BTFSS nate_3,0
	BSF   0x06,RB2
	BTFSC nate_3,0
	BCF   0x06,RB2
			;        nate = rr(nate);
	RRF   nate_3,1
			;        rs_wait();
	CALL  rs_wait
			;    }
	INCF  l,1
	GOTO  m037
			;
			;    Serial_Out_BB = 0;
m039	BCF   0x03,RP0
	BCF   0x03,RP1
	BCF   0x06,RB2
			;    //rs_wait();
			;    
			;    //6-20-02 Needed a long wait time. Stuff was getting messed up
			;    delay_ms(1);
	MOVLW .1
	MOVWF millisec
	CLRF  millisec+1
	GOTO  delay_ms
			;#endif
			;
			;}
			;
			;//Prints a string including variables
			;void printf_bb(const char *nate, uns8 my_byte)
			;{
printf_bb
	MOVWF my_byte_2
			;    //Display byte
			;  
			;#pragma rambank 0
			;    uns8 i, k, m;
			;    uns8 high_byte = 0, low_byte = 0;
	CLRF  high_byte_2
	CLRF  low_byte_2
			;    uns8 y, z;
			;    
			;    for(i = 0 ; ; i++)
	CLRF  i_5
			;    {
			;        k = nate[i];
m040	MOVF  i_5,W
	ADDWF nate_4,W
	CALL  _const2
	MOVWF k_2
			;
			;        if (k == '\0') 
	MOVF  k_2,1
	BTFSC 0x03,Zero_
			;            break;
	GOTO  m061
			;
			;        else if (k == '%') //Print var
	MOVF  k_2,W
	XORLW .37
	BTFSS 0x03,Zero_
	GOTO  m059
			;        {
			;            i++;
	INCF  i_5,1
			;            k = nate[i];
	MOVF  i_5,W
	ADDWF nate_4,W
	CALL  _const2
	MOVWF k_2
			;
			;            if (k == '\0') 
	MOVF  k_2,1
	BTFSC 0x03,Zero_
			;                break;
	GOTO  m061
			;            else if (k == 'b') //Print Binary
	MOVF  k_2,W
	XORLW .98
	BTFSS 0x03,Zero_
	GOTO  m045
			;            {
			;                for( m = 0 ; m < 8 ; m++ )
	CLRF  m_2
m041	MOVLW .8
	SUBWF m_2,W
	BTFSC 0x03,Carry
	GOTO  m060
			;                {
			;                    if (my_byte.7 == 1) rs_out_bb('1');
	BTFSS my_byte_2,7
	GOTO  m042
	MOVLW .49
	CALL  rs_out_bb
			;                    if (my_byte.7 == 0) rs_out_bb('0');
m042	BTFSC my_byte_2,7
	GOTO  m043
	MOVLW .48
	CALL  rs_out_bb
			;                    
			;                    if (m == 3) rs_out_bb(' ');
m043	MOVF  m_2,W
	XORLW .3
	BTFSS 0x03,Zero_
	GOTO  m044
	MOVLW .32
	CALL  rs_out_bb
			;                    
			;                    my_byte = my_byte << 1;
m044	BCF   0x03,Carry
	RLF   my_byte_2,1
			;                }
	INCF  m_2,1
	GOTO  m041
			;            } //End Binary               
			;            else if (k == 'd') //Print Decimal
m045	MOVF  k_2,W
	XORLW .100
	BTFSS 0x03,Zero_
	GOTO  m056
			;            {
			;                /*if (my_byte.7 == 1)
			;                {
			;                    rs_out_bb('-');
			;                    my_byte.7 = 0;
			;                }*/
			;                
			;                z = my_byte;
	MOVF  my_byte_2,W
	MOVWF z_2
			;                
			;                y = z / 100;
	MOVF  z_2,W
	MOVWF C12tmp
	CLRF  C13rem
	MOVLW .8
	MOVWF C11cnt
m046	RLF   C12tmp,1
	RLF   C13rem,1
	MOVLW .100
	SUBWF C13rem,W
	BTFSS 0x03,Carry
	GOTO  m047
	MOVLW .100
	SUBWF C13rem,1
	BSF   0x03,Carry
m047	RLF   y_2,1
	DECFSZ C11cnt,1
	GOTO  m046
			;                z = z % 100;
	MOVF  z_2,W
	MOVWF C15tmp
	CLRF  z_2
	MOVLW .8
	MOVWF C14cnt
m048	RLF   C15tmp,1
	RLF   z_2,1
	MOVLW .100
	SUBWF z_2,W
	BTFSS 0x03,Carry
	GOTO  m049
	MOVLW .100
	SUBWF z_2,1
m049	DECFSZ C14cnt,1
	GOTO  m048
			;                if (y != 0)
	MOVF  y_2,1
	BTFSC 0x03,Zero_
	GOTO  m050
			;                    rs_out_bb(bin2Hex(y)); //Print 100s
	MOVF  y_2,W
	CALL  bin2Hex
	CALL  rs_out_bb
			;            
			;                y = z / 10;
m050	MOVF  z_2,W
	MOVWF C17tmp
	CLRF  C18rem
	MOVLW .8
	MOVWF C16cnt
m051	RLF   C17tmp,1
	RLF   C18rem,1
	MOVLW .10
	SUBWF C18rem,W
	BTFSS 0x03,Carry
	GOTO  m052
	MOVLW .10
	SUBWF C18rem,1
	BSF   0x03,Carry
m052	RLF   y_2,1
	DECFSZ C16cnt,1
	GOTO  m051
			;                z = z % 10;
	MOVF  z_2,W
	MOVWF C20tmp
	CLRF  z_2
	MOVLW .8
	MOVWF C19cnt
m053	RLF   C20tmp,1
	RLF   z_2,1
	MOVLW .10
	SUBWF z_2,W
	BTFSS 0x03,Carry
	GOTO  m054
	MOVLW .10
	SUBWF z_2,1
m054	DECFSZ C19cnt,1
	GOTO  m053
			;                if (y != 0)
	MOVF  y_2,1
	BTFSC 0x03,Zero_
	GOTO  m055
			;                    rs_out_bb(bin2Hex(y)); //Print 10s
	MOVF  y_2,W
	CALL  bin2Hex
	CALL  rs_out_bb
			;            
			;                rs_out(bin2Hex(z)); //Print 1s 
m055	MOVF  z_2,W
	CALL  bin2Hex
	CALL  rs_out
			;            } //End Decimal
			;            else if (k == 'h') //Print Hex
	GOTO  m060
m056	MOVF  k_2,W
	XORLW .104
	BTFSS 0x03,Zero_
	GOTO  m057
			;            {
			;                high_byte.3 = my_byte.7;
	BCF   high_byte_2,3
	BTFSC my_byte_2,7
	BSF   high_byte_2,3
			;                high_byte.2 = my_byte.6;
	BCF   high_byte_2,2
	BTFSC my_byte_2,6
	BSF   high_byte_2,2
			;                high_byte.1 = my_byte.5;
	BCF   high_byte_2,1
	BTFSC my_byte_2,5
	BSF   high_byte_2,1
			;                high_byte.0 = my_byte.4;
	BCF   high_byte_2,0
	BTFSC my_byte_2,4
	BSF   high_byte_2,0
			;            
			;                low_byte.3 = my_byte.3;
	BCF   low_byte_2,3
	BTFSC my_byte_2,3
	BSF   low_byte_2,3
			;                low_byte.2 = my_byte.2;
	BCF   low_byte_2,2
	BTFSC my_byte_2,2
	BSF   low_byte_2,2
			;                low_byte.1 = my_byte.1;
	BCF   low_byte_2,1
	BTFSC my_byte_2,1
	BSF   low_byte_2,1
			;                low_byte.0 = my_byte.0;
	BCF   low_byte_2,0
	BTFSC my_byte_2,0
	BSF   low_byte_2,0
			;        
			;                rs_out_bb('0');
	MOVLW .48
	CALL  rs_out_bb
			;                rs_out_bb('x');
	MOVLW .120
	CALL  rs_out_bb
			;            
			;                rs_out_bb(bin2Hex(high_byte));
	MOVF  high_byte_2,W
	CALL  bin2Hex
	CALL  rs_out_bb
			;                rs_out_bb(bin2Hex(low_byte));
	MOVF  low_byte_2,W
	CALL  bin2Hex
	CALL  rs_out_bb
			;            } //End Hex
			;            else if (k == 'f') //Print Float
	GOTO  m060
m057	MOVF  k_2,W
	XORLW .102
	BTFSS 0x03,Zero_
	GOTO  m058
			;            {
			;                rs_out_bb('!');
	MOVLW .33
	CALL  rs_out_bb
			;            } //End Float
			;
			;            else if (k == 'u') //Print Direct Character
	GOTO  m060
m058	MOVF  k_2,W
	XORLW .117
	BTFSS 0x03,Zero_
	GOTO  m060
			;            {
			;                if(my_byte > 20) rs_out(my_byte);
	MOVLW .21
	SUBWF my_byte_2,W
	BTFSS 0x03,Carry
	GOTO  m060
	MOVF  my_byte_2,W
	CALL  rs_out
			;            } //End Direct
			;                        
			;        } //End Special Chars           
			;
			;        else
	GOTO  m060
			;            rs_out_bb(k);
m059	MOVF  k_2,W
	CALL  rs_out_bb
			;    }    
m060	INCF  i_5,1
	GOTO  m040
			;}
m061	RETURN
			;
			;//Returns nate at 9600 Baud
			;int rs_in_bb(void)
			;{
rs_in_bb
			;
			;#ifdef Clock_4MHz
			;    uns8 j, nate, count = 0;
			;
			;    //while (Serial_In == 0);
			;    while (Serial_In == 0 && count < 250)
			;    {
			;        count++;
			;        if (count > 245) return(0);
			;    }
			;
			;    for(j = 0 ; j < 8 ; j++)
			;    {
			;        nate.7 = !Serial_In;
			;        nate = rr(nate);
			;        rs_wait();
			;    }
			;    
			;    return(nate);
			;#endif
			;
			;#ifdef HS_Osc
			;    uns8 j, nate, count = 0;
	CLRF  count_2
			;
			;    //while (Serial_In == 0);
			;    while (Serial_In_BB == 0 && count < 250)
m062	BCF   0x03,RP0
	BCF   0x03,RP1
	BTFSC 0x06,RB7
	GOTO  m063
	MOVLW .250
	SUBWF count_2,W
	BTFSC 0x03,Carry
	GOTO  m063
			;    {
			;        count++;
	INCF  count_2,1
			;        if (count > 245) return(0);
	MOVLW .246
	SUBWF count_2,W
	BTFSS 0x03,Carry
	GOTO  m062
	CLRF  nate_5
	RETLW .0
			;    }
			;
			;    for(j = 0 ; j < 8 ; j++)
m063	CLRF  j
m064	MOVLW .8
	SUBWF j,W
	BTFSC 0x03,Carry
	GOTO  m065
			;    {
			;        nate.7 = !Serial_In_BB;
	BSF   nate_5,7
	BCF   0x03,RP0
	BCF   0x03,RP1
	BTFSC 0x06,RB7
	BCF   nate_5,7
			;        nate = rr(nate);
	RRF   nate_5,1
			;        rs_wait();
	CALL  rs_wait
			;    }
	INCF  j,1
	GOTO  m064
			;    
			;    return(nate);
m065	MOVF  nate_5,W
	RETURN

  ; FILE C:\cc5x\232-comm.c
			;
			;#include "c:\cc5x\Delay.c"   // Delays
			;#include "c:\cc5x\stdio.c"   // Software and Hardware based RS232 Signals
			;
			;//#pragma config |= 0x3F10 //Internal Oscillator, CProtect off, WDT off
			;#pragma config |= 0x3F02 //HS Oscillator, CProtect off, WDT off
			;
			;//#define DI1 RB3 //On-board LED
			;
			;void main()
			;{
main
			;   
			;    PORTA = 0b.0000.0000;  
	BCF   0x03,RP0
	BCF   0x03,RP1
	CLRF  PORTA
			;    TRISA = 0b.0000.0000;  //0 = Output, 1 = Input
	BSF   0x03,RP0
	CLRF  TRISA
			;
			;    PORTB = 0b.0000.0000;  
	BCF   0x03,RP0
	CLRF  PORTB
			;    TRISB = 0b.0000.0010;  //0 = Output, 1 = Input - RB1 on the 16F628 is RX of the UART
	MOVLW .2
	BSF   0x03,RP0
	MOVWF TRISB
			;
			;    uns8 x;
			;    
			;    RB5 = 1; //Turn on the on-board LED
	BCF   0x03,RP0
	BSF   0x06,RB5
			;    mem_spot = 0;
	CLRF  mem_spot
			;    uns16 button_monitor = 0;
	CLRF  button_monitor
	CLRF  button_monitor+1
			;
			;    enable_uart_TX(0); //Turn on Transmit UART with TX Interupts Disabled
	BCF   0x26,want_ints
	CALL  enable_uart_TX
			;    enable_uart_RX(1); //Turn on Receive UART with RX Interupts Enabled
	BCF   0x03,RP0
	BCF   0x03,RP1
	BSF   0x26,want_ints_2
	CALL  enable_uart_RX
			;
			;    char aux;
			;    aux = 0x0000;
	BCF   0x03,RP0
	BCF   0x03,RP1
	CLRF  aux
			;
			;    
			;    while(1)
			;    {
			;
			;        if (print_it == TRUE) //We have something to record
m066	BCF   0x03,RP0
	BCF   0x03,RP1
	BTFSS 0x32,print_it
	GOTO  m073
			;        {
			;            GIE = 0;
	BCF   0x0B,GIE
			;            
			;            print_it = FALSE;
	BCF   0x32,print_it
			;            button_monitor = 0; //Reset the LED blinker
	CLRF  button_monitor
	CLRF  button_monitor+1
			;            
			;            //Pass the pressed key back to hyperterminal
			;//            printf("Ascii: %h\n\r", data_in);
			;            printf("%u", data_in);            
	CLRF  nate_2
	MOVF  data_in,W
	CALL  printf
			;            
			;            //Store the incoming data to the memory array
			;            memory_array[mem_spot] = data_in;
	MOVLW .55
	BCF   0x03,RP0
	BCF   0x03,RP1
	ADDWF mem_spot,W
	MOVWF FSR
	BCF   0x03,IRP
	MOVF  data_in,W
	MOVWF INDF
			;            mem_spot++;
	INCF  mem_spot,1
			;
			;            if (mem_spot > 8) mem_spot = 0;
	MOVLW .9
	SUBWF mem_spot,W
	BTFSC 0x03,Carry
	CLRF  mem_spot
			;    
			;
			;            if (data_in == 0x0D && mem_spot>3)
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_in,W
	XORLW .13
	BTFSS 0x03,Zero_
	GOTO  m072
	MOVLW .4
	SUBWF mem_spot,W
	BTFSS 0x03,Carry
	GOTO  m072
			;            {
			;                rs_out(12);
	MOVLW .12
	CALL  rs_out
			;                
			;                data_last1 = memory_array[mem_spot-2];
	MOVLW .53
	BCF   0x03,RP0
	BCF   0x03,RP1
	ADDWF mem_spot,W
	MOVWF FSR
	BCF   0x03,IRP
	MOVF  INDF,W
	MOVWF data_last1
			;                data_last2 = memory_array[mem_spot-3];
	MOVLW .52
	ADDWF mem_spot,W
	MOVWF FSR
	BCF   0x03,IRP
	MOVF  INDF,W
	MOVWF data_last2
			;                data_last3 = memory_array[mem_spot-4];
	MOVLW .51
	ADDWF mem_spot,W
	MOVWF FSR
	BCF   0x03,IRP
	MOVF  INDF,W
	MOVWF data_last3
			;       //         printf("last1 %u\n\r", data_last1);
			;       //         printf("data_last2 %u\n\r", data_last2);
			;       //         printf("data_last3 %u\n\r", data_last3);
			;
			;                if(data_last3 == 'O')
	MOVF  data_last3,W
	XORLW .79
	BTFSS 0x03,Zero_
	GOTO  m071
			;                {
			;                    switch (data_last2) {
	MOVF  data_last2,W
	XORLW .49
	BTFSC 0x03,Zero_
	GOTO  m067
	XORLW .3
	BTFSC 0x03,Zero_
	GOTO  m068
	XORLW .1
	BTFSC 0x03,Zero_
	GOTO  m069
	XORLW .7
	BTFSC 0x03,Zero_
	GOTO  m070
	GOTO  m071
			;                    case '1':
			;                        if (data_last1 == 'A')
m067	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .65
	BTFSC 0x03,Zero_
			;                        {
			;                            aux |= 0x08;
	BSF   aux,3
			;              
			;                        }                    
			;                        if (data_last1 == 'D')
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .68
	BTFSC 0x03,Zero_
			;                        {
			;                            aux &= 0xF7;
	BCF   aux,3
			;                            
			;                        }
			;                        PORTA = aux;
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  aux,W
	MOVWF PORTA
			;                    break;
	GOTO  m071
			; 
			;                   case '2':
			;                        if (data_last1 == 'A')
m068	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .65
	BTFSC 0x03,Zero_
			;                        {
			;                            aux |= 0x04;
	BSF   aux,2
			;                           
			;                        }
			;                        if (data_last1 == 'D')
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .68
	BTFSC 0x03,Zero_
			;                        {
			;                            aux &= 0xFB;
	BCF   aux,2
			;                           
			;                        }
			;                        PORTA = aux;
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  aux,W
	MOVWF PORTA
			;                    break;
	GOTO  m071
			;  
			;                  case '3':
			;                        if (data_last1 == 'A')
m069	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .65
	BTFSC 0x03,Zero_
			;                        {
			;                            aux |= 0x02;
	BSF   aux,1
			;                        
			;                        }
			;                        if (data_last1 == 'D')
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .68
	BTFSC 0x03,Zero_
			;                        {
			;                            aux &= 0xFD;
	BCF   aux,1
			;                        }
			;                        PORTA = aux;
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  aux,W
	MOVWF PORTA
			;                    break;
	GOTO  m071
			; 
			;                   case '4':
			;                        if (data_last1 == 'A')
m070	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .65
	BTFSC 0x03,Zero_
			;                        {
			;                            aux |= 0x01;
	BSF   aux,0
			;                        
			;                        }
			;                        if (data_last1 == 'D')
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  data_last1,W
	XORLW .68
	BTFSC 0x03,Zero_
			;                        {
			;                            aux &= 0xFE;
	BCF   aux,0
			;                        
			;                        }
			;                        PORTA = aux;
	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  aux,W
	MOVWF PORTA
			;                    break;
			;
			;                    default:
			;                    break;
			;                    }
			;
			;                }
			;             mem_spot = 0;
m071	BCF   0x03,RP0
	BCF   0x03,RP1
	CLRF  mem_spot
			;            }
			;
			;
			;            //Dump the memory array to the hyperterminal screen
			;        /*    if (data_in == 'Z')
			;            {
			;                rs_out(12); //Clear the hyperterminal screen
			;                printf("Local Memory Dump:\n\r", 0);
			;                for(x = 0 ; x < 8 ; x++)
			;                    printf("%u ", memory_array[x]);
			;            }
			;*/
			;            //Finish up
			;            GIE = 1;            
m072	BSF   0x0B,GIE
			;
			;            CREN = 0;
	BCF   0x03,RP0
	BCF   0x03,RP1
	BCF   0x18,CREN
			;            CREN = 1;
	BSF   0x18,CREN
			;        }
			;        
			;        //Blinks the LED when the counter called button_monitor rolls over
			;        if(button_monitor == 0xFFFF)
m073	BCF   0x03,RP0
	BCF   0x03,RP1
	MOVF  button_monitor,W
	ANDWF button_monitor+1,W
	XORLW .255
	BTFSS 0x03,Zero_
	GOTO  m074
			;            RB5 ^= 1;
	MOVLW .32
	XORWF PORTB,1
			;        
			;        button_monitor++;
m074	BCF   0x03,RP0
	BCF   0x03,RP1
	INCF  button_monitor,1
	BTFSC 0x03,Zero_
	INCF  button_monitor+1,1
			;    }
	GOTO  m066

	ORG 0x2007
	DATA 3F02H
	END


; *** KEY INFO ***

; 0x0004   22 word(s)  1 % : serverX
; 0x0026   26 word(s)  1 % : delay_ms
; 0x0040   20 word(s)  0 % : delay10
; 0x0054    8 word(s)  0 % : _delay10
; 0x005C   18 word(s)  0 % : enable_uart_TX
; 0x006E   16 word(s)  0 % : enable_uart_RX
; 0x007E   10 word(s)  0 % : rs_out
; 0x0088   22 word(s)  1 % : bin2Hex
; 0x009E  278 word(s) 13 % : printf
; 0x001A   11 word(s)  0 % : _const1
; 0x01B4   10 word(s)  0 % : rs_wait
; 0x01BE   29 word(s)  1 % : rs_out_bb
; 0x01DB  198 word(s)  9 % : printf_bb
; 0x0025    1 word(s)  0 % : _const2
; 0x02A1   32 word(s)  1 % : rs_in_bb
; 0x02C1  188 word(s)  9 % : main

; RAM usage: 34 bytes (19 local), 190 bytes free
; Maximum call level: 2 (+1 for interrupt)
; Total of 890 code words (43 %)
