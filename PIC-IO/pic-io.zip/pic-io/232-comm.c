/*
    7-23-03
    Copyright Spark Fun Electronics� 2003
    
    Using the PIC and the RS232 Interface

    Use Hyperterminal provided by Windows or some equivalent serial communications
    software. Set the correct com port to 9600 Baud 8-N-1.
    
    ==============================================================

    Using hyperterminal, any button that the user presses is transmitted to the PIC.
    The PIC then responds with both the HEX value and the ASCII representation of the 
    letter that was pressed.
    
    All keys are stored in memory, and upon receiving a 'Z' key press the last 64 key presses
    will be dumped onto the hyperterminal screen.
    
*/
#define HS_Osc
#define Serial_Out_BB   RB2
#define Serial_In_BB   RB7
#define Baud_9600

#include "c:\cc5x\16F628.h" //Compiler specific header file
#include "c:\cc5x\int16CXX.H" //General Interrupts header file

#pragma origin 4 //Manditory when interrupts are used

#define TRUE        1
#define FALSE       0

bit print_it;
bit start_record;

uns8 data_in;
uns8 data_last1;
uns8 data_last2;
uns8 data_last3;

uns8 memory_array[8];
uns8 mem_spot;

interrupt serverX(void)
{
    int_save_registers
    char sv_FSR = FSR;  // save FSR if required

    if(RCIF) //UART Recieve Interrupt
    {
        data_in = RCREG;

        print_it = TRUE;
            
        //No clearing RCIF, must clear RCREG        
        RCREG = 0;
    }

    FSR = sv_FSR;               // restore FSR if saved
    int_restore_registers 
}

#include "c:\cc5x\Delay.c"   // Delays
#include "c:\cc5x\stdio.c"   // Software and Hardware based RS232 Signals

//#pragma config |= 0x3F10 //Internal Oscillator, CProtect off, WDT off
#pragma config |= 0x3F02 //HS Oscillator, CProtect off, WDT off

//#define DI1 RB3 //On-board LED

void main()
{
   
    PORTA = 0b.0000.0000;  
    TRISA = 0b.0000.0000;  //0 = Output, 1 = Input

    PORTB = 0b.0000.0000;  
    TRISB = 0b.0000.0010;  //0 = Output, 1 = Input - RB1 on the 16F628 is RX of the UART

    uns8 x;
    
    RB5 = 1; //Turn on the on-board LED
    mem_spot = 0;
    uns16 button_monitor = 0;

    enable_uart_TX(0); //Turn on Transmit UART with TX Interupts Disabled
    enable_uart_RX(1); //Turn on Receive UART with RX Interupts Enabled

    char aux;
    aux = 0x0000;

    
    while(1)
    {

        if (print_it == TRUE) //We have something to record
        {
            GIE = 0;
            
            print_it = FALSE;
            button_monitor = 0; //Reset the LED blinker
            
            //Pass the pressed key back to hyperterminal
//            printf("Ascii: %h\n\r", data_in);
            printf("%u", data_in);            
            
            //Store the incoming data to the memory array
            memory_array[mem_spot] = data_in;
            mem_spot++;

            if (mem_spot > 8) mem_spot = 0;
    

            if (data_in == 0x0D && mem_spot>3)
            {
                rs_out(12);
                
                data_last1 = memory_array[mem_spot-2];
                data_last2 = memory_array[mem_spot-3];
                data_last3 = memory_array[mem_spot-4];
       //         printf("last1 %u\n\r", data_last1);
       //         printf("data_last2 %u\n\r", data_last2);
       //         printf("data_last3 %u\n\r", data_last3);

                if(data_last3 == 'O')
                {
                    switch (data_last2) {
                    case '1':
                        if (data_last1 == 'A')
                        {
                            aux |= 0x08;
              
                        }                    
                        if (data_last1 == 'D')
                        {
                            aux &= 0xF7;
                            
                        }
                        PORTA = aux;
                    break;
 
                   case '2':
                        if (data_last1 == 'A')
                        {
                            aux |= 0x04;
                           
                        }
                        if (data_last1 == 'D')
                        {
                            aux &= 0xFB;
                           
                        }
                        PORTA = aux;
                    break;
  
                  case '3':
                        if (data_last1 == 'A')
                        {
                            aux |= 0x02;
                        
                        }
                        if (data_last1 == 'D')
                        {
                            aux &= 0xFD;
                        }
                        PORTA = aux;
                    break;
 
                   case '4':
                        if (data_last1 == 'A')
                        {
                            aux |= 0x01;
                        
                        }
                        if (data_last1 == 'D')
                        {
                            aux &= 0xFE;
                        
                        }
                        PORTA = aux;
                    break;

                    default:
                    break;
                    }

                }
             mem_spot = 0;
            }


            //Dump the memory array to the hyperterminal screen
        /*    if (data_in == 'Z')
            {
                rs_out(12); //Clear the hyperterminal screen
                printf("Local Memory Dump:\n\r", 0);
                for(x = 0 ; x < 8 ; x++)
                    printf("%u ", memory_array[x]);
            }
*/
            //Finish up
            GIE = 1;            

            CREN = 0;
            CREN = 1;
        }
        
        //Blinks the LED when the counter called button_monitor rolls over
        if(button_monitor == 0xFFFF)
            RB5 ^= 1;
        
        button_monitor++;
    }
        
}

