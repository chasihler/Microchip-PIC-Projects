VERSION 5.00
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form consolaIO 
   Caption         =   "Olimex Control Pannel"
   ClientHeight    =   5925
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   6420
   LinkTopic       =   "Form1"
   ScaleHeight     =   5925
   ScaleWidth      =   6420
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Open"
      Height          =   315
      Left            =   2040
      TabIndex        =   12
      Top             =   5520
      Width           =   855
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   1440
      TabIndex        =   10
      Text            =   "1"
      Top             =   5520
      Width           =   375
   End
   Begin VB.PictureBox Picture1 
      Height          =   5295
      Left            =   120
      Picture         =   "oliconsolle.frx":0000
      ScaleHeight     =   5235
      ScaleWidth      =   6075
      TabIndex        =   0
      Top             =   120
      Width           =   6135
      Begin VB.CommandButton CmdOff 
         Caption         =   "Off"
         Height          =   375
         Index           =   3
         Left            =   4080
         TabIndex        =   8
         Top             =   4200
         Width           =   735
      End
      Begin VB.CommandButton CmdOff 
         Caption         =   "Off"
         Height          =   375
         Index           =   2
         Left            =   4080
         TabIndex        =   7
         Top             =   3120
         Width           =   735
      End
      Begin VB.CommandButton CmdOff 
         Caption         =   "Off"
         Height          =   375
         Index           =   1
         Left            =   4080
         TabIndex        =   6
         Top             =   2160
         Width           =   735
      End
      Begin VB.CommandButton CmdOff 
         Caption         =   "Off"
         Height          =   375
         Index           =   0
         Left            =   4080
         TabIndex        =   5
         Top             =   1200
         Width           =   735
      End
      Begin VB.CommandButton OutOn 
         Caption         =   "On"
         Height          =   375
         Index           =   3
         Left            =   4080
         TabIndex        =   4
         Top             =   3840
         Width           =   735
      End
      Begin VB.CommandButton OutOn 
         Caption         =   "On"
         Height          =   375
         Index           =   2
         Left            =   4080
         TabIndex        =   3
         Top             =   2760
         Width           =   735
      End
      Begin VB.CommandButton OutOn 
         Caption         =   "On"
         Height          =   375
         Index           =   1
         Left            =   4080
         TabIndex        =   2
         Top             =   1800
         Width           =   735
      End
      Begin VB.CommandButton OutOn 
         Caption         =   "On"
         Height          =   375
         Index           =   0
         Left            =   4080
         TabIndex        =   1
         Top             =   840
         Width           =   735
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   7
         Left            =   3360
         Shape           =   3  'Circle
         Top             =   4200
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   6
         Left            =   3360
         Shape           =   3  'Circle
         Top             =   3240
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   5
         Left            =   3360
         Shape           =   3  'Circle
         Top             =   2160
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   4
         Left            =   3360
         Shape           =   3  'Circle
         Top             =   1200
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   3
         Left            =   600
         Shape           =   3  'Circle
         Top             =   4200
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   2
         Left            =   600
         Shape           =   3  'Circle
         Top             =   3480
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   1
         Left            =   720
         Shape           =   3  'Circle
         Top             =   2880
         Width           =   375
      End
      Begin VB.Shape Led 
         BackColor       =   &H000000FF&
         BorderStyle     =   0  'Transparent
         FillColor       =   &H000000FF&
         Height          =   375
         Index           =   0
         Left            =   720
         Shape           =   3  'Circle
         Top             =   2280
         Width           =   375
      End
   End
   Begin MSCommLib.MSComm MSComm1 
      Left            =   3600
      Top             =   5520
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DTREnable       =   -1  'True
      RThreshold      =   1
      RTSEnable       =   -1  'True
   End
   Begin VB.Label Label2 
      Caption         =   "Puerto Serial "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   11
      Top             =   5520
      Width           =   1695
   End
   Begin VB.Label Label1 
      Caption         =   "http://www.olimex.cl"
      Height          =   255
      Left            =   4440
      TabIndex        =   9
      Top             =   5520
      Width           =   1815
   End
End
Attribute VB_Name = "consolaIO"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub LedOn(Index As Integer)
    Led(Index).BackStyle = 1
End Sub

Private Sub LedOff(Index As Integer)
    Led(Index).BackStyle = 0
End Sub


Private Sub Command1_Click()
    If Command1.Caption = "Open" Then
        MSComm1.CommPort = Text1.Text
        MSComm1.PortOpen = True
        Command1.Caption = "Close"
    Else
        MSComm1.PortOpen = False
        Command1.Caption = "Open"
    End If
End Sub

Private Sub CheckRxData(incomingChars As String)

    crPos = InStr(1, incomingChars, Chr$(13), vbBinaryCompare)
    If crPos <> 0 Then
        rxLine = Mid(incomingChars, 1, crPos - 1)
        
        For i = 2 To 5
            If Mid(rxLine, i, 1) = "A" Then
                LedOn (i - 2)
            Else
                LedOff (i - 2)
            End If
        Next i
    End If
End Sub


Private Sub MSComm1_OnComm()

    Select Case MSComm1.CommEvent
      Case comEventBreak
        Debug.Print "comEventBreak"
      Case comEventFrame
        Debug.Print "comEventFrame"
      Case comEventOverrun
        Debug.Print "comEventOverrun"
      Case comEventRxOver
        Debug.Print "comEventRxOver"
      Case comEventRxParity
        Debug.Print "comEventRxParity"
      Case comEventTxFull
        Debug.Print "comEventTxFull"
      Case comEventDCB
        Debug.Print "comEventDCB"
      Case comEvCD
        Debug.Print "comEvCD"
      Case comEvCTS
        Debug.Print "comEvCTS"
      Case comEvDSR
        Debug.Print "comEvDSR"
      Case comEvRing
        Debug.Print "comEvRing"
      Case comEvReceive
        CheckRxData (MSComm1.Input)
      Case comEvSend
        Debug.Print "comEvSend"
      Case comEvEOF
        Debug.Print "comEvEOF"
    End Select
End Sub


Private Sub OutOn_Click(Index As Integer)
    MSComm1.Output = "O"
  Delay
    MSComm1.Output = Chr$(Index + &H30 + 1)
 Delay
    MSComm1.Output = "A"
 Delay
    MSComm1.Output = Chr$(13)
    LedOn (4 + Index)
End Sub

Private Sub CmdOff_Click(Index As Integer)
    MSComm1.Output = "O"
    Delay
    MSComm1.Output = Chr$(Index + &H30 + 1)
    Delay
    MSComm1.Output = "D"
    Delay
    MSComm1.Output = Chr$(13)
    LedOff (4 + Index)
End Sub

Sub Delay()

   For iCount = 1 To 100000
   Next iCount

End Sub
