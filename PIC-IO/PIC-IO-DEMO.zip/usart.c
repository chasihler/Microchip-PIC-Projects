#include	<pic.h>

#define BUFFER_SIZE 	8

void InitUsart(void) {

	// TX Pin - output
	TRISB2 = 0;

	// RX Pin - input
	TRISB1 = 1;

	// RX Setting, 8bit, enable receive, 
	RCSTA = 0x90; 

	// TX Setting, 8bit, Asinchronius mode, High speed 
	TXSTA = 0x24;

	// Set Baudrade - 9600 (from datasheet baudrade table)
	SPBRG = 129;

}


void  WriteByte(unsigned char byte) {
	
	// wait until register is empty 
	while(!TXIF);

	// transmite byte	
	TXREG = byte;
}

unsigned char ReadByte(void) {
	
	// wait to receive character
	while(!RCIF);

	// return received character
	return RCREG;	
}


void WriteString(unsigned char* str) {
	
	unsigned char index;
	
	index=0;
	while(str[index]!='\0') {
		WriteByte(str[index]);
		index++;
	}
	
}


// Write string to usart
void WriteStringConst(const unsigned char* str) {
	
	unsigned char index;
	
	index=0;
	while(str[index]!='\0') {
		WriteByte(str[index]);
		index++;
	}
	
}
// Read string and save to buffer until ENTER key or buffer lenght
void ReadString(unsigned char* buff) {

	unsigned char tmp, index;
	
	tmp=index=0;

	while(1) {
		tmp = ReadByte();
		
		if(tmp==0x0D) {
			buff[index]='\0';
			break;
		}
		else {
		  	if(index<BUFFER_SIZE) {	
		  		buff[index]=tmp;
		  		index++;		
		  	}
		}	
	}
}
