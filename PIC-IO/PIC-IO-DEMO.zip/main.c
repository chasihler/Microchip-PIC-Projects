//PROGRAMM FOR DEMO Board
//
// PROCESSOR : PIC16F628A
// CLOCK	 : 20MHz, EXTERNAL


#include	<pic.h>
#include 	<stdio.h>
#include	"usart.h"
#include 	<stdlib.h>

__CONFIG(WDTDIS & MCLREN & BORDIS & HS & PWRTEN & LVPDIS) ;


//Just simple delay
void Delay(unsigned long cntr) {
	while (--cntr != 0);
}

unsigned char buff[16];
unsigned char print_buff[8];
const unsigned char walcome1[] 	= "\n\r************************";
const unsigned char walcome2[] 	= "\n\r* PIC IO CONTROL       *";
const unsigned char walcome3[] 	= "\n\r* (C) 2007, OLIMEX Ltd *";
const unsigned char err_msg[]	= "\n\r ERR";
unsigned char sign_cmd[] = "\n\r>";
unsigned char i, ch, inputs, outputs; 


// Get input state
unsigned char GetInputs(void) {

	unsigned char in;

	in = RB4;
	in <<=1; 
	in |= RB3;
	in <<=1; 
	in |= RB0;
	in <<=1; 
	in |= RA4;

	return in;
}


void GetCommand(unsigned char* buff) {
	
	if(buff[0]=='R') {
		inputs = GetInputs();
		sprintf(print_buff, "\n\r$%01x \0", inputs);
		WriteString(print_buff);
	}
	else if(buff[0]=='r') {
		WriteByte('%');
		if(RB4) WriteByte('1');
		else 	WriteByte('0');
		if(RB3) WriteByte('1');
		else 	WriteByte('0');
		if(RB0) WriteByte('1');
		else 	WriteByte('0');
		if(RA4) WriteByte('1');
		else 	WriteByte('0');
	}
	else if(buff[0]=='W') {
		
		if(buff[2]!=0) {
			WriteStringConst(err_msg);
			return;
		}

		switch(buff[1]) {
			case '0': 	PORTA &= ~0x0F; PORTA |= 0x0; break;
			case '1': 	PORTA &= ~0x0F; PORTA |= 0x1; break;
			case '2': 	PORTA &= ~0x0F; PORTA |= 0x2; break;
			case '3': 	PORTA &= ~0x0F; PORTA |= 0x3; break;
			case '4': 	PORTA &= ~0x0F; PORTA |= 0x4; break;
			case '5': 	PORTA &= ~0x0F; PORTA |= 0x5; break;
			case '6': 	PORTA &= ~0x0F; PORTA |= 0x6; break;
			case '7': 	PORTA &= ~0x0F; PORTA |= 0x7; break;
			case '8': 	PORTA &= ~0x0F; PORTA |= 0x8; break;
			case '9': 	PORTA &= ~0x0F; PORTA |= 0x9; break;
			case 'A': 	PORTA &= ~0x0F; PORTA |= 0xA; break;
			case 'B': 	PORTA &= ~0x0F; PORTA |= 0xB; break;
			case 'C': 	PORTA &= ~0x0F; PORTA |= 0xC; break;
			case 'D': 	PORTA &= ~0x0F; PORTA |= 0xD; break;
			case 'E': 	PORTA &= ~0x0F; PORTA |= 0xE; break;
			case 'F': 	PORTA &= ~0x0F; PORTA |= 0xF; break; 
			default :   PORTA &= ~0x0F; WriteStringConst(err_msg);
		}
	}
	else if(buff[0]=='w') {
		
		i=1;
		outputs=0;
		while(buff[i]!=0) {

			if(i>=5) {
				WriteStringConst(err_msg);
				outputs = 0;
				break;	
			}
			
			outputs<<=1;
			
			if(buff[i]=='1') {
				outputs |= 1;			
			}
			else if (buff[i]=='0') {

			}
			else {
				WriteStringConst(err_msg);
				outputs = 0;
				break;	
			}
			i++;
			
		}

		PORTA = outputs;
		
	}	
	else {
		// ERROR
		WriteStringConst(err_msg);
	}
}


// main function
void main( void ) {

	OPTION	= 0x80;			// GPIO pull-ups are disabled
	INTCON 	= 0x0;			// Disable inerupt
	CMCON	= 0x7; 			// Comparators OFF	
	VRCON	= 0x0;			// disconnected from RA2 pin
	
	TRISB5 	= 0;			// Led pin as output

	TRISA4	= 1;			// I1 as input
	TRISB0	= 1;			// I2 as input		
	TRISB3	= 1;			// I3 as input
	TRISB4	= 1;			// I4 as input
	
	TRISA3	= 0;			// 01 as output
	TRISA2	= 0;			// 02 as output		
	TRISA1	= 0;			// 03 as output
	TRISA0	= 0;			// 04 as output

	PORTA &= ~0xF;			// Clear all relay

	// Init Uart Interface
	InitUsart();

	// Print menu
	WriteStringConst(walcome1);
	WriteStringConst(walcome2);
	WriteStringConst(walcome3);
	WriteStringConst(walcome1);
	
	// loop forever
	while(1) {
		// Write command sign
		WriteString(sign_cmd);
		// Wait user to type any command
		ReadString(buff);
		// Translate command and action :-)
		GetCommand(buff);
	}

}
