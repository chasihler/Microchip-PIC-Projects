
void InitUsart(void);
void WriteByte(unsigned char byte);
unsigned char ReadByte(void);
void WriteString(unsigned char* str);
void WriteStringConst(const unsigned char* str);
void ReadString(unsigned char* buff);

