/*
 * Project name:
     PIC clicker (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Revision History:
     20130906:
       - initial release (JK);
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     RA0 and RA1 pins depending on pressed buttons. Left button T1 changes mode
     of blinking and right button changes frequency of blinking.
 * Test configuration:
     MCU:             PIC18F47J53
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39964B.pdf
     Dev.Board:       PIC clicker - ac:PIC_clicker
                      http://www.mikroe.com/pic/clicker/
     Oscillator:      HS-PLL 48.0000 MHz, 16.0000 MHz Crystal
     Ext. Modules:    None.
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/mikroc/pic/
 */
// pin definitions
sbit LD1 at LATA0_bit;
sbit LD2 at LATA1_bit;
sbit LD1_Direction at TRISA0_bit;
sbit LD2_Direction at TRISA1_bit;

sbit T1 at RD3_bit;
sbit T2 at RD2_bit;
sbit T1_Direction at TRISD3_bit;
sbit T2_Direction at TRISD2_bit;

// globals
char oldstate1 = 0, oldstate2 = 0;
char Example_State = 0;
char count;

//Timer0
//Prescaler 1:128; TMR0 Preload = 18660; Actual Interrupt Time : 500 ms
void InitTimer0(){
  T0CON         = 0x86;
  TMR0H         = 0x48;
  TMR0L         = 0xE4;
  GIE_bit       = 1;
  TMR0IE_bit    = 1;
}

// ISR
void Interrupt(){
char temp;
  // check for timer0 interrupt
  if (TMR0IF_bit){
    // clear timer0 Interrupt flag
    TMR0IF_bit = 0;
    // check T1 button state
    switch (Example_State & 0x0F){
      case 0 : LD1 = 0;                     // Both LEDs are OF
               LD2 = 0;
               break;
      case 1 : LD1 ^= 1;                    // Only LD1 blinks
               LD2 = 0;
               break;
      case 2 : LD1 = 0;                     // Only LD2 blinks
               LD2 ^= 1;
               break;
      case 3 : LD1 ^= 1;                    // Both LEDs blinks alternately
               LD2  = !LD1;
               break;
      case 4 : LD1 ^= 1;                    // Both LEDs blink simultaneously
               LD2  = LD1;
               break;
      default : Example_State &= 0xF0;      // reset T1 state to zero
                break;
    }
    // check T2 button state
    switch (Example_State & 0xF0){
      case 0x00 : TMR0H = 0x48;             // Set Timer0 Interrupt time to 500ms
                  TMR0L = 0xE4;
                  break;
      case 0x10 : TMR0H = 0x6D;             // Set Timer0 Interrupt time to 400ms
                  TMR0L = 0x83;
                  break;
      case 0x20 : TMR0H = 0x92;             // Set Timer0 Interrupt time to 300ms
                  TMR0L = 0x22;
                  break;
      case 0x30 : TMR0H = 0xB6;             // Set Timer0 Interrupt time to 200ms
                  TMR0L = 0xC1;
                  break;
      case 0x40 : TMR0H = 0xDB;             // Set Timer0 Interrupt time to 100ms
                  TMR0L = 0x60;
                  break;
      default :   TMR0H = 0x48;             // Set Timer0 Interrupt time to 500ms
                  TMR0L = 0xE4;
                  Example_State &= 0x0F;    // reset T1 state to zero
                break;
    }
  }
}

// main function
void main() {
  ANCON0 = 0;               // Default all pins to digital
  ANCON1 = 0;
  
  T1_Direction = 1;         // Set direction for buttons
  T2_Direction = 1;
  
  LD1_Direction = 0;        // Set direction for LEDS
  LD2_Direction = 0;
  LD1 = 0;                  // turn off leds
  LD2 = 0;
  Example_State = 0;        // set default Example state

  InitTimer0();             // initialize timer0

  while(1){                 // Endless loop
    // check T1 button
    if (Button(&PORTD, 3, 2, 0)) {                // Detect logical zero
      oldstate1 = 1;                              // Update flag
    }
    if (oldstate1 && Button(&PORTD, 3, 2, 1)) {   // Detect zero-to-one transition
      oldstate1 = 0;                              // Update flag
      Example_State += 0x01;                      // set new Example state
      if ((Example_State & 0x0F) > 4)
        Example_State &= 0xF0;
    }
    // check T2 button
    if (Button(&PORTD, 2, 2, 0)) {                // Detect logical zero
      oldstate2 = 1;                              // Update flag
    }
    if (oldstate2 && Button(&PORTD, 2, 2, 1)) {   // Detect zero-to-one transition
      oldstate2 = 0;                              // Update flag
      Example_State += 0x10;                      // set new Example state
      if ((Example_State & 0xF0) > 0x40)
        Example_State &= 0x0F;
    }
  }
}