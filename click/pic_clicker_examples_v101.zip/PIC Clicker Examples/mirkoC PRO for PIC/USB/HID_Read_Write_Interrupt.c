/*
 * Project name:
     HID_Read_Write_Interrupt (Testing the USB HID connection)
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Revision History:
     20130906:
       - initial release (JK);
 * Description:
     This example establishes connection with the HID terminal that is active
     on the PC. Upon connection establishment, the HID Device Name will appear
     in the respective window. After that software will wait for data and
     it will return received data back.
 * Test configuration:
     MCU:             PIC18F47J53
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39964B.pdf
     Dev.board:       PIC clicker - ac:PIC_clicker
                      http://www.mikroe.com/pic/clicker/
     Oscillator:      HS-PLL 48.0000 MHz, 16.0000 MHz Crystal
     Ext. Modules:    None.
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/mikroc/pic/
 */

unsigned char readbuff[64];
unsigned char writebuff[64];

char cnt;
char kk;

void interrupt(){
   USB_Interrupt_Proc();                   // USB servicing is done inside the interrupt
}

void main(void){
  ANCON0 = 0;
  ANCON1 = 0;

  HID_Enable(&readbuff,&writebuff);       // Enable HID communication
    GIE_bit = 1;
  while(1){
    while(!HID_Read())
      ;

    for(cnt=0;cnt<64;cnt++)
      writebuff[cnt]=readbuff[cnt];

    while(!HID_Write(&writebuff,64))
      ;
  }
}