Notes on the "first cut" BIOS:

  This is the first version, to get CP/M up & running on the P112 board.
Support is minimal: basic devices, no interrupts or IOBYTE.

  The Submit file will build BIOS for its correct starting location (F600),
with a loader in the 100H bytes below that. The entire .HEX file is to be
read in using the Hex Upload feature of the ROM debugger. GO to locn. F500
(from the debugger), and BIOS will be installed on the correct sectors.
  Assuming the boot sector and CP/M itself are also installed, this is now
a bootable disk.

  Note that the version of DISKOP (the diskette subsystem) used in BIOS has
had the FORMAT command deleted. This to save memory: FORMAT is quite large,
and never normally used. See the FORMAT subdirectory for formatting diskettes.
The DISKOP source file is the same for BIOS and the ROM, save for the switch
"incformat" - this is defined in the ROM version, and commented out in the
BIOS version.

  This BIOS is designed so that loading will not corrupt the final 200H bytes
of RAM - they are occupied by the disk sector-buffer. This is because these
locations are used as workspace by the ROM. Since they are not altered, the
act of loading CP/M will not interfere with ROM functionality, and an un-
successful load can return to the ROM in safety. (Note that once CP/M is 
actually initiated, the ROM is no longer accessible).

"OVERLOAD" FUNCTIONS

  Besides the regular BIOS functions, additional "overload" functions
are defined. These are called from the cold-boot entry (which CP/M
never uses after start-up). The call passes a function code in C.

Currently defined are:

C=0	Reset disk subsystem
  This will turn off all drive motors, and issue a reset to the
controller hardware. It does NOT flush the CP/M blocking buffers:
a call to HOME should be made first, to do this.

C=1	Get boot-drive number
  The number of the drive from which CP/M was booted is returned in A.

C=2	Assign drive type
  Pass 	D = required rive number
	E = required drive type (see DRVTYPE.INC for definitions)

  If D and E are valid, the given drive is assigned to the hardware type
specified in E. This affects both the CP/M organsiation tables, and the
parameter-block controlling the hardware setup.
  If E = -1, the assigned type is returned in E.
