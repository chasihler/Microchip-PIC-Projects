/*!---------------------------------------------------------------------------
** @file	Modbus.h
** 
** @brief	Modbus protocol handler
**
**---------------------------------------------------------------------------
**
** Copyright 2010 Roy Hopkins (roy_web@fieldofcows.com)
**
** This file is part of the firmware for the Field of Cows USB Modbus I/O
** project (USBModbus)
** 
** USBModbus is free software: you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
** 
** USBModbus is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with USBModbus.  If not, see <http://www.gnu.org/licenses/>.
**
*/

#ifndef __modbus__h
#define __modbus__h

/*--------------------------------------------------------------------------- 
** Includes 
*/

/*--------------------------------------------------------------------------- 
** Defines and Macros 
*/
// Uncomment one of the three lines below to enable ASCII, RTU or software controlled protocol
//#define MODECONTROL_ASCII
#define MODECONTROL_RTU
//#define MODECONTROL_SW

// This definition defines the slave address
#define SLAVE_ADDRESS	1


#ifndef BOOL
#define BOOL unsigned char
#endif

#ifndef TRUE
#define TRUE !0
#endif
#ifndef FALSE
#define FALSE 0
#endif

/*---------------------------------------------------------------------------
** Typedefs 
*/
#ifdef MODECONTROL_SW
typedef enum 
{
  MODE_ASCII,
  MODE_RTU
} MODBUS_MODE;
#endif

typedef struct
{
  unsigned address;
  unsigned function;
  unsigned char dataBuf[20];
  unsigned dataLen;
} RXTX_DATA;

/*---------------------------------------------------------------------------
** Function prototypes
*/

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Set the modbus protocol mode
** 
** @param[in]	mode	Modbus mode to set, MODE_ASCII or MODE_RTU
** 
*/ 
#ifdef MODECONTROL_SW
void
setMode(
	MODBUS_MODE mode
);
#endif

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Initialise the modbus routines
**
** Initialises the modbus routines as defined in the definitions at the
** top of this file.
**
*/ 
void
initialiseModbus(
	void
);

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Signal that a Modbus message should be sent
**
** Initialises the transmit state machine to send a message
**
*/
BOOL
sendMessage(
	void
);

//-------------------------------------------------------------------------- 
/*! 
** @brief   	See if any transmit operation is pending
**
** @return		TRUE if idle else FALSE
**
*/
BOOL
txIdle(
	void
);

//-------------------------------------------------------------------------- 
/*! 
** @brief   	See if there is any data in the receive queue
** 
** @return    	TRUE if data waiting else false
**
** Whenever this function returns true it is assumed that the data will be
** read imminently therefore subsequent calls to this function will return
** FALSE until more data is received
*/ 
BOOL
rxDataAvailable(
	void
);

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Get a pointer to the transmit buffer
**
** @return		Transmit buffer
**
*/
RXTX_DATA*
txData(
	void
);

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Get the received data queue
** 
** @return    	Pointer to received data
** 
*/ 
RXTX_DATA*
rxData(
	void
);

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Get the received data queue
** 
** @return    	Pointer to received data
** 
*/ 
void
processModbus(
	void
);

/*---------------------------------------------------------------------------
** Data 
*/

#endif
