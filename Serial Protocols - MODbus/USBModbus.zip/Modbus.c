/*!---------------------------------------------------------------------------
** @file	Modbus.c
** 
** @brief	Modbus protocol handler
** 
**---------------------------------------------------------------------------
**
** Copyright 2010 Roy Hopkins (roy_web@fieldofcows.com)
**
** This file is part of the firmware for the Field of Cows USB Modbus I/O
** project (USBModbus)
** 
** USBModbus is free software: you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
** 
** USBModbus is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with USBModbus.  If not, see <http://www.gnu.org/licenses/>.
**
*/

/*--------------------------------------------------------------------------- 
** Includes 
*/
#include <p18cxxx.h>
#include <timers.h>
#include <adc.h>
#include <pwm.h>
#include "USB/usb_function_cdc.h"
#include "modbus.h"

/*--------------------------------------------------------------------------- 
** Defines and Macros 
*/

//
// Define the number of ports that will be allocated as discrete inputs
//
#define 	NUM_DISCRETE_PORTS	2

//
// Define the number of ports that will be configured as coils or outputs
//
#define 	NUM_COIL_PORTS		1

//
// Define whether to use PWM1 (RC2/CCPM1) to control an analogue output
//
#define		USE_PWM1_AO			1

//
// Define whether to use RA0/AN0 as an analogue input
//
#define		USE_AN0				1

//
// Define whether to use RA1/AN1 as an analogue input
//
#define		USE_AN1				1

/*---------------------------------------------------------------------------
** Typedefs 
*/
//
// Define a type to point to a PIC port
//
typedef volatile near unsigned char* PORT_TYPE;

typedef enum
{
  RXTX_IDLE,
  RXTX_START,
  RXTX_ADDRESS1,
  RXTX_ADDRESS2,
  RXTX_FUNCTION1,
  RXTX_FUNCTION2,
  RXTX_DATABUF,
  RXTX_CRC1,
  RXTX_CRC2,
  RXTX_END1,
  RXTX_END2
} RXTX_STATE;

typedef enum
{
  MBFN_READ_COILS = 1,
  MBFN_READ_DISCRETE_INPUTS,
  MBFN_READ_HOLDING_REGISTERS,
  MBFN_READ_INPUT_REGISTERS,
  MBFN_WRITE_SINGLE_COIL,
  MBFN_WRITE_SINGLE_REGISTER,
  MBFN_WRITE_MULTIPLE_COILS = 15,
  MBFN_WRITE_MULTIPLE_REGISTERS
} MODBUS_FUNCTION;	

/*--------------------------------------------------------------------------- 
** Local function prototypes 
*/

/*---------------------------------------------------------------------------
** Data 
*/

//---------------------------------------------------------------------------
// Input definition
//
// The next three variables define the port, tris and lat registers to use
// as digital inputs.
// You need to ensure that the list in each variable is consistent with the
// other variables and that the number of entries matches the
// NUM_DISCRETE_PORTS definition
PORT_TYPE	
discrete_inputs[NUM_DISCRETE_PORTS] = {
	&PORTB,
	&PORTD
};

PORT_TYPE	
discrete_inputs_tris[NUM_DISCRETE_PORTS] = {
	&TRISB,
	&TRISD
};

PORT_TYPE	
discrete_inputs_lat[NUM_DISCRETE_PORTS] = {
	&LATB,
	&LATD
};

//---------------------------------------------------------------------------
// Output definition
//
// The next two variables define the lat and tris registers to use
// as digital outputs.
// You need to ensure that the list in the variables are consistent with each
// other and that the number of entries matches the
// NUM_COIL_PORTS definition
PORT_TYPE
coil_outputs[NUM_COIL_PORTS] = {
	&LATC
};

PORT_TYPE
coil_outputs_tris[NUM_COIL_PORTS] = {
	&TRISC
};

//
// Stores the currently set value of the PWM output if configured
//
#if USE_PWM1_AO
unsigned				pwm_value = 0;
#endif

//--------------------------------------------------------------------------

#pragma idata

#ifdef MODECONTROL_SW
static MODBUS_MODE 		modbus_mode;
#endif

// TX Buffer
RXTX_DATA 				tx_data;
unsigned 				tx_current = 0;
unsigned short 			tx_crc16 = 0xFFFF;
unsigned char			tx_crc = 0;
RXTX_STATE 				tx_state = RXTX_IDLE;

// RX data
RXTX_DATA 				rx_data;
unsigned 				rx_current = 0;
unsigned short 			rx_crc16 = 0xFFFF;
unsigned char			rx_crc = 0;
RXTX_STATE 				rx_state = RXTX_IDLE;
BOOL 					rx_data_available = FALSE;
unsigned char			tx_buf[50];
unsigned 				tx_buf_size = 0;

#pragma code

//-------------------------------------------------------------------------- 
/*! 
** @brief   		Calculate a 16 bit checksum
**
** @param[in]		data	Byte of data to add to checksum
**
** @param[in/out] 	crc		Current crc value
**
*/
void
crc16(
	const unsigned char data,
 	unsigned short* crc
) {
	unsigned char lowCRC;
	unsigned char highCRC;
	unsigned short i;

	*crc = *crc ^(unsigned short)data;
	for (i = 8; i > 0; i--) {
		if (*crc & 0x0001)
			*crc = (*crc >> 1) ^ 0xa001;
		else
			*crc >>= 1;
	}
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Set the modbus protocol mode
** 
** @param[in]	mode	Modbus mode to set, MODE_ASCII or MODE_RTU
** 
*/ 
#ifdef MODECONTROL_SW
void
setMode(
	MODBUS_MODE mode
) {
	modbus_mode = mode;
}
#endif

//--------------------------------------------------------------------------
/*! 
** @brief   	Add an 8 bit value to the transmit queue
** 
** @return    	TRUE
** 
*/ 
BOOL
txByte(
	unsigned char bt
) {
	tx_buf[tx_buf_size++] = bt;
	return TRUE;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Add a 16 bit value to the transmit queue
** 
** @return    	TRUE
** 
*/ 
BOOL
txWord(
	unsigned short sh
) {
	tx_buf[tx_buf_size++] = sh & 0xff;
	tx_buf[tx_buf_size++] = (sh & 0xff00) >> 8;
	return TRUE;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Transmit bytes over serial port
** 
** @return    	TRUE if bytes sent else FALSE
**
** Attempts to transmit all bytes in the transmit buffer
** 
*/ 
BOOL
doTX(
	void
) {
	if (cdc_trf_state != CDC_TX_READY)
		return FALSE;

	putUSBUSART((char*)tx_buf, tx_buf_size);
	tx_buf_size = 0;
	return TRUE;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Attempt to receive a byte from the serial port
** 
** @return    	TRUE if byte received else false
**
** @param[out]	bt		On return contains received byte
** 
*/ 
BOOL
rxByte(
	unsigned char* bt
) {
	static unsigned char buf[100];
	static int count = 0;
	if (count > 0) {
		int i = 0;
		*bt = buf[0];
		for (i = 0; i < (count - 1); ++i) {
			buf[i] = buf[i+1];
		}
		--count;
		return TRUE;
	}
	count = getsUSBUSART((char*)buf, 100);
	if (count > 0) {
		return rxByte(bt);
	}
	return FALSE;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Signal that a Modbus message should be sent
**
** Initialises the transmit state machine to send a message
**
*/
BOOL
sendMessage(
	void
) {
	// Only allow a new message to be sent if not currently sending. In fact, if the
	// caller calls this function when not idle then they have probably corrupted
	// the previous message anyway
	if (tx_state != RXTX_IDLE)
		return FALSE;

	// Initialise the sending of the buffer
	tx_current = 0;
	tx_crc = 0;
	tx_state = RXTX_START;

	return TRUE;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	See if any transmit operation is pending
**
** @return		TRUE if idle else FALSE
**
*/
BOOL
txIdle(
	void
) {
	return (tx_state == RXTX_IDLE);
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Get a pointer to the transmit buffer
**
** @return		Transmit buffer
**
*/
RXTX_DATA*
txData(
	void
) {
	return &tx_data;
}


//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 01 - Read coil status
**
*/
void
handleModbusReadCoils(
	void
) {
	// We have two digital outputs - Spindle FWD and REV. These are on port A, outputs 1 and 2. Just set it
	// up to read all of port A
	unsigned short start = 0;
	unsigned short numCoils = 0;
	unsigned char byteCount = 0;
	unsigned short i = 0;
	unsigned char currentData = 0;
	unsigned char currentBit = 0;

	// The message contains the requested start address and number of inputs
	start = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	numCoils = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);

	// Initialise the output buffer. The first byte in the buffer says how many coils we have read
	tx_data.function = MBFN_READ_COILS;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 1;
	tx_data.dataBuf[0] = 0;
	for (i = 0; i < numCoils; ++i) {
		unsigned char coilBit = (start + i) % 8;
		unsigned char	coil_index = (start + i) / 8;
		if (coil_index < NUM_COIL_PORTS) {
			// Read the relevant bit out of the port B variable. This may not start at bit 0 if the requested
			// address is not aligned on an 8 value boundary
			if (*coil_outputs[coil_index] & (1 << coilBit))
				currentData |= 1 << currentBit;
			++currentBit;
		}
		else {
			// Populate with 0 for unset
			++currentBit;
		}
		if (currentBit > 8) {
			// Filled a whole byte
			tx_data.dataBuf[tx_data.dataLen] = currentData;
			tx_data.dataBuf[0] = tx_data.dataLen++;
			// Reset for next byte
			currentBit = 0;
			currentData = 0;
		}
	}
	// Populate the data we've just read
	if (currentBit > 0) {
		tx_data.dataBuf[tx_data.dataLen] = currentData;
		tx_data.dataBuf[0] = tx_data.dataLen++;
	}
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 02 - Read input status
**
*/
void
handleModbusReadDiscreteInputs(
	void
) {
	// Read digital inputs. In our implementation this reads the inputs in port B and port D
	unsigned short start = 0;
	unsigned short numInputs = 0;
	unsigned char byteCount = 0;
	unsigned short i = 0;
	unsigned char currentData = 0;
	unsigned char currentBit = 0;

	// The message contains the requested start address and number of inputs
	start = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	numInputs = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);

	// Initialise the output buffer. The first byte in the buffer says how many inputs we have read
	tx_data.function = MBFN_READ_DISCRETE_INPUTS;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 1;
	tx_data.dataBuf[0] = 0;
	for (i = 0; i < numInputs; ++i) {
		unsigned char inputBit = (start + i) % 8;
		unsigned char port_index = (start + i) / 8;

		if (port_index < NUM_DISCRETE_PORTS) {
			// Read the relevant bit out of the variable. This may not start at bit 0 if the requested
			// address is not aligned on an 8 value boundary
			if (*discrete_inputs[port_index] & (1 << inputBit))
				currentData |= 1 << currentBit;
			++currentBit;
		}
		else {
			// Populate with 0 for unset
			++currentBit;
		}
		if (currentBit >= 8) {
			// Filled a whole byte
			tx_data.dataBuf[tx_data.dataLen] = currentData;
			tx_data.dataBuf[0] = tx_data.dataLen++;
			// Reset for next byte
			currentBit = 0;
			currentData = 0;
		}
	}
	// Populate the data we've just read
	if (currentBit > 0) {
		tx_data.dataBuf[tx_data.dataLen] = currentData;
		tx_data.dataBuf[0] = tx_data.dataLen++;
	}
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 03 - Read holding registers
**
*/
void
handleModbusReadHoldingRegisters(
	void
) {
	// Holding registers are effectively numerical outputs that can be written to by the host.
	// They can be control registers or analogue outputs.
	// We potientially have one - the pwm output value
	unsigned short start = 0;
	unsigned short numRegisters = 0;
	unsigned char byteCount = 0;
	unsigned short i = 0;
	unsigned char currentData = 0;
	unsigned char currentBit = 0;

	// The message contains the requested start address and number of registers
	start = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	numRegisters = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);

	// Initialise the output buffer. The first byte in the buffer says how many registers we have read
	tx_data.function = MBFN_READ_HOLDING_REGISTERS;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 1;
	tx_data.dataBuf[0] = 0;
	for (i = 0; i < numRegisters; ++i) {
		unsigned short currentData = 0;
#if USE_PWM1_AO
		if (i == 0) {
			// PWM value
			currentData = pwm_value;
		}
#endif
		// Put the data in the buffer
		tx_data.dataBuf[tx_data.dataLen] = (unsigned char)((currentData & 0xff00) >> 8);
		tx_data.dataBuf[tx_data.dataLen + 1] = (unsigned char)(currentData & 0xff);
		tx_data.dataLen += 2;
		tx_data.dataBuf[0] = tx_data.dataLen - 1;
	}
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 04 - Read input registers
**
*/
void
handleModbusReadInputRegisters(
	void
) {
	// Input registers are effectively numerical inputs such as analogue inputs
	// We have 1 or 2 depending on the configuration at the top of this file
	unsigned short start = 0;
	unsigned short numRegisters = 0;
	unsigned char byteCount = 0;
	unsigned short i = 0;
	unsigned char currentBit = 0;

	// The message contains the requested start address and number of registers
	start = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	numRegisters = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);

	// Initialise the output buffer. The first byte in the buffer says how many registers we have read
	tx_data.function = MBFN_READ_INPUT_REGISTERS;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 1;
	tx_data.dataBuf[0] = 0;
	for (i = 0; i < numRegisters; ++i) {
		unsigned short current_data = 0;
#if USE_AN0
		if (i == 0) {
			SetChanADC(ADC_CH0);
			ConvertADC();
			while (BusyADC()) {
			}
			current_data = ReadADC();
		}
#if USE_AN1
		else if (i == 1) {
			SetChanADC(ADC_CH1);
			ConvertADC();
			while (BusyADC()) {
			}
			current_data = ReadADC();
		}
#endif
#endif
		// Put the data in the buffer
		tx_data.dataBuf[tx_data.dataLen] = (unsigned char)((current_data & 0xff00) >> 8);
		tx_data.dataBuf[tx_data.dataLen + 1] = (unsigned char)(current_data & 0xff);
		tx_data.dataLen += 2;
		tx_data.dataBuf[0] = tx_data.dataLen - 1;
	}
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 05 - Write single coil
**
*/
void
handleModbusWriteSingleCoil(
	void
) {
	// Write single coil output - these are on port A
	unsigned short address = 0;
	unsigned short value = 0;
	unsigned char i = 0;
	unsigned char	port_number = 0;
	unsigned char	bit_number = 0;

	// The message contains the requested start address and number of registers
	address = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	value = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);

	// Initialise the output buffer. The first byte in the buffer says how many registers we have read
	tx_data.function = MBFN_WRITE_SINGLE_COIL;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 4;
	// Output data buffer is exact copy of input buffer
	for (i = 0; i < 4; ++i) {
		tx_data.dataBuf[i] = rx_data.dataBuf[i];
	}

	// Calculate the port/bit
	port_number = address / 8;
	bit_number = address % 8;

	// Read the port data
	if (port_number < NUM_COIL_PORTS) {
		if (value) {
			*coil_outputs[port_number] |= 1 << bit_number;
		}
		else {
			*coil_outputs[port_number] &= ~(1 << bit_number);
		}
	}
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 06 - Write single register
**
*/
void
handleModbusWriteSingleRegister(
	void
) {
	// Write single numerical output
	unsigned short address = 0;
	unsigned short value = 0;
	unsigned char i = 0;

	// The message contains the requested start address and number of registers
	address = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	value = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);

	// Initialise the output buffer. The first byte in the buffer says how many registers we have read
	tx_data.function = MBFN_WRITE_SINGLE_REGISTER;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 4;
	// Output data buffer is exact copy of input buffer
	for (i = 0; i < 4; ++i) {
		tx_data.dataBuf[i] = rx_data.dataBuf[i];
	}

	// The only output we support is pwm output
#if USE_PWM1_AO
	if (address == 0) {
		pwm_value = value;
		SetDCPWM1(pwm_value);
	}
#endif
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Handle a modbus error
**
** Sends an error report back to the host
** 
*/
void
handleModbusError(
	void
) {
	// Initialise the output buffer. The first byte in the buffer says how many registers we have read
	tx_data.function = rx_data.function | 0x80;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 0;
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 15 - Write multiple coils
**
*/
void
handleModbusWriteMultipleCoils(
	void
) {
	// Write single numerical output
	unsigned short address = 0;
	unsigned short coils = 0;
	unsigned char byteCount = 0;
	unsigned char i = 0;
	unsigned short count;

	// The message contains the requested start address and number of registers
	address = ((unsigned short)(rx_data.dataBuf[0]) << 8) + (unsigned short)(rx_data.dataBuf[1]);
	coils = ((unsigned short)(rx_data.dataBuf[2]) << 8) + (unsigned short)(rx_data.dataBuf[3]);
	byteCount = rx_data.dataBuf[4];

	// Initialise the output buffer. The first byte in the buffer says how many outputs we have set
	tx_data.function = MBFN_WRITE_MULTIPLE_COILS;
	tx_data.address = SLAVE_ADDRESS;
	tx_data.dataLen = 4;
	tx_data.dataBuf[0] = rx_data.dataBuf[0];
	tx_data.dataBuf[1] = rx_data.dataBuf[1];
	tx_data.dataBuf[2] = rx_data.dataBuf[2];
	tx_data.dataBuf[3] = rx_data.dataBuf[3];

	// Sanity check - ensure we have been given enough values
	count = byteCount * 8;
	if (count < coils) {
		handleModbusError();
		return;
	}

	for (i = 0; i < coils; ++i) {
		unsigned char byte = i / 8;
		unsigned char bt = i % 8;
		unsigned char value = (rx_data.dataBuf[5 + byte] & (1 << bt));

		// Write it to the output port
		if (byte < NUM_COIL_PORTS) {
			unsigned char mask = 1 << (address + i);
			if (value) {
				*coil_outputs[byte] |= mask;
			}
			else {
				*coil_outputs[byte] &= ~mask;
			}
		}
	}
	sendMessage();
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Modbus function 16 - Write multiple registers
**
** Not implemented
** 
*/
void
handleModbusWriteMultipleRegisters(
	void
) {
	handleModbusError();
}

#ifndef MODECONTROL_RTU
//-------------------------------------------------------------------------- 
/*! 
** @brief   	Convert a numerical digit to an ASCII hex character
** 
** @return    	Hex character
**
** @param[in]	num		Digit to convert
** 
*/ 
// Convert a number from 0 to 15 into it's relevant hex char
char
hexDigit(
	char num
) {
	if (num < 10)
		return num + '0';
	else
		return num - 10 + 'A';
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Convert a single ASCII hex digit to a value
** 
** @return     Converted value
**
** @param[in]	hex		ASCII hex value
**
*/ 
char
digitHex(
	char hex
) {
	if ((hex >= '0') && (hex <= '9'))
		return hex - '0';
	else
		return hex - 'A' + 10;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Get the high nibble of an 8 bit value as hex
** 
** @return    	High nibble
**
** @param[in]	8 bit value
**
*/ 
char
highNibble(
	unsigned char num
) {
	return hexDigit((num & 0xf0) >> 4);
}

//--------------------------------------------------------------------------
/*! 
** @brief   	Get the low nibble of an 8 bit value as hex
** 
** @return    	Low nibble
**
** @param[in]	8 bit value
**
*/ 
char
lowNibble(
	unsigned char num
) {
	return hexDigit(num & 0x0f);
}
#endif

//-------------------------------------------------------------------------- 
/*! 
** @brief   	See if there is any data in the receive queue
** 
** @return    	TRUE if data waiting else false
**
** Whenever this function returns true it is assumed that the data will be
** read imminently therefore subsequent calls to this function will return
** FALSE until more data is received
*/ 
BOOL
rxDataAvailable(
	void
) {
	BOOL result = rx_data_available;
	rx_data_available = FALSE;
	return result;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Get the received data queue
** 
** @return    	Pointer to received data
** 
*/ 
RXTX_DATA*
rxData(
	void
) {
	return &rx_data;
}

//--------------------------------------------------------------------------
/*! 
** @brief   	Receive loop for Modbus ASCII protocol
** 
** Continues looping while there is data available. The function returns
** as soon as there is no more data in the receive queue
** 
*/ 
#ifndef MODECONTROL_RTU
void
rxASCII(
	void
) {
	// Try to read a byte
	unsigned char bt;
	while (rxByte(&bt)) {
		if (bt == ':') {
			rx_state = RXTX_ADDRESS1;
			rx_crc = 0;
			rx_data_available = FALSE;
			rx_current = 0;
			rx_data.dataLen = 0;
			continue;
		}
		else if (bt == '\r') {
			// First of two end sequence characters
			if (rx_state != RXTX_DATABUF) {
				// Invalid
				rx_state = RXTX_IDLE;
				continue;
			}
			rx_state = RXTX_END2;
			continue;
		}
		else if (bt == '\n') {
			unsigned char crcCheck = 0;
			unsigned i = 0;

			if (rx_state != RXTX_END2) {
				// Invalid
				rx_state = RXTX_IDLE;
				continue;
			}
			rx_state = RXTX_IDLE;
			// Check the checksum
			// We need to calculate it. The CRC will have been put in the received data. Remove it
			// from there and calculate it
			crcCheck = rx_data.dataBuf[rx_data.dataLen-1];
			rx_data.dataLen -= 1;

			// Now calculate the checksum
			rx_crc = -rx_crc;

			if (rx_crc == crcCheck) {
				// Message OK
				rx_data_available = TRUE;
			}
			continue;
		}
		switch (rx_state) {
			case RXTX_ADDRESS1:
				rx_data.address = digitHex(bt) << 4;
				rx_state = (RXTX_STATE)((int)rx_state + 1);
				rx_crc += bt;
				break;
			case RXTX_ADDRESS2:
				rx_data.address |= digitHex(bt);
				rx_state = (RXTX_STATE)((int)rx_state + 1);
				rx_crc += bt;
				break;
			case RXTX_FUNCTION1:
				rx_data.function = digitHex(bt) << 4;
				rx_state = (RXTX_STATE)((int)rx_state + 1);
				rx_crc += bt;
				break;
			case RXTX_FUNCTION2:
				rx_data.function |= digitHex(bt);
				rx_state = (RXTX_STATE)((int)rx_state + 1);
				rx_crc += bt;
				break;
			case RXTX_DATABUF:
				if ((rx_current % 2) == 0) {
					rx_data.dataBuf[rx_data.dataLen] = digitHex(bt) << 4;
				}
				else {
					// Add the PREVIOUS value to the CRC check. We actually read the
					// transmitted CRC into the data buffer so we don't want to add that
					// to the check
					if (rx_data.dataLen > 0) {
						rx_crc += highNibble(rx_data.dataBuf[rx_data.dataLen-1]);
						rx_crc += lowNibble(rx_data.dataBuf[rx_data.dataLen-1]);
					}
					rx_data.dataBuf[rx_data.dataLen++] += digitHex(bt);
				}
				++rx_current;
				break;
		}
	}
}
#endif

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Check to see if a receive operation has timed-out
** 
** @return    	TRUE if timed out else false
** 
*/ 
BOOL
checkRXTimeout(
	void
) {
	// A return value of true indicates there is a timeout

	// With a 40MHz clock, the timer runs at 10MHz. at 56Kbd 3.5 characters takes about 1/1600th second. If we
	// set a prescale of 64 on the clock then it equates to about 100 clock cycles
	unsigned int tval = ReadTimer0();
	if (tval >= 200) {
		// Reset it
		WriteTimer0(0);
		return TRUE;
	}
	return FALSE;
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Receive loop for Modbus RTU protocol
** 
** Continues looping while there is data available. The function returns
** as soon as there is no more data in the receive queue
** 
*/ 
#ifndef MODECONTROL_ASCII
void
rxRTU(
	void
) {
	int i;
	// Try to read a byte
	unsigned char bt;
	while (rxByte(&bt)) {
		switch (rx_state) {
			case RXTX_IDLE:
			case RXTX_START:
				rx_state = RXTX_ADDRESS1;
				rx_data_available = FALSE;
				rx_current = 0;
				rx_data.dataLen = 0;
				// fall through

			case RXTX_ADDRESS1:
				rx_data.address = bt;
				rx_state = (RXTX_STATE)((int)rx_state + 2);
				// Initialise the CRC
				rx_crc16 = 0xffff;
				crc16(bt, &rx_crc16);
				break;
			case RXTX_FUNCTION1:
				rx_data.function = bt;
				rx_state = (RXTX_STATE)((int)rx_state + 2);
				crc16(bt, &rx_crc16);
				break;
			case RXTX_DATABUF:
				rx_data.dataBuf[rx_data.dataLen++] = bt;
				break;
		}
	}
	if (checkRXTimeout()) {
		// The receive has timed out. If we are currently reading the databuf then it is quite likely
		// that we've got a full message.
		if ((rx_state == RXTX_DATABUF) && (rx_data.dataLen >= 2)) {
			unsigned i;
			unsigned short crcCheck;

			// Finish off our CRC check
			rx_data.dataLen -= 2;
			for (i = 0; i < rx_data.dataLen; ++i) {
				crc16(rx_data.dataBuf[i], &rx_crc16);
			}
			// Now check to see that it matches
			crcCheck = (unsigned short)rx_data.dataBuf[rx_data.dataLen] + ((unsigned short)rx_data.dataBuf[rx_data.dataLen + 1] << 8);
			if (crcCheck == rx_crc16) {
				// Valid message!
				rx_data_available = TRUE;
			}
		}
		rx_state = RXTX_START;
	}
}
#endif

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Transmit an RTU packet over the serial port
** 
** The packet data is contained in tx_data and the current state
** of the send is stored in tx_state
**
** The function returns as soon as the transmit buffer is full but
** the state is maintained for subsequent calls therefore the caller
** must keep calling this function until there is no more data to be
** sent
** 
*/ 
#ifndef MODECONTROL_ASCII
void
txRTU(
	void
) {
	BOOL anySent = TRUE;
	while (anySent) {
		anySent = FALSE;
		switch (tx_state) {
			case RXTX_START:
				// Nothing to send in this protocol
				anySent = TRUE;
				tx_crc16 = 0xFFFF;
				break;
			case RXTX_ADDRESS1:
				anySent = txByte(tx_data.address);
				if (anySent)
					crc16(tx_data.address, &tx_crc16);
				break;
			case RXTX_ADDRESS2:
				// Nothing to send in this protocol
				anySent = TRUE;
				break;
			case RXTX_FUNCTION1:
				anySent = txByte(tx_data.function);
				if (anySent)
					crc16(tx_data.function, &tx_crc16);
				break;
			case RXTX_FUNCTION2:
				// Nothing to send in this protocol
				anySent = TRUE;
				break;
			case RXTX_DATABUF:
				// See if there is any further data to send
				if (tx_current < tx_data.dataLen) {
					// Yes, send a character
					anySent = txByte(tx_data.dataBuf[tx_current]);
					if (anySent) {
						crc16(tx_data.dataBuf[tx_current++], &tx_crc16);
					}
					// Continue round the loop instead of breaking as we don't want to
					// automatically update the status
					continue;
				}
				else {
					tx_state = RXTX_CRC1;
					// Now fall through seeing as we haven't attempted to send anything
				}
			case RXTX_CRC1:
				//anySent = txByte(tx_crc16 & 0xff);
				anySent = txWord(tx_crc16);
				break;
			case RXTX_CRC2:
				//anySent = txByte((tx_crc16 & 0xff00) >> 8);
				// Sent as word above
				anySent = TRUE;
				break;
			case RXTX_END1:
				// Nothing to send in this protocol
				anySent = TRUE;
				break;
			case RXTX_END2:
				// Nothing to send in this protocol
				//anySent = TRUE;
				anySent = doTX();
				break;
		}
		if (anySent) {
			// Update the state to the next stage or if we are at then end then go back to idle
			if (tx_state == RXTX_END2) {
				tx_state = RXTX_IDLE;
			}
			else {
				tx_state = (RXTX_STATE)((int)tx_state + 1);
			}
		}
	}
}
#endif

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Main modbus processing function
**
** This function should be called periodically to service the sending
** and receiving of data
**
*/
void
processModbus(
	void
) {
	if (tx_state != RXTX_IDLE) {
		// Currently sending a buffer
#ifdef MODECONTROL_SW
		if (modbus_mode == MODE_ASCII)
			txASCII();
		else
			txRTU();
#elif MODECONTROL_ASCII
		txASCII();
#else
		txRTU();
#endif
	}

	// See if there is any data to receive
#ifdef MODECONTROL_SW
	if (modbus_mode == MODE_ASCII)
		rxASCII();
	else
		rxRTU();
#elif MODECONTROL_ASCII
	rxASCII();
#else
	rxRTU();
#endif

	// Now see if we've received any complete messages
	if (rxDataAvailable()) {
		// See if the message is for us
		if (rx_data.address == SLAVE_ADDRESS) {
			// Yes. Process the relevant function
			switch (rx_data.function) {
				case MBFN_READ_COILS: {
					handleModbusReadCoils();
					break;
				}
				case MBFN_READ_DISCRETE_INPUTS: {
					handleModbusReadDiscreteInputs();
					break;
				}
				case MBFN_READ_HOLDING_REGISTERS: {
					handleModbusReadHoldingRegisters();
					break;
				}
				case MBFN_READ_INPUT_REGISTERS: {
					handleModbusReadInputRegisters();
					break;
				}
				case MBFN_WRITE_SINGLE_COIL: {
					handleModbusWriteSingleCoil();
					break;
				}
				case MBFN_WRITE_SINGLE_REGISTER: {
					handleModbusWriteSingleRegister();
					break;
				}
				case MBFN_WRITE_MULTIPLE_COILS: {
					handleModbusWriteMultipleCoils();
					break;
				}
				case MBFN_WRITE_MULTIPLE_REGISTERS: {
					handleModbusWriteMultipleRegisters();
					break;
				}
				default: {
					// We don't handle this message. Send an error back
					handleModbusError();
					break;
				}
			}
		}
	}
}

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Transmit an ASCII packet over the serial port
** 
** The packet data is contained in tx_data and the current state
** of the send is stored in tx_state
**
** The function returns as soon as the transmit buffer is full but
** the state is maintained for subsequent calls therefore the caller
** must keep calling this function until there is no more data to be
** sent
** 
*/ 
#ifndef MODECONTROL_RTU
void
txASCII(
	void
) {
	BOOL anySent = TRUE;
	while (anySent) {
		anySent = FALSE;
		switch (tx_state) {
			case RXTX_START:
				anySent = txByte(':');
				break;
			case RXTX_ADDRESS1:
				anySent = txByte(highNibble(tx_data.address));
				if (anySent)
					tx_crc = highNibble(tx_data.address);
				break;
			case RXTX_ADDRESS2:
				anySent = txByte(lowNibble(tx_data.address));
				if (anySent)
					tx_crc += lowNibble(tx_data.address);
				break;
			case RXTX_FUNCTION1:
				anySent = txByte(highNibble(tx_data.function));
				if (anySent)
					tx_crc += highNibble(tx_data.function);
				break;
			case RXTX_FUNCTION2:
				anySent = txByte(lowNibble(tx_data.function));
				if (anySent)
					tx_crc += lowNibble(tx_data.function);
				break;
			case RXTX_DATABUF:
				// See if there is any further data to send
				if (tx_current < (tx_data.dataLen * 2)) {
					// Yes, send a character
					if ((tx_current % 2) == 0) {
						anySent = txByte(highNibble(tx_data.dataBuf[tx_current / 2]));
						if (anySent)
							tx_crc += highNibble(tx_data.dataBuf[tx_current / 2]);
					}
					else {
						anySent = txByte(lowNibble(tx_data.dataBuf[tx_current / 2]));
						if (anySent)
							tx_crc += lowNibble(tx_data.dataBuf[tx_current / 2]);
					}
					if (anySent)
						++tx_current;
					// Continue round the loop instead of breaking as we don't want to
					// automatically update the status
					continue;
				}
				else {
					tx_state = RXTX_CRC1;
					// Now fall through seeing as we haven't attempted to send anything
					tx_crc = -tx_crc;
				}
			case RXTX_CRC1:
				anySent = txByte(highNibble(tx_crc));
				break;
			case RXTX_CRC2:
				anySent = txByte(lowNibble(tx_crc));
				break;
			case RXTX_END1:
				anySent = txByte('\r');
				break;
			case RXTX_END2:
				anySent = txByte('\n');
				break;
		}
		if (anySent) {
			// Update the state to the next stage or if we are at then end then go back to idle
			if (tx_state == RXTX_END2) {
				tx_state = RXTX_IDLE;
			}
			else {
				tx_state = (RXTX_STATE)((int)tx_state + 1);
			}
		}
	}
}
#endif

//-------------------------------------------------------------------------- 
/*! 
** @brief   	Initialise the modbus routines
**
** Initialises the modbus routines as defined in the definitions at the
** top of this file.
**
*/ 
void
initialiseModbus(
	void
) {
	unsigned char	port;

	// Start a timer for handling timeouts
	OpenTimer0(TIMER_INT_OFF & T0_SOURCE_INT & T0_16BIT & T0_PS_1_64);

	// Initialise the pwm output
#if USE_PWM1_AO
	pwm_value = 0;
	// Analogue output is connected to RC2/CCP1. Set this up with the slowest pulse rate.
	// This goes through an opto-isolator then into a capacitor that converts the output into an
	// analogue signal from 0V to VDD
	OpenPWM1(0xff);

	// Start off with the pwm at 0 duty cycle
	SetDCPWM1(0);

	// Timer 2 must be running for PWM to function
	OpenTimer2(TIMER_INT_OFF & T2_PS_1_16 & T2_POST_1_16);
#endif

	// Initialise the input ports
	for (port = 0; port < NUM_DISCRETE_PORTS; ++port) {
		*discrete_inputs_tris[port] = 0xff;
		*discrete_inputs_lat[port] = 0x00;
	}

	// Initialise the output ports
	for (port = 0; port < NUM_COIL_PORTS; ++port) {
		*coil_outputs_tris[port] = 0x00;
		*coil_outputs[port] = 0x00;
	}

	// Initialise the analogue inputs
#ifdef USE_AN1
#ifndef USE_AN0
#define USE_AN0
#endif
	OpenADC(ADC_FOSC_32 &
	        ADC_RIGHT_JUST &
	        ADC_12_TAD,
	        ADC_CH0 & ADC_CH1 &
	        ADC_INT_OFF, 0x0d);
#else
#ifdef USE_AN0
#endif
	OpenADC(ADC_FOSC_32 &
	        ADC_RIGHT_JUST &
	        ADC_12_TAD,
	        ADC_CH0 & ADC_CH1 &
	        ADC_INT_OFF, 0x0e);
#endif
}

