/*!---------------------------------------------------------------------------
** @file	usb_descriptors.c
**
** @brief	USB descriptor content definitions
**
** This file defines the USB descriptors for the device.
**
** The contents of this file are based on the usb_descriptors.c that can
** be found in the CDC serial sample in the Microchip USB framework
**
**---------------------------------------------------------------------------
**
** Copyright 2010 Roy Hopkins (roy_web@fieldofcows.com)
**
** This file is part of the firmware for the Field of Cows USB Modbus I/O
** project (USBModbus)
** 
** USBModbus is free software: you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
** 
** USBModbus is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with USBModbus.  If not, see <http://www.gnu.org/licenses/>.
**
*/
#ifndef __USB_DESCRIPTORS_C
#define __USB_DESCRIPTORS_C
 
/*--------------------------------------------------------------------------- 
** Includes 
*/
#include "./USB/usb.h"
#include "./USB/usb_function_cdc.h"

/*--------------------------------------------------------------------------- 
** Defines and Macros 
*/
#if defined(__18CXX)
#pragma romdata
#endif

/*---------------------------------------------------------------------------
** Data 
*/

//
// Device Descriptor
//
ROM USB_DEVICE_DESCRIPTOR device_dsc = {
    0x12,    						// Size of this descriptor in bytes
    USB_DESCRIPTOR_DEVICE,  		// DEVICE descriptor type
    0x0200,                 		// USB Spec Release Number in BCD format
    CDC_DEVICE,             		// Class Code
    0x00,                   		// Subclass code
    0x00,                   		// Protocol code
    USB_EP0_BUFF_SIZE,      		// Max packet size for EP0, see usb_config.h
    0x04D8,                 		// Vendor ID
    0x000A,                 		// Product ID: CDC RS-232 Emulation Demo
    0x0100,                 		// Device release number in BCD format
    0x01,                   		// Manufacturer string index
    0x02,                   		// Product string index
    0x00,                   		// Device serial number string index
    0x01                    		// Number of possible configurations
};

//
// Configuration 1 Descriptor
//
ROM BYTE configDescriptor1[] = {
    // Configuration Descriptor
    0x09,							// Size of this descriptor in bytes
    USB_DESCRIPTOR_CONFIGURATION,   // CONFIGURATION descriptor type
    67,0,                   		// Total length of data for this cfg
    2,                      		// Number of interfaces in this cfg
    1,                      		// Index value of this configuration
    0,                      		// Configuration string index
    _DEFAULT | _SELF,       		// Attributes, see usb_device.h
    50,                     		// Max power consumption (2X mA)
							
    // Interface Descriptor 
    9,								// Size of this descriptor in bytes
    USB_DESCRIPTOR_INTERFACE,       // INTERFACE descriptor type
    0,                      		// Interface Number
    0,                      		// Alternate Setting Number
    1,                      		// Number of endpoints in this intf
    COMM_INTF,              		// Class code
    ABSTRACT_CONTROL_MODEL, 		// Subclass code
    V25TER,                 		// Protocol code
    0,                      		// Interface string index

    // CDC Class-Specific Descriptors
    sizeof(USB_CDC_HEADER_FN_DSC),
    CS_INTERFACE,
    DSC_FN_HEADER,
    0x10,0x01,

    sizeof(USB_CDC_ACM_FN_DSC),
    CS_INTERFACE,
    DSC_FN_ACM,
    USB_CDC_ACM_FN_DSC_VAL,

    sizeof(USB_CDC_UNION_FN_DSC),
    CS_INTERFACE,
    DSC_FN_UNION,
    CDC_COMM_INTF_ID,
    CDC_DATA_INTF_ID,

    sizeof(USB_CDC_CALL_MGT_FN_DSC),
    CS_INTERFACE,
    DSC_FN_CALL_MGT,
    0x00,
    CDC_DATA_INTF_ID,

    // Endpoint Descriptor
    0x07,
    USB_DESCRIPTOR_ENDPOINT,    	// Endpoint Descriptor
    _EP02_IN,            			// EndpointAddress
    _INTERRUPT,                     // Attributes
    0x08,0x00,                  	// size
    0x02,                       	// Interval

    // Interface Descriptor
    9,								// Size of this descriptor in bytes
    USB_DESCRIPTOR_INTERFACE,       // INTERFACE descriptor type
    1,                      		// Interface Number
    0,                      		// Alternate Setting Number
    2,                      		// Number of endpoints in this intf
    DATA_INTF,              		// Class code
    0,                      		// Subclass code
    NO_PROTOCOL,            		// Protocol code
    0,                      		// Interface string index
    
    // Endpoint Descriptor
    0x07,
    USB_DESCRIPTOR_ENDPOINT,    	// Endpoint Descriptor
    _EP03_OUT,            			// EndpointAddress
    _BULK,                       	// Attributes
    0x40,0x00,                  	// size
    0x00,                       	// Interval

    // Endpoint Descriptor
	0x07,
    USB_DESCRIPTOR_ENDPOINT,    	// Endpoint Descriptor
    _EP03_IN,            			// EndpointAddress
    _BULK,                       	// Attributes
    0x40,0x00,                  	// size
    0x00,                       	// Interval
};

//
// Language code string descriptor
//
ROM struct {
	BYTE bLength;
	BYTE bDscType;
	WORD string[1];
} sd000 = {
	sizeof(sd000),USB_DESCRIPTOR_STRING,{0x0409}
};

//
// Manufacturer string descriptor
//
ROM struct {
	BYTE bLength;
	BYTE bDscType;
	WORD string[25];
} sd001 = {
	sizeof(sd001),USB_DESCRIPTOR_STRING,
	{'M','i','c','r','o','c','h','i','p',' ',
	'T','e','c','h','n','o','l','o','g','y',' ','I','n','c','.'}
};

//
// Product string descriptor
//
ROM struct {
	BYTE bLength;
	BYTE bDscType;
	WORD string[25];
} sd002 = {
	sizeof(sd002),USB_DESCRIPTOR_STRING,
	{'C','D','C',' ','R','S','-','2','3','2',' ',
	'E','m','u','l','a','t','i','o','n',' ','D','e','m','o'}
};

//
// Array of configuration descriptors
//
ROM BYTE *ROM USB_CD_Ptr[] = {
    (ROM BYTE *ROM)&configDescriptor1
};

//
// Array of string descriptors
//
ROM BYTE *ROM USB_SD_Ptr[] = {
    (ROM BYTE *ROM)&sd000,
    (ROM BYTE *ROM)&sd001,
    (ROM BYTE *ROM)&sd002
};

#pragma code
#endif
