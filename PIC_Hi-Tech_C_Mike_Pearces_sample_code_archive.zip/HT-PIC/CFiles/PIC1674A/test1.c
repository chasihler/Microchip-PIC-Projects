//-----------------------------------------------------------------
//                          TEST1.C    
//  Test program for using LCD on a PIC16C74A micro
//  May also test the PSP and some other things...
//
//  NOTE: Designed for 20MHz Clock speed only!!!!
//
//  Author: Michael Pearce
//          Chemistry Department, University of Canterbury
//
//  Started: Thursday 18 Feburary 1999
//
//-----------------------------------------------------------------

#include <pic.h>

static bit LCD_RS	@ ((unsigned)&PORTA*8+4);	// Register select
static bit LCD_EN	@ ((unsigned)&PORTA*8+5);	// Enable
static bit DEBUGOUT	@ ((unsigned)&PORTA*8+0);	// RA0 set for LED Drive Testing


#define	LCD_STROBE	((LCD_EN = 1),(LCD_EN=0))



void lcd_init(void),lcd_puts(const char *s);
void lcd_write(unsigned char c);
void DelayUs(char count);
void DelayMs(char count);
void DelaySec(char count);
void lcd_clear(void);
void lcd_goto(unsigned char pos);




void main (void)
{
	 OPTION=0x00;
	 TRISA=0xCE;    //-- LCD Control pins as output + dbug as output
  TRISB=0xF0;    //-- all LCD data pins as output
  DEBUGOUT=0;
	 lcd_init();
	 lcd_clear();
	 lcd_puts("Hello World");
	 while(1)
	 {
 	 DelaySec(2);
   lcd_clear();
		 DelaySec(2);
   lcd_puts("This is a test");
   DelaySec(2);
   lcd_goto(40);
   lcd_puts("This is line 2");
	 }
}

void lcd_goto(unsigned char pos)
{
	LCD_RS = 0;
	lcd_write(0x80+pos);
}
	


void lcd_clear(void)
{
	LCD_RS = 0;
	lcd_write(0x1);
	DelayMs(2);
}

void lcd_write(unsigned char c)
{
	PORTB = c >> 4;
	LCD_STROBE;
	PORTB = c;
	LCD_STROBE;
 DelayUs(40);
}

void
lcd_init(void)
{
	LCD_RS = 0;	// write control bytes
	DelayMs(15);	// power on delay
	PORTB = 0x3;	// attention!
	LCD_STROBE;
	DelayMs(5);
	LCD_STROBE;
 DelayUs(100);
	LCD_STROBE;
	DelayMs(5);
	PORTB = 0x2;	// set 4 bit mode
	LCD_STROBE;
 DelayUs(40);
	lcd_write(0x28);	// 4 bit mode, 1/16 duty, 5x8 font
	lcd_write(0x08);	// display off
	lcd_write(0x0F);	// display on, blink curson on
	lcd_write(0x06);	// entry mode
}

void lcd_puts(const char * s)
{
	LCD_RS = 1;	// write characters
	while(*s)
		lcd_write(*s++);
}

void DelayUs(char count)
{
	char x;
 DEBUGOUT ^=1;   //-- Toggle the Debug LED
	//-- at 20MHz 5 instruction cycles per us - approx 4 cycles in loop + waste
	//-- thus use count of 1
 for(;count!=0;count--)
	{
		x=1;           
		while(--x!=0);
 }
}

void DelayMs(char count)
{
	for(;count !=0;count--)
	{
		DelayUs(250);
		DelayUs(250);
		DelayUs(250);
		DelayUs(250);
	}
}

void DelaySec(char count)
{
	for(;count !=0;count--)
	{
		DelayMs(250);
		DelayMs(250);
		DelayMs(250);
		DelayMs(250);
	}
}

