//*************************************************************************
//                            V2_CTRL.C
//            Hardware Communication Control Functions V1.00
//                         FOR RCCS PROJECT
//
// Common Communications routines for the RCCS Project.
// Handles basic encoding and decoding of commmands.
// Sends / recieves commands from CommandRead and CommandWrite Functions.
// The above mentioned functions need to be written for the specific hardware
// That you are using - for example you may be using serial from a PC or
// 8 or 4 bit parallel for micros - in each case things are done differently.
//
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 15 March 1999
//
// Controller Used: Any
//
//*************************************************************************
//                         VERSION NOTES
//                      (Latest to oldest...)
//*************************************************************************
//
//-------------------------------------------------------------------------
// Ver 1.00
// 15 March 1999
// Started Common Communications Control Routines for Main/LCD boards
//*************************************************************************

#ifndef V2_CTRL               //-- If not defined then ok to load it

#define V2_CTRL 1.00         //-- Indicate the version number

#ifndef TRUE
 #define TRUE 1
 #define FALSE 0
#endif

 
unsigned char CommandEncode(unsigned char DH,unsigned char DL); // Encode Cmd
unsigned char CommandDecode(unsigned char *DH,unsigned char *DL, unsigned char Cmd);
unsigned char CommandGet(void);   //-- Waits for command, loads, decodes, do
unsigned char CommandSend(unsigned char DH, unsigned char DL); // send a command
unsigned char CommandSendData(unsigned char *Data, unsigned char Bytes); //send data
unsigned char CommandGetData(unsigned char *Data, unsigned char Bytes); //read data


//**** These functions need to be written by YOU *******
unsigned char CommandDo(unsigned char DH, unsigned char DL);//-- Do Command
unsigned char CommandCheck(void);                  //-- Checks for new command
unsigned char CommandRead(void);                   //-- Reads command in
unsigned char CommandWrite(unsigned char Command); //-- Writes command out



//*************************************************************************
//                          CommandEncode
// Combines the Command and Operator ready for transmission
//*************************************************************************
unsigned char CommandEncode(unsigned char DH, unsigned char DL)
{
 #ifdef WDTENABLED
  CLRWDT();
 #endif
 DH &=0xF0;             //-- Ensure High Nibble only
 DL &=0x0F;             //-- Ensure Low Nibble only
 return(DH | DL);       //-- Combine the two nibbles and return
}
//************** END OF CommandEncode

//*************************************************************************
//                          CommandDecode
// Decodes the Command and Operator ready for transmission
//*************************************************************************
unsigned char CommandDecode(unsigned char *DH,unsigned char *DL, unsigned char Cmd)
{
 #ifdef WDTENABLED
  CLRWDT();
 #endif
 *DH=Cmd & 0xF0;      //-- Write Command to DH byte
 *DL=Cmd & 0x0F;      //-- Write Operation to DL byte
 return(TRUE);       //-- Indicate conversion O.K
}
//************** END OF CommandDecode

//*************************************************************************
//                          CommandGet
//      Waits for command, loads it in , decodes it , does it
//*************************************************************************
unsigned char CommandGet(void)
{
 unsigned char *DH,*DL;
 #ifdef WDTENABLED
  CLRWDT();
 #endif
 while(!CommandCheck());             //-- Wait for Command to be received ******** NEED TO ADD TIMEOUT *********
 CommandDecode(DH,DL,CommandRead()); //-- Read in the command and decode it
 return(CommandDo(*DH,*DL));         //-- Do the command and return err code
}
//************** END OF CommandGet

//*************************************************************************
//                        CommandSend
// Sends a command to device - returns the ACK
//*************************************************************************
unsigned char CommandSend(unsigned char DH, unsigned char DL)
{
 #ifdef WDTENABLED
  CLRWDT();
 #endif
 CommandWrite(CommandEncode(DH,DL));    //-- Send command out
 while(!CommandCheck());                //-- Wait for response ********* NEED TO ADD TIMEOUT *******
 return(CommandRead());                 //-- Returns data recieved (ACK)
}
//************** END OF CommandSend

//*************************************************************************
//                        CommandSendData
// Sends specified amount of data to device
//*************************************************************************
unsigned char CommandSendData(unsigned char *Data, unsigned char Bytes)
{
 #ifdef WDTENABLED
  CLRWDT();
 #endif
 do
 {
  CommandWrite(*Data);     //-- Write data to bus
  Data++;                  //-- Point to next byte
  while(!CommandCheck());  //-- Wait for ACK     ************** NEED TO ADD TIMEOUT ************
  switch(CommandGet())
  {
   case ACKNOWLEDGE+ACK_NULL:         //-- ACK NULL or MORE expected
   case ACKNOWLEDGE+ACK_MORE:         //-- until end of data reached
    break;                            //-- Continue as normal

   case ACKNOWLEDGE+ACK_NOMORE:       //-- NOMORE or DONE indicate end of data
   case ACKNOWLEDGE+ACK_DONE:
    if(Bytes > 1) return(2);          //-- if more required return err 2
    break;                            //-- else all done properly

   default:
    return(FALSE);
  }
 }while(--Bytes > 0);
 return(TRUE);
}
//************** END OF CommandSend

//*************************************************************************
//                        CommandGetData
// Reads specified number of bytes storing in *Data - an array
//*************************************************************************
unsigned char CommandGetData(unsigned char *Data, unsigned char Bytes)
{
 #ifdef WDTENABLED
  CLRWDT();
 #endif
 do
 {
  while(!CommandCheck());  //-- Wait for Data  ********* NEED TO ADD TIMEOUT *************
  *Data=CommandRead();     //-- Read in the data
  Data++;                  //-- Point to next byte
  if(Bytes>1)
  {
   CommandWrite(ACKNOWLEDGE+ACK_MORE); //-- Indicate more data to come
  }
  else
  {
   CommandWrite(ACKNOWLEDGE+ACK_NOMORE); //-- Indicate Last byte was sent
  }
 }while(--Bytes > 0);
 return(1);
}
//************** END OF CommandGetData



//**************************************************************************
//     FOLLOWING ARE THE COMMANDS THAT YOU NEED TO WRITE
//
// The following notes will hopefully help you to write the functions for
// your specific system.
// Samples shown will not work without some additional work and are
// specifically for the LCD/Keypad controller V2.00 so will need modification
// for use on PC's etc.
//
// if you copy the functions and then add code as required hopefully it will
// work - have fun!!!
//**************************************************************************

//**************************************************************************
//                           CommandDo
//
// This is the function that decodes the recieved command and does what
// has been requested.
// This is very dependant on what part of the system it is in.
// Hopefully the general idea will be shown by the following example
//
//**************************************************************************
//unsigned char CommandDo(unsigned char DH, unsigned char DL)
//{
// #ifdef WDTENABLED
//  CLEARWDT();
// #endif
// switch(DH)
// {
//  case ACKREQUEST:
//   //-- Acknowledge has been requested - usually to see if system running
//   //-- Write a null acknowledge
//   CommandWrite(ACKNOWLEDGE+ACK_NULL);
//   break;
//
//  case ERROR:
//
//    break;
//
//  case SELCHANNEL:
//    //- if main board then you would select the new channel as "current"
//    //- Then Acknowledge that command has been done
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case SELSLOT:
//    //- if main board then you would select new slot as "current"
//    //- then Acknowledge that command has been done
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case PAUSERUN:
//    //- if main board then you would Pause or Run as selected
//    //- Then acknowledge as Done
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case READWRITE:
//    //- if reading
//    //- if main board then acknowledge as MORE data to come
//    CommandWrite(ACKNOWLEDGE+ACK_MORE);
//    //- then WRITE the data back that was requested.
//
//    //- if writing
//    //- if main board then acknowledge as READY for data
//    CommandWrite(ACKNOWLEDGE+ACK_READY);
//    //- Read in data as required
//    //- Store data in appropiate place
//    //- Last ACK as DONE
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case COMPORT:
//    //- if main board then Send data on to RS-232 Controller and change
//    //- the appropiate registers then ACK as DONE
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case WAITSTARTSTOP:
//    //- if LCD/KEYPAD
//    //- if WAITSTART then Pause the pannel until resume command given
//    //- if WAITRESUME then enable things again
//    break;
//
//  case GETVERSION:
//    //- Acknowledge with ACK_MORE
//    CommandWrite(ACKNOWLEDGE+ACK_MORE);
//    //- Write the Version Strings as required (Basic  to Extended options)
//    break;
//
//  default:                            //- If here then command not recognised
//   CommandWrite(ERROR+ERR_NOSUCHCMD); //- So tell other device about it
//   break;
// }
// return(DH);
//}
//*************** END OF CommandDo


//**************************************************************************
//                          CommandCheck
// This checks if a new command has been recieved, this checks a flag that
// is set by either an interrupt routine or UART hardware or something else.
// Must be rewritten for specif hardware.
//
// The sample given is more for the LCD/KEYPAD interface but should be
// easy to convert for the other parts of the system
//**************************************************************************
//unsigned char CommandCheck(void)
//{
// #ifdef WDTENABLED
//  CLEARWDT();
// #endif
//  //-- For LCD/KEYPAD the PSP interrupt is used to check for new data
//  //-- if new data is avaliable then the routine sets the NewCommand flag
//  //--  Note: the flag must be cleared manually
//
//  if(NewCommand)    //-- Check for new command
//  {
//   NewCommand=0;    //-- Have command so clear the flag
//   return(1);       //-- Return '1' to indicate new data
//  }
//  return(0);        //-- else return 0 to so no new data
//}
//*************** END OF CommandCheck

//**************************************************************************
//                          CommandRead
// Reads the command/data in from the buffer
// This is hardware specific, so would talk to the UART for Serial based
// system or directly to hardware ports for other methods
//
// The sample given is more for the LCD/KEYPAD interface but should be
// easy to convert for the other parts of the system
//**************************************************************************
//unsigned char CommandRead(void)
//{
// #ifdef WDTENABLED
//  CLEARWDT();
// #endif
// //-- If new data is avaliable as indicated by CommandCheck then data is
// //-- avaliable in a buffer somewhere
// //-- in this example we read the PSP register on a PIC16C74
// return(PORTD);
//}
//*************** END OF CommandRead

//**************************************************************************
//                          CommandWrite
// Writes the data to the bus using appropiate timing as defined in V2_CMDS.h
// This is hardware specific, so would talk to the UART for Serial based
// system or directly to hardware ports for other methods
//
// The sample given is more for the LCD/KEYPAD interface but should be
// easy to convert for the other parts of the system
//**************************************************************************
//unsigned char CommandWrite(unsigned char Command)
//{
// #ifdef WDTENABLED
//  CLEARWDT();
// #endif
// //-- The timing is reasonable critical to stop more than one device writing
// //-- to the bus at the same time
// //-- the following example is for a PIC16C74 using the PSP registers and pins

// //-- Disable the PSP read mode
// PSPMODE=0;    //-- disables the PSP mode - back to normal port
// //-- Before enabling ports as output raise the control pins
// PSP_WRITE=1;
// PSP_READ=1;
//
// //-- Check if CS still low - if so then other end is writing
// while(!PSP_CS);  //-- Wait till released - if not then WDT will overflow
//
// //-- But Lower the Chip Select
// PSP_CS=0;
// //-- output the data
// PSP_DATA=Command;
// //-- Change the ports to output
// TRISD=0x00;   //-- Data Port to output
// TRISE=0x00;   //-- Control Port to output
//
//******* CAUSE WRITE DATA *********
//
// DelayUs(DATAVALIDMIN);    //-- Allow data to settle on the bus
// PSP_WRITE=0;              //-- Cause write of data
// DelayUs(WRITEMIN);        //-- Delay for write pulse
// PSP_WRITE=1;              //-- End the write pulse
// DelayUs(DATAGAPMIN);      //-- leave data on bus for a bit longer
//
//
//******* BACK TO NORMAL *****
// TRISD=0xFF;              //-- Back to high impedance mode - removes data
// TRISE=0xFF;              //-- Back to High Impedance mode - disables CS etc
// PSPMODE=1;               //-- Re-enable PSP Mode
//
//}
//*************** END OF CommandWrite


//************************** END OF FILE ********************************
#endif
