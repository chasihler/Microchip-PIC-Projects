//*************************************************************************
//                            V2_CMDS.H
//                          Version 1.00
// Commands for communications between Controller Board /LCD Keypad / Serial
//
// For Version 2.xx Firmware communication/control
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 15 March 1999
//
//*************************************************************************
//                        VERSION INFORMATION
//*************************************************************************
//
//-------------------------------------------------------------------------
// Version 1.00
// 15 March 1999
// First command list and Sub Command options
//*************************************************************************

//*********************** START OF FILE ***********************************
#ifndef V2_CMDS             //-- Go past here if not already loaded
#define V2_CMDS 1.00        //-- Indicate Version number of this file


//------- Things that need to be re-defined in your program file --------
// VERSIONBASIC
// HARDWARETYPE
//-----------------------------------------------------------------------

//-------------------- System Min/Max Delay Values --------------------------
//--- Delays in micro seconds ---
#define DATAVALIDMIN    10         //-- Min us delay for data on bus
#define DATAVALIDMAX    50         //-- Maximum us delay for data on bus
#define DATAGAPMIN       5         //-- Minimum gap between read/acknowledge
#define DATAGAPMAX      25         //-- Maximum gap between read/acknowledge
#define WRITEMIN         1         //-- Minimum write pulse length
#define WRITEMAX         5         //-- Maximum write pulse length
#define READMIN          1         //-- Minimum read pulse (unused in v1.00)
#define READMAX          5         //-- Maximum read pulse (unused in V1.00)
#define WAITMAX        200         //-- Max time waiting for ACK

// Following is the recommended communication timing.
// Please note the devices do not actually read from anything but instead
// write commands to device then device writes a reply. This means that there
// is no actual master on the system - so precautions should be taken no to
// have two devices writing at the same time.
// I recommend having one device set up as a master and the other as a slave.
//
// Here is what I recommend for the communication :
// Master End of things:  --->> SENDING A COMMAND /DATA <<---
//
//   - Raise Write Pulse
//   - Lower Chip Select to device communicating with
//   - WriteCommand to Bus
//   - Delay DATAVALIDMIN
//   - Lower Write Pulse
//   - Delay WRITEMIN
//   - Raise Write Pulse
//   - Delay DATAGAPMIN
//   - Raise Chip Select
//   - Bus to High Impedance State
//   - Wait for Acknowledge no more than WAITMAX
//   - Read data in from buffer
//   - Check for valid ACK signal
//   - Delay DATAGAPMAX
//   - do what ever is needed
//
// Slave End of things:  --->> REPLYING TO A WRITE SIGNAL <<---
//   - Port into INPUT mode - High impedance
//   - Wait for data  (most likely interrupt driven)
//   - Read data from buffer
//   - Wait DATAGAPMAX
//   - Lower Chip Select
//   - Put required ACK command on port
//   - Delay DATAVALIDMIN
//   - Lower Write Pulse
//   - Delay WRITEMIN
//   - Raise Write Pulse
//   - Delay DATAGAPMIN
//   - Raise Chip Select
//   - Back into input mode
//   - Do what is required




//-------------------- HARDWARE TYPE DEFINITIONS ----------------------------
// In your C file use #define HARDWARETYPE then one of the following options
// The basic model has no more information avaliable where the eXtended version
// has more inforamtion avaliable about itself.
//
//#define    HARDWARETYPE
//
#define HW_NOTDEFINED "H00"  //-- Not Defined piece of hardware
#define HW_LCDKEY     "H01"  //-- Basic LCD/KEYPAD
#define HW_LCDKEYX    "H02"  //-- eXtended LCD/KEYPAD
#define HW_MAINCTRL   "H03"  //-- Basic Main Control board
#define HW_MAINCTRLX  "H04"  //-- eXtended Main Control Board
#define HW_SUBCTRL    "H05"  //-- Basic sub controller on Main Control board
#define HW_SUBCTRLX   "H06"  //-- Ext sub controller on Main Control board
#define HW_PC         "H07"  //-- Basic PC Software for driving unit
#define HW_PCX        "H08"  //-- eXtended PC Software for driving unit


//-------------------- COMMUNICATION COMMANDS -------------------------------
// These are the commands sent between each device to indicate and initiate
// the next action to be done.
// The upper 4 bits are the command, the lower 4 bits are command operators

#define ACKREQUEST    0x00  //-- requests that selected controller Acknowledges
#define ACKNOWLEDGE   0x10  //-- The Acknowledge signal for above and other
#define ERROR         0x20  //-- Indicates an error has occured
#define SELCHANNEL    0x30  //-- Selects channel / Indicates selected channel
#define SELSLOT       0x40  //-- Selects Slot /Indicates selected slot
#define PAUSERUN      0x50  //-- Pauses or Runs current selected device
#define READWRITE     0x60  //-- Reads or writes data to/from controller
#define COMPORT       0x70  //-- Selects COM port settings
#define WAITSTARTSTOP 0x80  //-- Force controller to Wait till job finished
#define CTRL_UNUSED1  0x90  //-- Unused in V1.00
#define CTRL_UNUSED2  0xA0  //-- Unused in V1.00
#define CTRL_UNUSED3  0xB0  //-- Unused in V1.00
#define CTRL_UNUSED4  0xC0  //-- Unused in V1.00
#define CTRL_UNUSED5  0xD0  //-- Unused in V1.00
#define CTRL_UNUSED6  0xE0  //-- Unused in V1.00
#define GETVERSION    0xF0  //-- Request Version string from controller

//--------------- Communication COMMAND OPERATORS ----------------------------
// These are the operators that combined with the commands above form a
// complete instruction to to recieving controller
// These are the lower 4 bits of the byte

//----- ACKNOWLEDGE Codes -------
#define ACK_NULL         0x00   //-- Just an ack to a command
#define ACK_MORE         0x01   //-- More Data Follows - get ready for it
#define ACK_NOMORE       0x02   //-- No more data follows - i.e. last item
#define ACK_READY        0x03   //-- Ready to receive data
#define ACK_NOTREADY     0x04   //-- Not ready to receive data
#define ACK_DONE         0x05   //-- Indicates that command has been Done

//----- ERROR Codes -----
#define ERR_UNDETERMINED 0x00   //-- Undefined Error
#define ERR_BADCHKSUM    0x01   //-- Checksum was bad on last recieved string
#define ERR_NOSUCHCMD    0x02   //-- Indicates no command exists on hardware

//----- SELCHANNEL -----
#define CHANNEL0         0x00   //-- Channels 0 to 5 are for 6 channel boards
#define CHANNEL1         0x01
#define CHANNEL2         0x02
#define CHANNEL3         0x03
#define CHANNEL4         0x04
#define CHANNEL5         0x05
#define CHANNEL6         0x06   //-- Channels 0 to 7 are for 8 channel boards
#define CHANNEL7         0x07
#define AUTOTRIGGER      0x06   //-- Is the AutoRetrigger Reg in 6 chan Brds

//----- SELSLOT --------
#define SLOT0            0x00
#define SLOT1            0x01

//------ PAUSERUN ------
#define PAUSESLOT        0x00   //-- Pause Board in selected slot
#define RUNSLOT          0x01   //-- Run Board in selected Slot
#define PAUSECH          0x02   //-- Pause selected channel
#define RUNCH            0x03   //-- Run selected channel
#define PAUSEALL         0x04   //-- Pause All Boards
#define RUNALL           0x05   //-- Run All Boards   (including channels)

//------ READWRITE -----
// Bit 3 - Low is read / High is write
#define READSTART        0x00   //-- Reads 32 bit Start for current selection
#define READSTOP         0x01   //-- Reads 32 bit Stop for current selection
#define READINVERT       0x02   //-- Reads Output Inversion Configuration

#define WRITESTART       0x08   //-- Writes 32 bit Start for current selection
#define WRITESTOP        0x09   //-- Writes 32 bit Stop for current selection
#define WRITEINVERT      0x0A   //-- Writes Output Inversion Configuration

//------ COMPORT ------
// Alters Communication Ports Settings
// By Adding ON/OFF and Baud together you generate the instruction

#define BAUDNOCHANGE     0x00   //-- Use current baud setting
#define BAUD2400         0x01   //-- 2400 Baud
#define BAUD4800         0x02   //-- 4800 Baud
#define BAUD9600         0x03   //-- 9600 Baud

#define COMNOCHANGE      0x00   //-- Use current On/Off state
#define COMON            0x04   //-- Turn PC control via serial ON
#define COMOFF           0x08   //-- Turn PC control via serial OFF
#define COMLOOPBACK      0x0C   //-- Turn Loopback ON for testing only


//------ WAITSTARTSTOP --------
// Starts and stops a wait on remote controller
// If a controller is waiting then no communication occurs until the wait is
// over, This is used during updating of Xilinx of PC Control etc.
//
#define WAITSTATE        0x00   //-- Requests "wait" status of device
#define WAITSTART        0x01   //-- Request a "wait" from controller
#define WAITRESUME       0x02   //-- Resumes normal running - Ends "wait"
#define WAITOK           0x03   //-- Indicates device starting "wait"
#define WAITON           0x04   //-- Indicates that already in "wait"
#define WAITOFF          0x05   //-- Indicates that not "wait"ing

//------ CTRL_UNUSED1 ------
//------ CTRL_UNUSED2 ------
//------ CTRL_UNUSED3 ------
//------ CTRL_UNUSED4 ------
//------ CTRL_UNUSED5 ------
//------ CTRL_UNUSED6 ------

//------ GETVERSION ------
// This gets version information for checking Firmware/Hardware compatability
// The options following allow different version info to be read
// The basic option is required on all versions and from the recieved data
// the other avaliable types can be determined

#define VERSIONGETBASIC     0x00  //-- Gets the basic version string
#define VERSIONGETEXTENDED  0x01  //-- Gets extended Version information string

//-- Others not needed at the moment


//--------------------- VERSIONBASIC STRING LAYOUT --------------------------
// need #defined VERSIONBASIC "Hxx Vx.xx dd-mm-yyyy" in your program
//
// The string contains the hardware type, version number and date.
//    Vx.xx dd-mm-yyyy [NULL]
//    Vx.xx = Firmware Version 0-9 A-Z characters allowed
//    dd-mm-yyyy = Date Version Released/Compiled - all zeros = not completed
//    [NULL] = Null termination of the string for ease of display etc
//----------------------------------------------------------------------------
// Following is an example
// #define VERSIONBASIC "V0.00 00-00-0000"   //-- Undefined version info



//************************* END OF FILE **************************************
#endif
