//**********************************************************************
//                           lcdprint.c
//                          Version 1.00
//
// Some additional printing and scrolling functions for the LCD.
//
//
//**********************************************************************
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 23 Feburary 1999
//
//************** Version Notes and Bug Fixes ****************
// Version 1.00 - 23021999 - lcd_print, lcd_scroll
//
//***********************************************************
#define LINE1         0x00             //-- Start address of first row
#define LINE2         0x40             //-- Start address of second row

void lcd_print(char x,const char *s);  //-- prints const str starting at x
void lcd_prints(char x,char *s);       //-- prints string starting at x

//*************************************************************************
//lcd_print  -  prints const string starting at location x
//*************************************************************************
void lcd_print(char x,const char *s)
{
 lcd_goto(x);
 lcd_puts(s);
}
//****************** END OF lcd_print

//*************************************************************************
//lcd_prints  -  prints string starting at location x
//*************************************************************************
void lcd_prints(char x,char *s)
{
 lcd_goto(x);
	LCD_RS = 1;	 // write characters
 while(*s)
 {
  lcd_write(*s++);
 }
}
//****************** END OF lcd_print


