//*************************************************************************
//                             V2_COMS.C
//                           Version 0.00
//
// Does the communication between the LCD/Keypad and the Main Board
//
// The type of board must be defined to access the appropiate routines.
// This is done by defining one of the following options:
//       BOARD_MAIN
//       BOARD_LCD
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 7 April 1999
//*************************************************************************
//                        VERSION INFORMATION
//*************************************************************************
// Version 0.00   7 April 1999
// LCD Unit Functions:  SendCommand,
//                      SendData,
//                      GetData,
//                      WaitForNewData
//
// Main Unit Functions: WaitForCommand,
//                      DoCommand,
//                      InComing,
//                      OutGoing,
//                      CommandSend
//
//*************************************************************************
#ifndef uchar
 typedef unsigned char uchar;
#endif

//******************************
//        FUNCTION DEFINES
//******************************

//-- General Functions --
uchar DataRead(void);                           //- Does the READ from hardware
uchar DataWrite(uchar Data);                    //- Does the WRITE to hardware
uchar DataWait(uchar TimeOut);                  //- Waits for new data - Timed
uchar WaitForNewData(void);                     //- Waits for new data byte

//-- LCD Board Functions --
#ifdef BOARD_LCD
 uchar SendCommand(uchar Command);               //- Sends the command to main
 uchar SendData(uchar *Data,uchar Num);          //- Sends data string to main
 uchar GetData(uchar *Data,uchar Num);           //- Gets data string from main
 #ifdef DEBUG
  static bit COMSDBGPIN @ (unsigned) (&PORTC)*8+(5);  //-- PORTC 5 ->SP4
 #endif
#endif


//-- Main Board Functions --
#ifdef BOARD_MAIN
 //uchar WaitForCommand(void);                     //- Waits for new command
 uchar InComing(uchar *Data,uchar Num);          //- Reads an incoming string
 uchar OutGoing(uchar *Data,uchar Num);          //- Writes outgoing string
 uchar ReplyCommand(uchar Name,uchar controls);  //- Replys to commands
 //uchar DoCommand(void);                          //- Decodes and does command
 #ifdef DEBUG
  static bit COMSDBGPIN @ (unsigned)(&PORTA)*8+(3);     //-- PORTA 3 -> LOAD
 #endif
#endif


//*************************************************************************
// The Functions are put into pairs.
// First the LCD function and then the the equivalent Main Board function.
// This groups the MASTER routine to the associated SLAVE routine.
// Each groupe will be seperated by a line of ########'s
//*************************************************************************

//#########################################################################

//*************************************************************************
// SendCommand - Sends command to main board - waits for ACK
//*************************************************************************
#ifdef BOARD_LCD
uchar SendCommand(uchar Command)
{
 DataWrite(Command);        //-- Write command to the port
 if(DataWait(TIMEOUTLONG))  //-- Wait for ACK
 {
  //-- Timeout Occured -- Return Error
  return(false);
 }
 return(DataRead());   //-- Return data that was read (Non Zero!!!)
}
#endif
//************* END OF SendCommand

//*************************************************************************
//WaitForCommand  -  Waits for new command from LCD unit, does and ACK's it
//*************************************************************************
#ifdef BOARD_MAIN
/*
uchar WaitForCommand(void)
{
	return(false);
}
*/
#endif
//************* END OF WaitForCommand

//#########################################################################

//*************************************************************************
// SendData - Sends a string to Main board
//*************************************************************************
#ifdef BOARD_LCD
uchar SendData(uchar *Data,uchar Num)
{
 #ifdef PINGPONG
  char PPTemp;
  putch('!');
 #endif
 Num &=0x0F;
 if(SendCommand(_WRITE_ + Num))            //- Start the write sequence
 {
  for(;Num>0;Num--)
  {
   #ifdef PINGPONG
    PPTemp=*Data;
    putch(PPTemp);
   #endif

   DataWrite(*Data);
   Data++;
   if(!WaitForNewData())
   {
    #ifdef PINGPONG
     lcd_print(LINE1,"Err: No Data Rcved");
     Beep(BEEPERROR);
     Pause(1);
    #endif
   }
   switch(DataRead())
   {
    case ACKMORE:
    break;

    case ACKDONE:
     if(Num==0) return(true);   //- If all data sent return OK else return ERR

    default:
     return(false);
   }
  }
 }
 #ifdef PINGPONG
  lcd_print(LINE1,"Err: No ACK Rcvd");
  Beep(BEEPERROR);
  Pause(1);
 #endif

 return(false);  //- If zero reached no ACKDONE or No response then Error
}
#endif
//************* END OF SendData

//*************************************************************************
// InComing - recieves a string from the LCD board
//*************************************************************************
#ifdef BOARD_MAIN
uchar InComing(uchar *Data,uchar Num)
{
 Num &=0x0F;
 for(;Num>0;Num--)
 {
  if(DataWait(TIMEOUTSTD))        //-- wait for New Data
  {                               //-- If timeout then return error
   return(false);
  }
  *Data=DataRead();               //-- Read data into the Buffer
  Data++;                         //-- Point to next buffer location
  if(Num >1)
  {
   DataWrite(ACKMORE);        //-- If need MORE data then request it
  }
  else
  {
   DataWrite(ACKDONE);         //- If all data recieved say all DONE
  }
 }
 return(true);                   //- Indicate Good data to calling function
// return(false);                    //- Should not get here unless error
}
#endif
//************* END OF InComing

//#########################################################################

//*************************************************************************
// GetData - Gets data from the main board
//*************************************************************************
#ifdef BOARD_LCD
uchar GetData(uchar *Data,uchar Num)
{
 Num &=0x0F;
 if(SendCommand(_READ_ + Num))     //-- Send the command
 {

  for(;Num>0;Num--)
  {
   DataWrite(REQUESTDATA);
   if(DataWait(TIMEOUTSTD))
   {
    //- Timeout occured so exit with error
    #ifdef PINGPONG
     lcd_print(LINE1,"Err: ACK Not Received");
     Beep(BEEPERROR);
     Pause(1);
    #endif
    return(false);
   }
   *Data=DataRead();
   Data++;
  }
//  SendCommand(REQUESTEND);
//  if(Num==0) return(true);    //-- If count was completed then return O.K
  return(true);
 }
 return(false);  //-- if any other value / no response then ERROR
}
#endif
//************* END OF GetData

//*************************************************************************
// OutGoing - sends data to the LCD board
//*************************************************************************
#ifdef BOARD_MAIN
uchar OutGoing(uchar *Data,uchar Num)
{
// Num++;                         //- Add one to allow for REQUESTEND
 Num &=0x0F;
 for(;Num>0;Num--)
 {
  if(DataWait(TIMEOUTSTD))        //- wait for new command
  {
   //-- Timeout waiting for write command
   return(false);
  }
  switch(DataRead())            //- Check for correct command
  {
   default:
   case REQUESTDATA:            // Request for more data
    if(Num==0)return(false);    // if Num zero then something wrong!!!
    DataWrite(*Data);           //   else give it some more data!!!
    Data++;                     //- point to next data
    break;

   case REQUESTEND:             //- check for stop of request
    DataWrite(ACKEND);          //- Ack end of data
    if(Num >0) return(false);   //- Incomplete data stream
    return(true);               //- Assume things complete

//   default:                     //- Unrecognised instruction - ERROR!!!
//    return(false);
//     break;
  }
 }
 if(Num==0)return(true);    //- If num is 0 then all done!!
 return(false);             //- Else something wrong!!
}
#endif
//************* END OF OutGoing

//#########################################################################

//*************************************************************************
//
//*************************************************************************
#ifdef BOARD_LCD

#endif
//************* END OF

//*************************************************************************
//
//*************************************************************************
#ifdef BOARD_MAIN

#endif
//************* END OF

//#########################################################################
//           NON MATCHED AND GENERAL FUNCTIONS FOLLOW
//#########################################################################

//*************************************************************************
//WaitForNewData - Waits for data byte to be recieved from remote unit
//*************************************************************************
uchar WaitForNewData(void)
{
 if(DataWait(TIMEOUTSTD))
 {
	 return(false);             //-- If timeout occurs then return false
 }
 return(true);               //-- Else New Data exists
}
//************* END OF WaitForNewData



//*************************************************************************
//DataRead - reads data byte from the hardware port
// This is basically identical on both boards since using the same I.C.
// Need to ensure that data is avaliable first otherwise will just return false
//*************************************************************************
uchar DataRead(void)
{
 if(DataNew)
 {
  DataNew=0;        //-- Clear the flag
  return(PORTD);    //-- Return the data from the PSP port register
 }
 return(false);     //-- If here then no data was avaliable
}
//************* END OF Data Read

//*************************************************************************
// DataWrite - writes data to the hardware port
// This may vary a little between the boards
//*************************************************************************
uchar DataWrite(uchar Data)
{
 uchar TimeOut=0xFF;
 //- Disable PSP Modes -
 PSPMODE=0;


 //- Check if CS held Low - if so wait for it to be released b4 timeout
 while(!PSPCS)
 {
  DelayMs(5);                       //-- 5ms x 255 aprox 1.2 seconds
  if(--TimeOut==0) return(false);   //-- If timeout then return error
 }
 DelayUs(DELAYWAIT);                //-- Min Delay between read/write

 #ifdef DEBUG
  COMSDBGPIN ^=1;                   //-- Toggle pin for debug
 #endif

 //- Configure pins appropiately
 PSPWRITE=1;                       //-- Dont write
 PSPREAD=1;                        //-- Dont read
 PSPCS=0;                          //-- But select the I.C.
 //- lower CS
 TRISE=0x00;                       //-- Set control to output mode
 //- output data to bus
 PORTD=Data;                       //-- Load the data onto the port
 TRISD=0x00;                       //-- Set oport to output
 //- delay to let data settle
 DelayUs(DELAYDATA);              //-- Let the data settle
 //- lower WRITE pin
 PSPWRITE=0;                       //-- Write the data to the device
 //- delay for WRITE
 DelayUs(DELAYWRITE);             //-- Hold pin for a bit
 //- raise the write pin
 PSPWRITE=1;                       //-- Release the Write pin
 //- configure pins as PSP mode again
 TRISD=0xFF;                       //-- Data to input mode
 TRISE=0x0F;                       //-- Control pins to input mode
 PSPMODE=1;                        //-- Turn PSP mode back on

 #ifdef DEBUG
  COMSDBGPIN ^=1;                  //-- Toggle pin for debug
 #endif
 //- return true cause we succeded - maybe!!
 return(true);
}
//************* END OF DataWrite

//*************************************************************************
//DataWait - waits for new data in buffer - with timeout
// This depends on the DataNew Bit being set by the interrupt routine
//*************************************************************************
uchar DataWait(uchar TimeOut)
{
 uchar count;
 while(TimeOut)
 {
  for(count=50;count>0;count--)
  {
   //******* MUST HAVE INTERRUPT ROUTINE SETUP FOR THIS TO WORK ********
   if(DataNew)return(false);     //-- New Data Arrived? if so return false
   DelayMs(10);                 //-- 10ms delay * 50 = 0.5sec resolution
  }
  TimeOut--;
 }
 return(true);       //-- Timeout so return true!!!
}
//************* END OF DataWait

//*************************************************************************
//
//*************************************************************************

//************* END OF
//*************************************************************************
//
//*************************************************************************

//************* END OF
//*************************************************************************
//
//*************************************************************************

//************* END OF
//*************************************************************************
//
//*************************************************************************

//************* END OF


