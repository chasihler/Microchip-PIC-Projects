//***********************************************************************
//                          CardType.h
//
// This file defines the different type of output cards avaliable
// This allows detection of type and lets firmware know if it can talk
// to it or not.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 23 March 1999
//***********************************************************************


//***********************************************************************
//   Layout of the Card Type Byte
//***********************************************************************
// Bit#     7 6 5 4 3 2 1 0
//          O O M T T C C A
//
//     A = Auto Reset Mode
//         0 - No Auto Reset Mode
//         1 - Has Auto Reset Mode
//
//     C = Number of Channels
//         00 - 4 channels
//         01 - 6 channels
//         10 - 8 channels
//         11 - Extended Channels
//
//     T = Type of Board
//         00 - Output only Board - Slave - Master -> Slave Data Xfer only
//         01 - Input only Board  - Slave - Read/Write Data Xfer capable
//         10 - Input/Output Board - Slave - Read/Write Data Capable
//         11 - Extended Board Type
//         Note: Input boards toggle Select line as an interrupt to Master
//
//     M = Mode of Board
//         0 - Basic Mode - Very Dumb board Master has to do everything
//         1 - Smart      - Board has a few more clues than a piece of wood
//
//     O = Output/Input Type
//         00 - All Optical
//         01 - All BNC
//         10 - Mixed Optical/BNC
//         11 - Extended Type
//
//
// NOTE: The Extended (0xFF) mode has not yet been defined but will use more
//       data from bank one to define the details required.
//       I suspect that this project will not get that far
//       If it does someone will be raking in alot of money so I hope they
//       send some my way!!!!
//
//**************************************************************************
#define _AUTO_ON     0x01       //-- 0000 000x
#define _AUTO_0FF    0x00
#define _CH_4        0x00       //-- 0000 0xx0
#define _CH_6        0x02
#define _CH_8        0x04
#define _CH_EXT      0x06
#define _TYPE_OUT    0x00       //-- 000x x000
#define _TYPE_IN     0x08
#define _TYPE_IN_OUT 0x10
#define _TYPE_EXT    0x18
#define _MODE_BASIC  0x00       //-- 00x0 0000
#define _MODE_SMART  0x20
#define _MODE_EXT    0x20
#define _IO_OPTIC    0x00       //-- xx00 0000
#define _IO_BNC      0x40
#define _IO_MIXED    0x80
#define _IO_EXT      0xC0

//***********************************************************************
//  Below are the different types of boards
//***********************************************************************

//--  Original 6 Channel Output Board with Auto Reset
#define OPTIC_OUT_6A  _AUTO_ON + _CH_6 + _TYPE_OUT + _MODE_BASIC + _IO_OPTIC






