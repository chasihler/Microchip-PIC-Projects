//*************************************************************************
//                            V2_LCD.C
//                RCCS LCD/Keypad Driver Version 2.00
//
// Version 2 takes the control away from the main board and gives it to the
// LCD/Keypad unit. This frees up the Controller board resources to handle
// the data transfer and off board communications without worrying about
// Communicating with the user.
//
// The LCD/Keypad controller now has all the Menus programmed into it.
// The communication to the controller board is only done when something
// needs changing.
// (in Version 1.xx comms done continuously for printing and scanning keypad)
//
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 15 March 1999
//
// Controller Used: PIC16C74A
//
//*************************************************************************
//                         VERSION NOTES
//                      (Latest to oldest...)
//*************************************************************************
//
//-------------------------------------------------------------------------
// Ver 2.00
// 15 March 1999
// Version 2.00 Started
// Menu System and Communication system re-developed since V1.xx
//*************************************************************************

#define NOMAINCTRL

#include <pic.h>
#include <stdio.h>
#include <stdlib.h>

//************************ DEFINES *********************************
//#define DEBUG
#define XTAL_FREQ 8MHZ          //-- Crystal speed - for delay routines
#define WDTENABLED              //-- Indicate that WDT is being used
#define MAXEDITX  9             //-- Edit window width

// TRUE/FALSE  ON/OFF
#define TRUE   1
#define FALSE  0
#define ON     1
#define OFF    0

// Warning Beeps
#define BEEPERROR      10,100       //-- 1Khz for 1 second
#define BEEPWRONGKEY   5,25         //-- 2Khz 
#define BEEPHELLO      7,25         //-- 1428Hz for 0.56 Sec

// Bit Address Defining command
#define BITNUM(adr, bit) ((unsigned)(&adr)*8+(bit))  //-- used for port defs

//************************ I/O PORT DEFINES ************************
// lcd stuff defined in the lcd files
//static bit LCD_RS      @ BITNUM(PORTA, 4);    //-- LCD RS Control
//static bit LCD_EN      @ BITNUM(PORTA, 5);    //-- LCD E  Control
//#define LCD_PORT       PORTB                  //-- LCD Data Port (Low 4bits)
static bit BEEP       @ BITNUM(PORTA,0);  //-- Beeper Port
static bit TRISBEEP   @ BITNUM(TRISA,0);  //-- Beeper Tris
static bit PSP_WRITE  @ BITNUM(PORTE,1);  //-- Write pin
static bit PSP_READ   @ BITNUM(PORTE,0);  //-- Read Pin
static bit PSP_CS     @ BITNUM(PORTE,2);  //-- Chip Select Pin
#define PSP_DATA PORTD        // PSP I/O port
#define KEYDATA  PORTB        // PortB 4-7 as input
#define KEYADDRESS PORTC      // Port C0 - 2 as output


//************************ INCLUDES ********************************
#include "delay.h"         //-- Delays required for timing etc
#include "delay.c"
#include "lcd.h"           //-- lcd header files
#include "lcd.c"           //-- lcd functions
#include "lcdprint.c"      //-- Printing/scrolling etc
#include "v2_cmds.h"       //-- Command definitions
#include "v2_ctrl.c"       //-- Command Encoding/decoding etc
#include "v2_keys.c"       //-- Keypad reading/interpretation

//************************ MORE DEFINES ****************************
#define HARDWARETYPE HW_LCDKEY             //-- Hardware Type LCD/Keypad
#define VERSIONBASIC " V2.00 15-03-1999"   //-- Version String
#define MAXCHANNEL AUTOTRIGGER             //-- Last channel is the AutoTrigger
#define MAXSLOT 1                          //-- Only 2 slots in any unit

//************************ GLOBAL VARIABLES ************************
bit TimeOut;                  //-- Indicates if timeout has occured
bit Running;                  //-- Indicates if Selected is running
bit NewCommand=0;             //-- Indicates data in CommandBuff
bit CommandOverflow=0;        //-- Indicates if incoming data has overflowed
unsigned char CommandBuff;    //-- Input Buffer from PSP read
unsigned char Channel;        //-- Current channel number
unsigned char Slot;           //-- Current slot number
unsigned char Invert;         //-- Inversion Settings for entire Slot
unsigned long Start;          //-- Start Time
unsigned long Stop;           //-- Stop Time
unsigned long Width;          //-- Pulse Width (Stop - Start)
union
{
 unsigned long Long;           //-- Working 32bit value
 unsigned char Array[4];       //-- Array overlaying above
}Temp;

//************************ FUNCTIONS *********************************
void check_WDT(void);         //-- Check for WDT Timeout
void init_ports(void);        //-- Initialise I/O Ports
void lcd_init(void);          //-- Get the LCD operational
void init_variables(void);    //-- Set up the variables that need setting up
void load_current(void);      //-- Loads in the current selection data
void save_current(void);      //-- Saves the current data settings
void MainMenu(void);          //-- Main Menu
void EditMenu(void);          //-- Edits current settings
void MoreMenu(void);          //-- Lists a few more options
void DisplayCurrent(void);    //-- shows the current settings
unsigned char YesOrNo(const char *s);  //-- Asks the Yes or No Question 
void NotAvaliable(void);      //-- Indicates option not avaliable
unsigned long Edit(const char *str, unsigned long time); //-- edit time
void SelectInversion(void);   //-- Selects inversion for current channel
void Beep(unsigned char Rate,unsigned char Num); //-- Makes a sound


//*************************************************************************
//                             main
//*************************************************************************
void main(void)
{
 check_WDT();             //-- Check for WDT Timeout
 init_ports();            //-- Initialise I/O Ports
 lcd_init();              //-- Get the LCD operational
 lcd_cursor(CURSOR_OFF);  //-- Turn LCD Cursor OFF
 init_variables();        //-- Set up the variables that need setting up
 load_current();          //-- Get current settings from controller

 while(1)
 {
  MainMenu();         //-- Go to the main menu
 }
}
//***************** END OF main

//*************************************************************************
//                          GetInterrupt
//*************************************************************************
interrupt void GetInterrupt(void)
{
	if(PSPIF)   
	{
		//-- PSP Read or write has taken place - only check for writes --
		PSPIF=0;
		if(IBF)
		{
			//-- If new data has arrived transfer it to the Buffer
			if(NewCommand)
			{
				//-- Overflow has occured --
				CommandOverflow=1;
			}
			else
			{
			 NewCommand=1;
			 CommandBuff=PORTD;
			}
		}
	}
}
//***************** END OF GetInterrupt

//*************************************************************************
//                             check_WDT
//                       Check for WDT Timeout
//*************************************************************************
void check_WDT(void)
{
 TimeOut=0;
 if(!TO)
 {
  //-- TIMEOUT OCCURED !!!!
  TimeOut=1;
  Beep(BEEPERROR);  
 }
 CLRWDT();
}
//***************** END OF check_WDT

//*************************************************************************
//                          init_ports
//                      Initialise I/O Ports
//*************************************************************************
void init_ports(void)
{
 CLRWDT();
 
 TRISA=0x0F;       //-- RS and E LCD control pis as output
 TRISB=0xF0;       //-- 0-3 LCD output 4-7 Keypad input
 TRISC=0xF8;       //-- 0-2 as output rest as inputs
 TRISD=0xFF;       //-- PSP as input initially
 TRISE=0xFF;       //-- PSP Ctrls as input initially

 INTCON=0x00;      //-- Clear all interrupts
 PIE1=0x00;
 PIE2=0x00;
 PSPIE=1;          //-- Enable PSP Interrupt
 PEIE=1;           //-- Enable Peripheral Interrupts
 GIE=1;            //-- Enable Global Interrupts
 
}
//***************** END OF init_ports

//*************************************************************************
//                          init_variables
//            Set up the variables that need setting up
//*************************************************************************
void init_variables(void)
{
 CLRWDT();
 if(TimeOut)
 {
  lcd_clear();
  lcd_print(LINE1,"TIMEOUT OCCURRED!");
  lcd_print(LINE2,"Display was RESET!");
  Pause(2);
 }
 lcd_clear();
 lcd_print(LINE1,"HSPG Firmware V2.00");
 lcd_print(LINE2,"M.O.Pearce 1999");
 Pause(1);
 lcd_print(LINE1,"SYSTEM INITIALISING");
 lcd_print(LINE2,"Please wait....");
 Beep(BEEPHELLO);
 Pause(1);
 Running=0;                           //-- Not Running
 Channel=0;                           //-- Current channel number
 Slot=0;                              //-- Current slot number
 Start=0L;                            //-- Start Time
 Stop=0L;                             //-- Stop Time
 Width=0L;                            //-- Pulse Width (Stop - Start)
 Temp.Long=0L;                        //-- Working 32bit value
}
//***************** END OF init_variables

//*************************************************************************
//                          load_current
// loads in the currently selected information from the controller board
//*************************************************************************
void load_current(void)
{
	CLRWDT();

#ifdef MAINCTRLOK
 CommandSend(SELCHANNEL,Channel);   //-- Select channel to read from
 CommandSend(SELSLOT,Slot);         //-- Select channel to write to
 CommandSend(READWRITE,READSTART);  //-- Read the start word

 //-- Read in the 4 bytes required
 CommandGetData(Temp.Array,4);      //-- 4 bytes need to be read

 //-- Store in Start
 Start=Temp.Long;
 CommandSend(READWRITE,READSTOP);

 //-- Read in the 4 Bytes required
 CommandGetData(Temp.Array,4);      //-- 4 bytes need to be read

 //-- Store in Stop
 Stop=Temp.Long;

 //-- Create the Width from the read data --
 if(Stop>=Start)                    //-- Check for valid width
 {
  Width=Stop-Start;                 //-- Calculate the width;
 }
 else
 {
  Width=0;                          //-- if not valid set to zero
  Stop=Start;                       //-- and make Stop = Start
 }

 //-- Read in the Inversion info
 CommandSend(READWRITE,READINVERT);
 //-- read in the byte
 CommandGetData(&Invert,1);
#endif
}
//***************** END OF load_current

//*************************************************************************
//                          save_current
// saves the current settings to the controller board
//*************************************************************************
void save_current(void)
{
	CLRWDT();
#ifdef MAINCTRLOK
 CommandSend(SELCHANNEL,Channel);   //-- Select channel to read from
 CommandSend(SELSLOT,Slot);         //-- Select channel to write to

 CommandSend(READWRITE,WRITESTART);  //-- Write the start word
 //-- Convert Start Data
 Temp.Long=Start;
 //-- Write the 4 bytes required
 CommandSendData(Temp.Array,4);      //-- 4 bytes need to be written

 CommandSend(READWRITE,WRITESTOP);
 //-- Create the Stop Data from Width and Start
 Stop=Start+Width;
 //--  Convert Stop Data
 Temp.Long=Stop;
 //-- Write in the 4 Bytes required
 CommandSendData(Temp.Array,4);      //-- 4 bytes need to be written

 //-- Write the Inversion info 
 CommandSend(READWRITE,WRITEINVERT);
 //-- Write in the byte
 CommandSendData(&Invert,1);
#endif
}
//***************** END OF save_current


//*************************************************************************
//                           MainMenu
// Main Menu
//*************************************************************************
void MainMenu(void)
{
 CLRWDT();                                //-- Reset the WDT
 lcd_clear();                             //-- Clear the display
 lcd_print(LINE1,"MAIN:");                //-- Menu type = MAIN
 lcd_print(LINE2,"Slot# CH# EDIT MORE");  //-- Show the options
 DisplayCurrent();                        //-- Update the current settings
 switch(getch())                          //-- Get input from the user
 {
  case OPTION0:
   //-- Selected Slot# option
   if(++Slot > MAXSLOT) Slot=0;
   load_current();                     //-- When Changing slot update Inversion
   break;

  case OPTION1:
   //-- Selected CH# option
   if(++Channel > MAXCHANNEL) Channel=0;
   break;

  case OPTION2:
   //-- Selected EDIT option
   EditMenu();
   NotAvaliable();
   break;

  case OPTION3:
   //-- Selected MORE option
   MoreMenu();
   break;

  default:
   //-- Invalid Key - Ignore
   break;
 }
}
//***************** END OF MainMenu

//*************************************************************************
//                          EditMenu
// Edits current selection
//*************************************************************************
void EditMenu(void)
{
 char NotDone=TRUE;
	CLRWDT();
 while(NotDone)
 {
  lcd_clear();
	 lcd_print(LINE1,"EDIT:");
  DisplayCurrent();                 //-- Display the current settings
  lcd_print(LINE2,"Loading Data...");
  load_current();                   //-- Read selected data from main board
  Start=Edit("Start:",Start);
  Width=Edit("Width:",Width);
  if(YesOrNo("Save New Settings?"))
  {
	  save_current();
	  NotDone=FALSE;
  }
  else
  {
   if(!YesOrNo("Try Again?"))
   {
    NotDone=FALSE;
   }
  }
	} 
}
//***************** END OF EditMenu

//*************************************************************************
//                          MoreMenu
// Lists a few more options
//*************************************************************************
void MoreMenu(void)
{
 char NotDone=TRUE;
 CLRWDT();
 while(NotDone)
 {
  lcd_clear();
  lcd_print(LINE1,"MORE:");
  DisplayCurrent();                 //-- Display the current settings
  if(Running==TRUE)                 //-- Show opposite to current Run State
  {
	  lcd_print(LINE2,"Pause");
  }
  else
  {
   lcd_print(LINE2,"Run  ");
  }
  lcd_print(LINE2+6,"Inv Coms Reset");
  switch(getch())                        //-- Get input from user --
  {
   case CLR:
    //-- Escape out of menu
    NotDone=FALSE;
    break;

   case OPTION0:
    //-- Pause Mode Selected --
    if(Running==FALSE)
    {
	    Running=TRUE;
    }
    else
    {
     Running=FALSE;
    }
//    CommandSend(PAUSERUN+PAUSESLOT);  //##################################
    break;

   case OPTION1:
    //-- Change Inversion of current channel --
    SelectInversion();
    break;

   case OPTION2:
    //-- Coms Setup Menu Requested --
    NotAvaliable();
    break;

   case OPTION3:
    //-- RESET of system requested --
    if(YesOrNo("** RESET SYSTEM? **"))
    {
     //-- Write Reset command to main board
     lcd_print(LINE2,"Sorry Can't do that!");
     Pause(1);
    }
    break;

   default:
    //-- Invalid Key - Ignore
    break;
  }
 }
}
//***************** END OF MoreMenu
//**********************************************************************
//                      DisplayCurrent
//    Shows the current settings on the top line of the LCD
//    Values are decoded from Running/Slot/Channel/Invert Variables
//**********************************************************************
void DisplayCurrent(void)
{
	unsigned char temp[3];
 CLRWDT();
 //******** Running or Paused **********
 if(Running)
 {
	 lcd_print(LINE1+6,"R");
 }
 else
 {
	 lcd_print(LINE1+6,"P");
 }
 //******** Inverted or Non Inverted ********
 if((Invert>>Channel) & 0x01)
 {
	 lcd_print(LINE1+8,"I");
 }
 else
 {
	 lcd_print(LINE1+8,"N");
 }
 //******** Slot Number ********
 lcd_print(LINE1+10,"SLOT");
 sprintf(temp,"%d",Slot);
 putch(temp[0]);
 
 //******** Channel Number ********
 lcd_print(LINE1+16,"CH");
 sprintf(temp,"%d",Channel);
 putch(temp[0]);
}
//**************** END OF DisplayCurrent

//*************************************************************************
//                           YesOrNo
// Asks for a yes or no Response to Question String
//*************************************************************************
unsigned char YesOrNo(const char *s)
{
	lcd_clear();
	lcd_print(LINE1,s);
	lcd_print(LINE2,"      YES  NO");
	while(1)
	{
		switch(getch())
		{
	  case OPTION1:   //-- If YES pressed
	  	return(TRUE);            //-- Return TRUE
	  	
	  case OPTION2: 
   	return(FALSE);             //-- Any other key returns FALSE

   default:
    Beep(BEEPWRONGKEY);
   break;
		}
	}
 return(FALSE);
}
//***************** END OF YesOrNo


//*************************************************************************
//                         NotAvaliable
//   Indicates that option selected is not currently avaliable
//*************************************************************************
void NotAvaliable(void)
{
	lcd_clear();
	lcd_print(LINE1,"Sorry.....");
	lcd_print(LINE2,"Option not avaliable");
	Pause(1);
}
//***************** END OF NotAvaliable


//*************************************************************************
//                               Edit
//                  Edits the 32bit time value in ns
//*************************************************************************
unsigned long Edit(const char *str, unsigned long time)
{
	char string[12];             //-- Temp storage for the string
	char count=0;
	char x=0,AllDone=TRUE;
	Temp.Long=time;
	lcd_print(LINE2,"                    "); //-- Clear the Line
	lcd_print(LINE2,str);        //-- Print the option
	sprintf(string,"%010lu",time); //-- Convert the time 
	
 //-- Put the zeros in place of space --
 //-- Have to do since sprintf does not do it!! --
 while(string[count]!=0)
 {
	 if(string[count]==' ') string[count]='0';
	 count++;
 }
	
 lcd_cursor(CURSOR_ON);
 //******* EDIT THE NUMBER ON THE DISPLAY *******
 while(AllDone)
 {
 	lcd_prints(LINE2+8,string);  //-- Display the time
	 lcd_print(LINE2+18,"ns");    //-- Indicate that it is ns
  lcd_goto(LINE2+8+x);         //-- Move Cursor to current position
  count=getch();
  switch(count)
  {
	  case CLR:
	   AllDone=FALSE;
	   break;
	   
	  case ENTER:
	   AllDone=FALSE;
	   break;
	   
	  case LEFT:
	   if(x>0)x--;
	   break;
	   
	  case RIGHT:
	   if(x<MAXEDITX) x++;
	   break;

   default:
    if(count>='0' && count <='9')
    {
     string[x]=count;
     if(string[0] >='4')
     {
	     string[0] = '4';
	     //-- Find value that does not cause overflow to occur
	     CLRWDT();
	     while(atol(string) > 0)   //-- if not a negative number then overflow 
	     {
		     string[x]--;             //-- find value that does not cause overflow
		     if(string[x] < '0')
		     {
			     string[x]='0';
			     break;
		     }
	     }
     }
     if(x<MAXEDITX) x++;
    }
    break;
  }
 }
	//** IF ENTER PRESSED THEN RETURN NEW VALUE ELSE RETURN OLD **
 lcd_cursor(CURSOR_OFF);  //-- Turn LCD Cursor OFF
 if(count==ENTER)          //-- Check if Enter or ESC
	{
		
  return(atol(string));    //-- Return the new value
	}
 return(Temp.Long);        //-- Return the old value
}
//***************** END OF Edit


//*************************************************************************
//                         SelectInversion
//          Toggles the inversion for the current channel
//*************************************************************************
void SelectInversion(void)
{
 unsigned char temp;
 temp= 0x01 << Channel;   //-- Select Bit to toggle
 Invert ^= temp;          //-- Toggle the bit by XORing the data 
}
//***************** END OF SelectInversion


//*************************************************************************
//                             Beep
// Makes a beep at Rate for Num of times.
// --> Rate is in 0.1ms lots
// --> Num is in units 10 times the Rate
// e.g.  Rate = 10 Num = 100  --> 1ms=1000Hz for 1ms x 10 x Num = 1 Second
// Needs BEEP and TRISBEEP Defined 
//*************************************************************************
void Beep(unsigned char Rate,unsigned char Num)
{
	char count,count1;
	BEEP=1;      
	
	while(Num--)
	{
		for(count1=0;count1<10;count1++)
		{
	 	CLRWDT();
	  TRISBEEP=0;
	  for(count=0;count<50;count++)
	  {
	   DelayUs(Rate);
	  }
	  TRISBEEP=1;
	  for(count=0;count<50;count++)
	  {
	   DelayUs(Rate);
	  }
		}
	}
}
//***************** END OF Beep


//*************************************************************************
//
//*************************************************************************

//***************** END OF


//*************************************************************************
//
//*************************************************************************

//***************** END OF


//**************************************************************************
//                           CommandDo
//
// This is the function that decodes the recieved command and does what
// has been requested.
// This is very dependant on what part of the system it is in.
// Hopefully the general idea will be shown by the following example
//
//**************************************************************************
unsigned char CommandDo(unsigned char DH, unsigned char DL)
{
// #ifdef WDTENABLED
//  CLEARWDT();
// #endif
// switch(DH)
// {
//  case ACKREQUEST:
//   //-- Acknowledge has been requested - usually to see if system running
//   //-- Write a null acknowledge
//   CommandWrite(ACKNOWLEDGE+ACK_NULL);
//   break;
//
//  case ERROR:
//
//    break;
//
//  case SELCHANNEL:
//    //- if main board then you would select the new channel as "current"
//    //- Then Acknowledge that command has been done
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case SELSLOT:
//    //- if main board then you would select new slot as "current"
//    //- then Acknowledge that command has been done
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case PAUSERUN:
//    //- if main board then you would Pause or Run as selected
//    //- Then acknowledge as Done
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case READWRITE:
//    //- if reading
//    //- if main board then acknowledge as MORE data to come
//    CommandWrite(ACKNOWLEDGE+ACK_MORE);
//    //- then WRITE the data back that was requested.
//
//    //- if writing
//    //- if main board then acknowledge as READY for data
//    CommandWrite(ACKNOWLEDGE+ACK_READY);
//    //- Read in data as required
//    //- Store data in appropiate place
//    //- Last ACK as DONE
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case COMPORT:
//    //- if main board then Send data on to RS-232 Controller and change
//    //- the appropiate registers then ACK as DONE
//    CommandWrite(ACKNOWLEDGE+ACK_DONE);
//    break;
//
//  case WAITSTARTSTOP:
//    //- if LCD/KEYPAD
//    //- if WAITSTART then Pause the pannel until resume command given
//    //- if WAITRESUME then enable things again
//    break;
//
//  case GETVERSION:
//    //- Acknowledge with ACK_MORE
//    CommandWrite(ACKNOWLEDGE+ACK_MORE);
//    //- Write the Version Strings as required (Basic  to Extended options)
//    break;
//
//  default:                            //- If here then command not recognised
//   CommandWrite(ERROR+ERR_NOSUCHCMD); //- So tell other device about it
//   break;
// }
 return(1);
}
//*************** END OF CommandDo


//**************************************************************************
//                          CommandCheck
// This checks if a new command has been recieved, this checks a flag that
// is set by either an interrupt routine or UART hardware or something else.
// Must be rewritten for specif hardware.
//
// The sample given is more for the LCD/KEYPAD interface but should be
// easy to convert for the other parts of the system
//**************************************************************************
unsigned char CommandCheck(void)
{
 CLRWDT();
 //-- For LCD/KEYPAD the PSP interrupt is used to check for new data
 //-- if new data is avaliable then the routine sets the NewCommand flag
 //--  Note: the flag must be cleared manually
 if(NewCommand)    //-- Check for new command
 {
  NewCommand=0;    //-- Have command so clear the flag
  return(1);       //-- Return '1' to indicate new data
 }
 return(0);        //-- else return 0 to so no new data
}
//*************** END OF CommandCheck

//**************************************************************************
//                          CommandRead
// Reads the command/data in from the buffer
// This is hardware specific, so would talk to the UART for Serial based
// system or directly to hardware ports for other methods
//
// The sample given is more for the LCD/KEYPAD interface but should be
// easy to convert for the other parts of the system
//**************************************************************************
unsigned char CommandRead(void)
{
 CLRWDT();
//-- If new data is avaliable as indicated by CommandCheck then data is
//-- avaliable in a buffer somewhere
//-- in this example we read the PSP register on a PIC16C74
 return(CommandBuff);
}
//*************** END OF CommandRead

//**************************************************************************
//                          CommandWrite
// Writes the data to the bus using appropiate timing as defined in V2_CMDS.h
// This is hardware specific, so would talk to the UART for Serial based
// system or directly to hardware ports for other methods
//
// The sample given is more for the LCD/KEYPAD interface but should be
// easy to convert for the other parts of the system
//**************************************************************************
unsigned char CommandWrite(unsigned char Command)
{
 CLRWDT();
//-- The timing is reasonable critical to stop more than one device writing
//-- to the bus at the same time
//-- the following example is for a PIC16C74 using the PSP registers and pins

//-- Disable the PSP read mode
 PSPMODE=0;    //-- disables the PSP mode - back to normal port
//-- Before enabling ports as output raise the control pins
 PSP_WRITE=1;
 PSP_READ=1;

 //-- Check if CS still low - if so then other end is writing or forcing HOLD
 while(!PSP_CS);  //-- Wait till released - if not then WDT will overflow

 //-- But Lower the Chip Select
 PSP_CS=0;
 //-- output the data
 PSP_DATA=Command;
 //-- Change the ports to output
 TRISD=0x00;   //-- Data Port to output
 TRISE=0x00;   //-- Control Port to output

//******* CAUSE WRITE DATA *********

 DelayUs(DATAVALIDMIN);    //-- Allow data to settle on the bus
 PSP_WRITE=0;              //-- Cause write of data
 DelayUs(WRITEMIN);        //-- Delay for write pulse
 PSP_WRITE=1;              //-- End the write pulse
 DelayUs(DATAGAPMIN);      //-- leave data on bus for a bit longer


//******* BACK TO NORMAL *****
 TRISD=0xFF;              //-- Back to high impedance mode - removes data
 TRISE=0xFF;              //-- Back to High Impedance mode - disables CS etc
 PSPMODE=1;               //-- Re-enable PSP Mode

 return(0);
}
//*************** END OF CommandWrite


