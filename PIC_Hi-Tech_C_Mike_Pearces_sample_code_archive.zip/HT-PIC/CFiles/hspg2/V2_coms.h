//*************************************************************************
//                             V2_COMS.H
//                           Version 0.00
//
// Header file for V2_COMS.C
// Does the communication between the LCD/Keypad and the Main Board
//
// The type of board must be defined to access the appropiate routines.
// This is done by defining one of the following options:
//       BOARD_MAIN
//       BOARD_LCD
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 8 April 1999
//*************************************************************************
//                        VERSION INFORMATION
//*************************************************************************
// Version 0.00   7 April 1999
//   Initial Defines that are required
//
//*************************************************************************
#ifndef V2_COMS_H
#define V2_COMS_H
//XXXXXXXXXXXXXXXXXXXXXXXXX START OF FILE XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

//---- COMMON DEFINES ----

//-- BASE COMMANDS --
#define _ERR_    0x00      //- Error Message
#define _ACK_    0x10      //- Acknowledge Signal
#define _WRITE_  0x20      //- Write Data Command
#define _READ_   0x30      //- Read Data Command
#define _SELCH_  0x40      //- Select Channel Command
#define _SELSLT_ 0x50      //- Select Slot command
#define _SELINV_ 0x60      //- Select Invert State
#define _MODE_   0x70      //- MODE swiches - Pause, Run, Reset Etc
#define _REQU_   0x80      //- Request Something
#define _DTYPE_  0x90      //- Defines the type of data being read or written


//-- COMBINED COMMANDS --

//-- Ack commands
#define ACKNULL        _ACK_ | 5       //- A basic Ack to signal
#define ACKMORE        _ACK_ | 1       //- Ack but more data is expected
#define ACKDONE        _ACK_ | 2       //- Ack task done
#define ACKEND         _ACK_ | 3       //- Ack no more data expected
#define ACKERROR       _ACK_ | 4       //- Ack but error occured

//-- Request commands
#define REQUESTDATA    _REQU_ | 1      //- Requests a byte from the slave
#define REQUESTEND     _REQU_ | 2      //- End of the request


//-- Data Types --
#define DTYPESTART     _DTYPE_ | 1     //- Start Time Data
#define DTYPESTOP      _DTYPE_ | 2     //- Stop Time Data
#define DTYPEINVERT    _REQU_  | 3     //- Inversion Data

//-- MODEs --
#define MODERUN        _MODE_  | 1     //- RUN the system
#define MODEPAUSE      _MODE_  | 2     //- PAUSE the system
#define MODERESET      _MODE_  | 3     //- DO HARD RESET OF SYSTEM



//************************** TIMING ************************
// Timeout in 50ms lots.
#ifdef DEBUG
 #define TIMEOUTSHORT    10       //-- Debug Delays are LONG
 #define TIMEOUTSTD      50       //-- Debug Delays are LONG
 #define TIMEOUTLONG    100       //-- Debug Delays are LONG
#else
 #define TIMEOUTSHORT    10       //--  10 x 50ms = 500ms
 #define TIMEOUTSTD      50       //--  20 x 50ms = 1 Second
 #define TIMEOUTLONG    100       //-- 100 x 50mS = 5 Seconds
#endif

#ifdef DEBUG
 #define DELAYDATA        10    //-- us for data to settle
 #define DELAYWRITE       10    //-- us for write pulse
 #define DELAYWAIT        20    //-- Wait time between read/write cycles
#else
 #define DELAYDATA        10    //-- us for data to settle
 #define DELAYWRITE       10    //-- us for write pulse
 #define DELAYWAIT       100    //-- Wait time between read/write cycles us
#endif



//************** VARIABLES **********
bit DataNew = 0;                   //- Indicates if new data avaliable
unsigned char ReadWriteMode=0;



//XXXXXXXXXXXXXXXXXXXXXXXXXXX END OF FILE XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#endif