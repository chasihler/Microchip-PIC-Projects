//*************************************************************************
//                             PONG.C
//                           Version 0.00
//
// Test program for the MAIN BOARD to use the V2_COMS routines
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 14 April 1999
//*************************************************************************
//                        VERSION INFORMATION
//*************************************************************************
// Version 0.00   14 April 1999
//
//
//*************************************************************************
#define XTAL_FREQ 8MHZ          //-- Crystal speed - for delay routines

#include <pic.h>
#include <string.h>

#ifndef TRUE
 #define TRUE 1
 #define FALSE 0
#endif
#ifndef true
 #define true TRUE
 #define false FALSE
#endif

// Bit Address Defining command
#define BITNUM(adr, bit) ((unsigned)(&adr)*8+(bit))  //-- used for port defs

static bit BEEP       @ BITNUM(PORTA,0);  //-- Beeper Port
static bit TRISBEEP   @ BITNUM(TRISA,0);  //-- Beeper Tris
static bit PSPREAD    @ BITNUM(PORTE,0);  //-- Read Pin
static bit PSPWRITE   @ BITNUM(PORTE,1);  //-- Write pin
static bit PSPCS      @ BITNUM(PORTE,2);  //-- Chip Select Pin
static bit TRIS_R     @ BITNUM(TRISE,0);  //-- Read tris
static bit TRIS_W     @ BITNUM(TRISE,1);  //-- Write tris
static bit TRIS_CS    @ BITNUM(TRISE,2);  //-- Chip Select tris

static bit LOAD       @ BITNUM(PORTA,3);
static bit TRIS_LOAD  @ BITNUM(TRISA,3);


#define PSP_DATA PORTD        // PSP I/O port
#define KEYDATA  PORTB        // PortB 4-7 as input
#define KEYADDRESS PORTC      // Port C0 - 2 as output

//************************ INCLUDES ********************************
#include "delay.h"         //-- Delays required for timing etc
#include "delay.c"

#define  BOARD_MAIN          // Tell v2_coms what functions to use
#include "v2_coms.h"       //  Communication control between LCD And Main
#include "v2_coms.c"



//************************* Messages ********************************
char Buffer[21];
const char Blank[]="                    ";     //-- Blank Line

//*************************************************************************
void ReceiveMessage(char num);
void SendMessage(char num);
void InitVariables(void);
void InitPorts(void);
void Beep(unsigned char Rate,unsigned char Num); //-- Makes a sound

//*************************************************************************
//                         main
//*************************************************************************
void main (void)
{
 char data;
 InitVariables();
 InitPorts();
 while(1)
 {
  if(WaitForNewData())
  {
   LOAD=1;
   data=DataRead();
   switch(data & 0xF0)
   {
    case _WRITE_:
     strcpy(Buffer,Blank);
     DataWrite(ACKNULL);
     ReceiveMessage(data & 0x0F);       //-- Read the message
      break;

    case _READ_:
     DataWrite(ACKMORE);
     SendMessage(data & 0x0F);          //-- Send the Message
     break;
   }
   LOAD=0;
  }
  else
  {
   //--- Error Occured - Set ERROR Pin
   for(data=0;data<100;data++)
   {
    LOAD=1;
    DelayUs(10);
    LOAD=0;
    DelayUs(10);
   }
  }
 }
}
//*************** END OF main

//*************************************************************************
//                         SendMessage
//*************************************************************************
void SendMessage(char num)
{
 OutGoing(Buffer,num);
}
//*************** END OF SendMessage

//*************************************************************************
//                         ReceiveMessage
//*************************************************************************
void ReceiveMessage(char num)
{
 InComing(Buffer,num);
}
//*************** END OF ReceiveMessage

//*************************************************************************
//                   InitVariables
//*************************************************************************
void InitVariables(void)
{

}
//*************** END OF InitVariables
//*************************************************************************
//                         InitPorts
//*************************************************************************
void InitPorts(void)
{
 TRISA=0x0F;       //-- RS and E LCD control pis as output
 TRISB=0xF0;       //-- 0-3 LCD output 4-7 Keypad input
 TRISC=0xF8;       //-- 0-2 as output rest as inputs
 TRISD=0xFF;       //-- PSP as input initially
 TRISE=0xFF;       //-- PSP Ctrls as input and PSP ON initially

 INTCON=0x00;      //-- Clear all interrupts
 PIE1=0x00;
 PIE2=0x00;
 PSPIE=1;          //-- Enable PSP Interrupt
 PEIE=1;           //-- Enable Peripheral Interrupts
 GIE=1;            //-- Enable Global Interrupts
 ADCON1=0xFF;      //-- Set Port E pins to DIGITAL mode!!!!

 LOAD=0;
 TRIS_LOAD=0;      //-- Debug pin to indicate if timeout etc

}
//*************** END OF InitPorts

//*************************************************************************
//                          GetInterrupt
//*************************************************************************
interrupt void GetInterrupt(void)
{
	if(PSPIF)
	{
		//-- PSP Read or write has taken place - only check for writes --
		PSPIF=0;
		if(IBF)
		{
   DataNew=1;
		}
	}
}
//***************** END OF GetInterrupt



//*************************************************************************
//                         SendMessage
//*************************************************************************


//*************** END OF SendMessage


