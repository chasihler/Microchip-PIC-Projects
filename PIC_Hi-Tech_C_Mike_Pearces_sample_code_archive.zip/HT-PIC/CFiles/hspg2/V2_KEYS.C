//*****************************************************************************
//                         V2_KEYS.C
//                        Version 1.00
//
// This is the keyboard interface for the LCD KEYPAD Controller for
// use in the HSPG project.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 17 March 1999
//
//*****************************************************************************
//                     VERSION INFORMATION
//*****************************************************************************
// Version 1.00
// 17 March 1999
// Functions getch(), kbhit(), keyread(), and keydecode() are written
//
//*****************************************************************************

//*****************************************************************************
//                      OUTSIDE REQUIREMENTS
//*****************************************************************************
// KEYDATA needs to be defined as the PORT the data is read on
// the TRIS register for the port needs to be set as input.
//         (on LCDKEY-001 this is PORTB 4 - 7)
//
// KEYADDRESS needs to be defined as the PORT the address is written to.
// The tris reg for this port need to be set as outputs.
//         (on LCDKEY-001 this is PORTC 0 - 2)
//
//*****************************************************************************

#define KEYDELAY 10            //-- Keyboard reading/scanning delay
#define KEYDEBOUNCE 20         //-- 20ms keyboard debounce between getch's
#define KEYBEEP  2,1           //-- Short Sharp beep
//*****************************************************************************
//                         KEY DEFINITIONS
//                      FOR HSPG V2 Configuration
//*****************************************************************************
#define OPTION0 'a'            //-- Left Option Key
#define OPTION1 'b'            //-- Left Centre Option Key
#define OPTION2 'c'            //-- Right Center Option Key
#define OPTION3 'd'            //-- Right option Key

#define ENTER   'E'            //-- Enter Key
#define CLR     'C'            //-- Clr/Esc Key
#define UP      'U'            //-- Up Arrow
#define DOWN    'D'            //-- Down Arrow
#define LEFT    'L'            //-- Left Arrow
#define RIGHT   'R'            //-- Right Arrow

//*****************************************************************************
//                             GLOBALS
//*****************************************************************************
unsigned char KEYOLD=0;                 //-- holds previous key pressed

//*****************************************************************************
//                            FUNCTIONS
//*****************************************************************************
//unsigned char getch(void);
//unsigned char kbhit(void);
unsigned char KeyDecode(unsigned char keycode);
unsigned char KeyRead(void);
bit KeyBeep=0;

extern void Beep(unsigned char Rate,unsigned char Num); //-- Makes a sound


//*****************************************************************************
//                              getch
//*****************************************************************************
unsigned char getch(void)
{
 unsigned char NotDone=TRUE,temp;
 while(NotDone)                //-- Wait for key to be pressed
 {
  temp=KeyRead();
  if(temp != KEYOLD)
  {
   KEYOLD=temp;                //-- Ensure last key has been released
   if(KEYOLD)                  //-- But don't exit till have new key
   {
    NotDone=FALSE;             //-- accept input
    if(KeyBeep)                //-- Beep if allowed to
    {
     Beep(KEYBEEP);
    }
    else
    {
      DelayMs(KEYDEBOUNCE);    //-- KeyDebounce between key presses
    }
   }
  }
  CLRWDT();
 }

 return(KeyDecode( KeyRead() ) ); //-- Return the key code for it
}
//**************** END OF getch

//*****************************************************************************
//                               kbhit
//*****************************************************************************
/*
unsigned char kbhit(void)
{
 return(KeyRead());
}
*/
//**************** END OF kbhit

//*****************************************************************************
//                               KeyRead
//Does a scan of the keypad and returns the resulting keycode or 0 if nothing
//*****************************************************************************
unsigned char KeyRead(void)
{
	unsigned char line,data,result=0;
	for(line=0;line <8;line++)
	{
  CLRWDT();
		KEYADDRESS=line;      //-- Set Row To Read
		DelayUs(KEYDELAY);
		data = KEYDATA;       //-- Read in the data
		data = data >> 4;     //-- shift to lower nibble
		data	|= 0xF0;         //-- set upper nibble to 1s
		data ^= 0xFF;         //-- invert everything (XOR)
		if(data !=0)
		{
			result=line<<4;      //-- Put line number in upper nibble
			result+=data;        //-- Put Row Bit pattern in lower nibble
			line=10;             //-- Terminate the loop
		}
	}
	return(result);        //-- Return the result
}
//******************* END OF KeyRead

//*****************************************************************************
//                                KeyDecode
//        Takes the keycode and translates it to its ASCII value
//*****************************************************************************
char KeyDecode(char keycode)
{
 CLRWDT();
 switch(keycode)
 {
  case 1:
   return(DOWN);         //-- Down Arrow
  case 2:
   return(ENTER);        //-- Enter Key
  case 4:
   return('0');          //-- Zero
  case 8:
   return(CLR);          //-- Clear

  case 17:
   return(RIGHT);        //-- Right Arrow
  case 18:
   return('3');          //-- 3
  case 20:
   return('2');          //-- 2
  case 24:
   return('1');          //-- 1

  case 33:
   return(LEFT);         //-- Left Arrow
  case 34:
   return('6');          //-- 6
  case 36:
   return('5');          //-- 5
  case 40:
   return('4');          //-- 4

  case 49:
   return(UP);           //-- Up Arrow
  case 50:
   return('9');          //-- 9
  case 52:
   return('8');          //-- 8
  case 56:
   return('7');          //-- 7

  case 81:
   return(OPTION0);          //-- Left Option Key
  case 82:
   return(OPTION1);          //-- Left-Center Option Key
  case 84:
   return(OPTION2);          //-- Right-Center Option Key
  case 88:
   return(OPTION3);          //-- Right Option Key

  case 95:
   if(KeyBeep)               //-- All Function keys Toggles the Beep Option
   {
    KeyBeep=0;
   }
   else
   {
    KeyBeep=1;
   }
   return(0xFF);             //-- all Option keys hit.

  default:
   break;
 }
 return(0);
}
//******************* END OF KeyDecode
