//*************************************************************************
//                             PING.C
//                           Version 0.00
//
// Test program for the LCD to use the V2_COMS routines
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 14 April 1999
//*************************************************************************
//                        VERSION INFORMATION
//*************************************************************************
// Version 0.00   14 April 1999
//
//
//*************************************************************************
#define XTAL_FREQ 8MHZ          //-- Crystal speed - for delay routines
#define PINGPONG                //-- Turn Debuging on

// Warning Beeps
extern void Beep(unsigned char Rate,unsigned char Num); //-- Makes a sound
#define BEEPERROR      10,100       //-- 1Khz for 1 second
#define BEEPNEXT       5,25         //-- 2Khz
#define BEEPHELLO      7,25         //-- 1428Hz for 0.56 Sec
#define BEEPNOTE       6,10

char Blank[]="                    ";     //-- Blank Line


#include <pic.h>
#include <string.h>
#include <stdio.h>

#ifndef TRUE
 #define TRUE 1
 #define FALSE 0
#endif
#ifndef true
 #define true TRUE
 #define false FALSE
#endif

// Bit Address Defining command
#define BITNUM(adr, bit) ((unsigned)(&adr)*8+(bit))  //-- used for port defs

static bit BEEP       @ BITNUM(PORTA,0);  //-- Beeper Port
static bit TRISBEEP   @ BITNUM(TRISA,0);  //-- Beeper Tris
static bit PSPREAD    @ BITNUM(PORTE,0);  //-- Read Pin
static bit PSPWRITE   @ BITNUM(PORTE,1);  //-- Write pin
static bit PSPCS      @ BITNUM(PORTE,2);  //-- Chip Select Pin
static bit TRIS_R     @ BITNUM(TRISE,0);  //-- Read tris
static bit TRIS_W     @ BITNUM(TRISE,1);  //-- Write tris
static bit TRIS_CS    @ BITNUM(TRISE,2);  //-- Chip Select tris

#define PSP_DATA PORTD        // PSP I/O port
#define KEYDATA  PORTB        // PortB 4-7 as input
#define KEYADDRESS PORTC      // Port C0 - 2 as output

//************************ INCLUDES ********************************
#include "delay.h"         //-- Delays required for timing etc
#include "delay.c"
#include "lcd.h"           //-- lcd header files
#include "lcd.c"           //-- lcd functions
#include "lcdprint.c"      //-- Printing/scrolling etc

#define  BOARD_LCD          // Tell v2_coms what functions to use
#include "v2_coms.h"       //  Communication control between LCD And Main
#include "v2_coms.c"

#include "v2_keys.c"       //-- Keypad reading/interpretation


//************************* Messages ********************************
char Buffer[21];
const char Message[4][21] =
{
 "Ping Pong       ",
 "      Pong Ping ",
 "Testing 1. 2. 3.",
 "1234567890123456"
};



//*************************************************************************

void SendMessage(char num);
void ReceiveMessage(char num);
void InitVariables(void);
void InitPorts(void);
void Beep(unsigned char Rate,unsigned char Num); //-- Makes a sound

//*************************************************************************
//                         main
//*************************************************************************
void main (void)
{
 unsigned char count=0,counter=0;
 InitVariables();
 InitPorts();
 lcd_init();
 lcd_clear();
 lcd_print(LINE1,"PING PONG.......");
 lcd_print(LINE2,"...Test Routines");
 Beep(BEEPHELLO);
 Pause(2);
 while(1)
 {
	 Beep(BEEPNEXT);
  lcd_clear();                        //-- Clear the display
  lcd_print(LINE1,Message[count]);    //-- Display message that will be sent
  SendMessage(count);                 //-- Send the Message
  lcd_print(LINE2,"Recieving....");   //-- Indicate reading the data
  ReceiveMessage(count);              //-- Read the message back
  lcd_print(LINE2,Blank); //-- Clear the line
  lcd_print(LINE2,Buffer);            //-- Display the data that was recieved
  Pause(2);
  count++;
  if(count >=4)
  {
	  count=0;
	  lcd_clear();
	  counter++;
   Beep(BEEPNOTE);	  
   sprintf(Buffer,"%u\0",counter);
   lcd_print(LINE1,"Counter =>");
   lcd_puts(Buffer);
   Pause(1);
  }	  
 }
}
//*************** END OF main

//*************************************************************************
//                       SendMessage
//*************************************************************************
void SendMessage(char num)
{
 char Size;
 Size=strlen(Message[num]);    //-- Get size of string to recieve
 if(Size >16)Size=16;
 strcpy(Buffer,Message[num]);
 #ifdef PINGPONG
  lcd_print(LINE1,Blank);
  lcd_print(LINE1,">");
 #endif
 SendData(Buffer,Size);  //-- Send the data

}
//*************** END OF SendMessage

//*************************************************************************
//                       ReceiveMessage
//*************************************************************************
void ReceiveMessage(char num)
{
 char Size;
 Size=strlen(Message[num]);    //-- Get size of string to recieve
 if(Size >16)Size=16;
 strcpy(Buffer,Blank);         //-- Clear the buffer
 GetData(Buffer,Size);         //-- Recieve the data
}
//*************** END OF ReceiveMessage

//*************************************************************************
//                   InitVariables
//*************************************************************************
void InitVariables(void)
{

}
//*************** END OF InitVariables
//*************************************************************************
//                         InitPorts
//*************************************************************************
void InitPorts(void)
{
 TRISA=0x0F;       //-- RS and E LCD control pis as output
 TRISB=0xF0;       //-- 0-3 LCD output 4-7 Keypad input
 TRISC=0xF8;       //-- 0-2 as output rest as inputs
 TRISD=0xFF;       //-- PSP as input initially
 TRISE=0xFF;       //-- PSP Ctrls as input and PSP ON initially

 INTCON=0x00;      //-- Clear all interrupts
 PIE1=0x00;
 PIE2=0x00;
 PSPIE=1;          //-- Enable PSP Interrupt
 PEIE=1;           //-- Enable Peripheral Interrupts
 GIE=1;            //-- Enable Global Interrupts
 ADCON1=0xFF;      //-- Set Port E pins to DIGITAL mode!!!!

}
//*************** END OF InitPorts

//*************************************************************************
//                          GetInterrupt
//*************************************************************************
interrupt void GetInterrupt(void)
{
	if(PSPIF)
	{
		//-- PSP Read or write has taken place - only check for writes --
		PSPIF=0;
		if(IBF)
		{
   DataNew=1;
		}
	}
}
//***************** END OF GetInterrupt

//*************************************************************************
//                             Beep
// Makes a beep at Rate for Num of times.
// --> Rate is in 0.1ms lots
// --> Num is in units 10 times the Rate
// e.g.  Rate = 10 Num = 100  --> 1ms=1000Hz for 1ms x 10 x Num = 1 Second
// Needs BEEP and TRISBEEP Defined
//*************************************************************************
void Beep(unsigned char Rate,unsigned char Num)
{
	char count,count1;
	BEEP=1;

	while(Num--)
	{
		for(count1=0;count1<10;count1++)
		{
	 	CLRWDT();
	  TRISBEEP=0;
	  for(count=0;count<50;count++)
	  {
	   DelayUs(Rate);
	  }
	  TRISBEEP=1;
	  for(count=0;count<50;count++)
	  {
	   DelayUs(Rate);
	  }
		}
	}
}
//***************** END OF Beep


//*************************************************************************
//
//*************************************************************************


//*************** END OF
//*************************************************************************
//
//*************************************************************************


//*************** END OF
//*************************************************************************
//
//*************************************************************************


//*************** END OF
//*************************************************************************
//
//*************************************************************************


//*************** END OF
//*************************************************************************
//
//*************************************************************************


//*************** END OF
//*************************************************************************
//
//*************************************************************************


//*************** END OF
//*************************************************************************
//
//*************************************************************************


//*************** END OF

