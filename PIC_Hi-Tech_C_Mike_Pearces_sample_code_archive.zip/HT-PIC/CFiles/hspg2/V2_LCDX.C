//*************************************************************************
//                            V2_LCD.C
//                RCCS LCD/Keypad Driver Version 2.00
//
// Version 2 takes the control away from the main board and gives it to the
// LCD/Keypad unit. This frees up the Controller board resources to handle
// the data transfer and off board communications without worrying about
// Communicating with the user.
//
// The LCD/Keypad controller now has all the Menus programmed into it.
// The communication to the controller board is only done when something
// needs changing.
// (in Version 1.xx comms done continuously for printing and scanning keypad)
//
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 15 March 1999
//
// Controller Used: PIC16C74A                                   
//
//*************************************************************************
//                         VERSION NOTES
//                      (Latest to oldest...)
//*************************************************************************
//
//-------------------------------------------------------------------------
// Ver 2.00
// 15 March 1999
// Version 2.00 Started
// Menu System and Communication system re-developed since V1.xx
//*************************************************************************
#define DEBUG
//#define NOMAINCTRL
#define MAINCTRLOK

#include <pic.h>
#include <stdio.h>
#include <stdlib.h>

//************************ DEFINES *********************************
//#define DEBUG
#define XTAL_FREQ 8MHZ          //-- Crystal speed - for delay routines
#define WDTENABLED              //-- Indicate that WDT is being used
#define MAXEDITX  9             //-- Edit window width
#define MAXCHANNEL 6            //-- Have 7 channels - 6 output 1 control

// TRUE/FALSE  ON/OFF
#define TRUE   1
#define FALSE  0
#define ON     1
#define OFF    0
#ifndef true
 #define true  TRUE
 #define false FALSE
#endif

// Warning Beeps
#define BEEPERROR      10,100       //-- 1Khz for 1 second
#define BEEPWRONGKEY   5,25         //-- 2Khz
#define BEEPHELLO      7,25         //-- 1428Hz for 0.56 Sec

// Error Messages
#define E_COMMAND   1               //-- Comand Failure
#define E_SLOT      2               //-- Slot Sel Error
#define E_CHANNEL   3               //-- Channel Sel Error
#define E_INVERT    4               //-- Invert Command R/W error
#define E_STOP      5               //-- Stop Command R/W error
#define E_START     6               //-- Start Command R/W error
#define E_SRINVERT  7               //-- Send/Recieve Invert Data Error
#define E_SRSTOP    8               //-- Send/Rcv Stop Data Error
#define E_SRSTART   9               //-- Send/Rcv Start data error
#define E_NOMAIN   10               //-- No Main Board Detected

// Bit Address Defining command
#define BITNUM(adr, bit) ((unsigned)(&adr)*8+(bit))  //-- used for port defs

//************************ I/O PORT DEFINES ************************
// lcd stuff defined in the lcd files
//static bit LCD_RS      @ BITNUM(PORTA, 4);    //-- LCD RS Control
//static bit LCD_EN      @ BITNUM(PORTA, 5);    //-- LCD E  Control
//#define LCD_PORT       PORTB                  //-- LCD Data Port (Low 4bits)
static bit BEEP       @ BITNUM(PORTA,0);  //-- Beeper Port
static bit TRISBEEP   @ BITNUM(TRISA,0);  //-- Beeper Tris

static bit PSPREAD    @ BITNUM(PORTE,0);  //-- Read Pin
static bit PSPWRITE   @ BITNUM(PORTE,1);  //-- Write pin
static bit PSPCS      @ BITNUM(PORTE,2);  //-- Chip Select Pin
static bit TRIS_R     @ BITNUM(TRISE,0);  //-- Read tris
static bit TRIS_W     @ BITNUM(TRISE,1);  //-- Write tris
static bit TRIS_CS    @ BITNUM(TRISE,2);  //-- Chip Select tris

#define PSP_DATA PORTD        // PSP I/O port
#define KEYDATA  PORTB        // PortB 4-7 as input
#define KEYADDRESS PORTC      // Port C0 - 2 as output


//************************ INCLUDES ********************************
#include "delay.h"         //-- Delays required for timing etc
#include "delay.c"
#include "lcd.h"           //-- lcd header files
#include "lcd.c"           //-- lcd functions
#include "lcdprint.c"      //-- Printing/scrolling etc
//#include "v2_cmds.h"       //-- Command definitions
//#include "v2_ctrl.c"       //-- Command Encoding/decoding etc

#define  BOARD_LCD          // Tell v2_coms what functions to use
#include "v2_coms.h"       //  Communication control between LCD And Main
#include "v2_coms.c"

#include "v2_keys.c"       //-- Keypad reading/interpretation

//************************ MORE DEFINES ****************************
//#define HARDWARETYPE HW_LCDKEY             //-- Hardware Type LCD/Keypad
//#define VERSIONBASIC " V2.00 15-03-1999"   //-- Version String
//#define MAXCHANNEL AUTOTRIGGER             //-- Last channel is the AutoTrigger
#define MAXSLOT 1                          //-- Only 2 slots in any unit

//************************ GLOBAL VARIABLES ************************
bit TimeOut;                  //-- Indicates if timeout has occured
bit Running;                  //-- Indicates if Selected is running
bit NewCommand=0;             //-- Indicates data in CommandBuff
bit CommandOverflow=0;        //-- Indicates if incoming data has overflowed
unsigned int  OverFlowCount;  //-- Internal overflow counter
unsigned char CommandBuff;    //-- Input Buffer from PSP read
unsigned char Channel;        //-- Current channel number
unsigned char Slot;           //-- Current slot number
unsigned char Invert;         //-- Inversion Settings for entire Slot
unsigned long Start;          //-- Start Time
unsigned long Stop;           //-- Stop Time
unsigned long Width;          //-- Pulse Width (Stop - Start)
union
{
 unsigned long Long;           //-- Working 32bit value
 unsigned char Array[4];       //-- Array overlaying above
}Temp;

//************************ FUNCTIONS *********************************
void check_WDT(void);         //-- Check for WDT Timeout
void init_ports(void);        //-- Initialise I/O Ports
void lcd_init(void);          //-- Get the LCD operational
void init_variables(void);    //-- Set up the variables that need setting up
void load_current(void);      //-- Loads in the current selection data
void save_current(void);      //-- Saves the current data settings
void MainMenu(void);          //-- Main Menu
void EditMenu(void);          //-- Edits current settings
void MoreMenu(void);          //-- Lists a few more options
void DisplayCurrent(void);    //-- shows the current settings
unsigned char YesOrNo(const char *s);  //-- Asks the Yes or No Question
void NotAvaliable(void);      //-- Indicates option not avaliable
unsigned long Edit(const char *str, unsigned long time); //-- edit time
void SelectInversion(void);   //-- Selects inversion for current channel
void Beep(unsigned char Rate,unsigned char Num); //-- Makes a sound
void ShowError(char Error);
void CheckForMain(void);      //-- checks if main board responding

//*************************************************************************
//                             main
//*************************************************************************
void main(void)
{
 check_WDT();             //-- Check for WDT Timeout
 init_ports();            //-- Initialise I/O Ports
 lcd_init();              //-- Get the LCD operational
 lcd_cursor(CURSOR_OFF);  //-- Turn LCD Cursor OFF
 init_variables();        //-- Set up the variables that need setting up
 CheckForMain();          //-- Checks if main board responding
 load_current();          //-- Get current settings from controller

 while(1)
 {
  MainMenu();         //-- Go to the main menu
 }
}
//***************** END OF main

//*************************************************************************
//                          GetInterrupt
//*************************************************************************
interrupt void GetInterrupt(void)
{
	if(PSPIF)
	{
		//-- PSP Read or write has taken place - only check for writes --
		PSPIF=0;
		if(IBF)
		{
   DataNew=1;
		}
	}
}
//***************** END OF GetInterrupt

//*************************************************************************
//                             check_WDT
//                       Check for WDT Timeout
//*************************************************************************
void check_WDT(void)
{
 TimeOut=0;
 if(!TO)
 {
  //-- TIMEOUT OCCURED !!!!
  TimeOut=1;
  Beep(BEEPERROR);
 }
 CLRWDT();
}
//***************** END OF check_WDT

//*************************************************************************
//                          init_ports
//                      Initialise I/O Ports
//*************************************************************************
void init_ports(void)
{
 CLRWDT();

 TRISA=0x0F;       //-- RS and E LCD control pis as output
 TRISB=0xF0;       //-- 0-3 LCD output 4-7 Keypad input
 TRISC=0xF8;       //-- 0-2 as output rest as inputs
 TRISD=0xFF;       //-- PSP as input initially
 TRISE=0xFF;       //-- PSP Ctrls as input and PSP ON initially

 INTCON=0x00;      //-- Clear all interrupts
 PIE1=0x00;
 PIE2=0x00;
 PSPIE=1;          //-- Enable PSP Interrupt
 PEIE=1;           //-- Enable Peripheral Interrupts
 GIE=1;            //-- Enable Global Interrupts
 ADCON1=0xFF;      //-- Set Port E pins to DIGITAL mode!!!!
}
//***************** END OF init_ports

//*************************************************************************
//                          init_variables
//            Set up the variables that need setting up
//*************************************************************************
void init_variables(void)
{
 CLRWDT();
 if(TimeOut)
 {
  lcd_clear();
  lcd_print(LINE1,"TIMEOUT OCCURRED!");
  lcd_print(LINE2,"Display was RESET!");
  Pause(2);
 }
 lcd_clear();
 lcd_print(LINE1,"HSPG Firmware V2.00");
 lcd_print(LINE2,"M.O.Pearce 1999");
 Pause(1);
 lcd_print(LINE1,"SYSTEM INITIALISING");
 lcd_print(LINE2,"Please wait....");
 Pause(1);
 Beep(BEEPHELLO);
 Running=0;                           //-- Not Running
 Channel=0;                           //-- Current channel number
 Slot=0;                              //-- Current slot number
 Start=0L;                            //-- Start Time
 Stop=0L;                             //-- Stop Time
 Width=0L;                            //-- Pulse Width (Stop - Start)
 Temp.Long=0L;                        //-- Working 32bit value
}
//***************** END OF init_variables

//*************************************************************************
//                          load_current
// loads in the currently selected information from the controller board
//*************************************************************************
void load_current(void)
{
	CLRWDT();
	lcd_clear();
	lcd_print(LINE1,"Reading Data....");

 //-- Select the Slot number --
 // _SELSLT_ - Select Slot command
 #ifdef DEBUG
  lcd_print(LINE2,"W Slot");
 #endif
 if(!SendCommand( _SELSLT_ & (Slot & 0x0F) ) ) //- Choose the slot to read from
 {
  ShowError(E_SLOT);
 }

 //-- Select the channel --
 #ifdef DEBUG
  lcd_print(LINE2,"W Channel");
 #endif

 // _SELCH_  - Select Channel Command
 if(!SendCommand( _SELCH_ & (Channel & 0x0F) ))//- Choose the Channel to read
 {
  ShowError(E_CHANNEL);
 }


 //-- READ in the inversion data --
 #ifdef DEBUG
  lcd_print(LINE2,"D Inv");
 #endif
 if(!SendCommand( DTYPEINVERT ))              //- Data Type = Invert info
 {
  ShowError(E_INVERT);
 }
 #ifdef DEBUG
  lcd_print(LINE2,"R Inv");
 #endif
 if(!GetData(&Invert,1))                      //- Read the Invert Byte
 {
  ShowError(E_SRINVERT);
 }

 //-- READ the start time --
 #ifdef DEBUG
  lcd_print(LINE2,"D Start");
 #endif
 if(!SendCommand( DTYPESTART ))               //- Data Type = Start time
 {
  ShowError(E_START);
 }
 #ifdef DEBUG
  lcd_print(LINE2,"R Start");
 #endif
 if(!GetData(&Temp.Array[0],4))               //- Read "Starts" 4 bytes
 {
  ShowError(E_SRSTART);
 }
 Start=Temp.Long;

 //-- READ the stop time --
 #ifdef DEBUG
  lcd_print(LINE2,"D Stop");
 #endif
 if(SendCommand( DTYPESTOP ))                 //- Data Type = Stop time
 {
  ShowError(E_STOP);
 }
 #ifdef DEBUG
  lcd_print(LINE2,"R Stop");
 #endif
 if(!GetData(&Temp.Array[0],4))               //- Read "Stops" 4 bytes
 {
  ShowError(E_SRSTOP);
 }
 Stop=Temp.Long;
}
//***************** END OF load_current

//*************************************************************************
//                          save_current
// saves the current settings to the controller board
//*************************************************************************
void save_current(void)
{
	CLRWDT();
	lcd_clear();
	lcd_print(LINE1,"Saving Data....");
 //-- Select the Slot number --
 // _SELSLT_ - Select Slot command
 #ifdef DEBUG
  lcd_print(LINE2,"W Slot");
 #endif
 if(!SendCommand( _SELSLT_ & (Slot & 0x0F) ))    //- Choose the slot to write
 {
  ShowError(E_SLOT);
 }

 //-- Select the channel --
 // _SELCH_  - Select Channel Command
 #ifdef DEBUG
  lcd_print(LINE2,"W Channel");
 #endif
 if(!SendCommand( _SELCH_ & (Channel & 0x0F) ))   //- Choose the Channel to write
 {
  ShowError(E_CHANNEL);
 }


 //-- Write in the inversion data --
 #ifdef DEBUG
  lcd_print(LINE2,"D Inv");
 #endif
 if(!SendCommand( DTYPEINVERT ))              //- Data Type = Invert info
 {
  ShowError(E_INVERT);
 }

 #ifdef DEBUG
  lcd_print(LINE2,"W Inv");
 #endif
 if(!SendData(&Invert,1))                     //- Write the Invert Byte
 {
  //-- Report Error
  ShowError(E_SRINVERT);
 }

 //-- READ the start time --
 #ifdef DEBUG
  lcd_print(LINE2,"D Start");
 #endif
 if(!SendCommand( DTYPESTART ))               //- Data Type = Start time
 {
  ShowError(E_START);
 }

 Temp.Long=Start;
 #ifdef DEBUG
  lcd_print(LINE2,"W Start");
 #endif
 if(!SendData(&Temp.Array[0],4))              //- Write "Starts" 4 bytes
 {
  //-- Report Error
  ShowError(E_SRSTART);
 }

 //-- Write the stop time --
 #ifdef DEBUG
  lcd_print(LINE2,"D Stop");
 #endif
 if(!SendCommand( DTYPESTOP ))                    //- Data Type = Stop time
 {
  ShowError(E_STOP);
 }
 Temp.Long=Stop;
 #ifdef DEBUG
  lcd_print(LINE2,"W Stop");
 #endif
 if(!SendData(&Temp.Array[0],4))                 //- Write "Stops" 4 bytes
 {
  //-- Report Error
  ShowError(E_SRSTOP);
 }
}
//***************** END OF save_current


//*************************************************************************
//                           MainMenu
//
//*************************************************************************
void MainMenu(void)
{
 CLRWDT();                                //-- Reset the WDT
 lcd_clear();                             //-- Clear the display
 lcd_print(LINE1,"MAIN:");                //-- Menu type = MAIN
 lcd_print(LINE2,"Slot# CH# EDIT MORE");  //-- Show the options
 DisplayCurrent();                        //-- Update the current settings
 switch(getch())                          //-- Get input from the user
 {
  case OPTION0:
   //-- Selected Slot# option
   if(++Slot > MAXSLOT) Slot=0;
   load_current();                     //-- When Changing slot update Inversion
   break;

  case OPTION1:
   //-- Selected CH# option
   if(++Channel > MAXCHANNEL) Channel=0;
   break;

  case OPTION2:
   //-- Selected EDIT option
   EditMenu();
   break;

  case OPTION3:
   //-- Selected MORE option
   MoreMenu();
   break;

  default:
   //-- Invalid Key - Ignore
   break;
 }
}
//***************** END OF MainMenu

//*************************************************************************
//                          EditMenu
// Edits current selection
//*************************************************************************
void EditMenu(void)
{
 char NotDone=TRUE;
	CLRWDT();
 while(NotDone)
 {
  lcd_clear();
	 lcd_print(LINE1,"EDIT:");
  DisplayCurrent();                 //-- Display the current settings
  lcd_print(LINE2,"Loading Data...");
  load_current();                   //-- Read selected data from main board
  Start=Edit("Start:",Start);
  Width=Edit("Width:",Width);
  if(YesOrNo("Save New Settings?"))
  {
	  save_current();
	  NotDone=FALSE;
  }
  else
  {
   if(!YesOrNo("Try Again?"))
   {
    NotDone=FALSE;
   }
  }
	}
}
//***************** END OF EditMenu

//*************************************************************************
//                          MoreMenu
// Lists a few more options
//*************************************************************************
void MoreMenu(void)
{
 char NotDone=TRUE;
 CLRWDT();
 while(NotDone)
 {
  lcd_clear();
  lcd_print(LINE1,"MORE:");
  DisplayCurrent();                 //-- Display the current settings
  if(Running==TRUE)                 //-- Show opposite to current Run State
  {
	  lcd_print(LINE2,"Pause");
  }
  else
  {
   lcd_print(LINE2,"Run  ");
  }
  lcd_print(LINE2+6,"Inv Coms Reset");
  switch(getch())                        //-- Get input from user --
  {
   case CLR:
    //-- Escape out of menu
    NotDone=FALSE;
    break;

   case OPTION0:
    //-- Pause Mode Selected --
    if(Running==FALSE)
    {
	    Running=TRUE;
    }
    else
    {
     Running=FALSE;
    }
//    CommandSend(PAUSERUN+PAUSESLOT);  //##################################
    break;

   case OPTION1:
    //-- Change Inversion of current channel --
    SelectInversion();
    //-- Update Inversion info --
 	  save_current();
    break;

   case OPTION2:
    //-- Coms Setup Menu Requested --
    NotAvaliable();
    break;

   case OPTION3:
    //-- RESET of system requested --
    if(YesOrNo("** RESET SYSTEM? **"))
    {
     //-- Write Reset command to main board
     lcd_print(LINE2,"Sorry Can't do that!");
     Pause(1);
    }
    break;

   default:
    //-- Invalid Key - Ignore
    break;
  }
 }
}
//***************** END OF MoreMenu
//**********************************************************************
//                      DisplayCurrent
//    Shows the current settings on the top line of the LCD
//    Values are decoded from Running/Slot/Channel/Invert Variables
//**********************************************************************
void DisplayCurrent(void)
{
	unsigned char temp[3];
 CLRWDT();
 //******** Running or Paused **********
 if(Running)
 {
	 lcd_print(LINE1+6,"R");
 }
 else
 {
	 lcd_print(LINE1+6,"P");
 }
 //******** Inverted or Non Inverted ********
 if((Invert>>Channel) & 0x01)
 {
	 lcd_print(LINE1+8,"I");
 }
 else
 {
	 lcd_print(LINE1+8,"N");
 }
 //******** Slot Number ********
 lcd_print(LINE1+10,"SLOT");
 sprintf(temp,"%d",Slot);
 putch(temp[0]);

 //******** Channel Number ********
 lcd_print(LINE1+16,"CH");
 sprintf(temp,"%d",Channel);
 putch(temp[0]);
}
//**************** END OF DisplayCurrent

//*************************************************************************
//                           YesOrNo
// Asks for a yes or no Response to Question String
//*************************************************************************
unsigned char YesOrNo(const char *s)
{
	lcd_clear();
	lcd_print(LINE1,s);
	lcd_print(LINE2,"      YES  NO");
	while(1)
	{
		switch(getch())
		{
	  case OPTION1:               //-- If YES pressed
	  	return(TRUE);              //-- Return TRUE

	  case OPTION2:
   	return(FALSE);             //-- Any other key returns FALSE

   default:
    Beep(BEEPWRONGKEY);
   break;
		}
	}
 return(FALSE);
}
//***************** END OF YesOrNo


//*************************************************************************
//                         NotAvaliable
//   Indicates that option selected is not currently avaliable
//*************************************************************************
void NotAvaliable(void)
{
	lcd_clear();
	lcd_print(LINE1,"Sorry.....");
	lcd_print(LINE2,"Option not avaliable");
	Pause(1);
}
//***************** END OF NotAvaliable


//*************************************************************************
//                               Edit
//                  Edits the 32bit time value in ns
//*************************************************************************
unsigned long Edit(const char *str, unsigned long time)
{
	char string[12];             //-- Temp storage for the string
	char count=0;
	char x=0,AllDone=TRUE;
	Temp.Long=time;
	lcd_print(LINE2,"                    "); //-- Clear the Line
	lcd_print(LINE2,str);        //-- Print the option
	sprintf(string,"%010lu",time); //-- Convert the time

 //-- Put the zeros in place of space --
 //-- Have to do since sprintf does not do it!! --
 while(string[count]!=0)
 {
	 if(string[count]==' ') string[count]='0';
	 count++;
 }

 lcd_cursor(CURSOR_ON);
 //******* EDIT THE NUMBER ON THE DISPLAY *******
 while(AllDone)
 {
 	lcd_prints(LINE2+8,string);  //-- Display the time
	 lcd_print(LINE2+18,"ns");    //-- Indicate that it is ns
  lcd_goto(LINE2+8+x);         //-- Move Cursor to current position
  count=getch();
  switch(count)
  {
	  case CLR:
	   AllDone=FALSE;
	   break;

	  case ENTER:
	   AllDone=FALSE;
	   break;

	  case LEFT:
	   if(x>0)x--;
	   break;

	  case RIGHT:
	   if(x<MAXEDITX) x++;
	   break;

   default:
    if(count>='0' && count <='9')
    {
     string[x]=count;
     if(string[0] >='4')
     {
	     string[0] = '4';
	     //-- Find value that does not cause overflow to occur
	     CLRWDT();
	     while(atol(string) > 0)   //-- if not a negative number then overflow
	     {
		     string[x]--;             //-- find value that does not cause overflow
		     if(string[x] < '0')
		     {
			     string[x]='0';
			     break;
		     }
	     }
     }
     if(x<MAXEDITX) x++;
    }
    break;
  }
 }
	//** IF ENTER PRESSED THEN RETURN NEW VALUE ELSE RETURN OLD **
 lcd_cursor(CURSOR_OFF);  //-- Turn LCD Cursor OFF
 if(count==ENTER)          //-- Check if Enter or ESC
	{
  return(atol(string));    //-- Return the new value
	}
 return(Temp.Long);        //-- Return the old value
}
//***************** END OF Edit


//*************************************************************************
//                         SelectInversion
//          Toggles the inversion for the current channel
//*************************************************************************
void SelectInversion(void)
{
 unsigned char temp;
 temp= 0x01 << Channel;   //-- Select Bit to toggle
 Invert ^= temp;          //-- Toggle the bit by XORing the data
}
//***************** END OF SelectInversion


//*************************************************************************
//                             Beep
// Makes a beep at Rate for Num of times.
// --> Rate is in 0.1ms lots
// --> Num is in units 10 times the Rate
// e.g.  Rate = 10 Num = 100  --> 1ms=1000Hz for 1ms x 10 x Num = 1 Second
// Needs BEEP and TRISBEEP Defined
//*************************************************************************
void Beep(unsigned char Rate,unsigned char Num)
{
	char count,count1;
	BEEP=1;

	while(Num--)
	{
		for(count1=0;count1<10;count1++)
		{
	 	CLRWDT();
	  TRISBEEP=0;
	  for(count=0;count<50;count++)
	  {
	   DelayUs(Rate);
	  }
	  TRISBEEP=1;
	  for(count=0;count<50;count++)
	  {
	   DelayUs(Rate);
	  }
		}
	}
}
//***************** END OF Beep


//*************************************************************************
//
//*************************************************************************

//***************** END OF


//*************************************************************************
//                         CheckForMain
//                 checks if main board responding
//*************************************************************************
void CheckForMain(void)
{
 char count;
 lcd_print(LINE2,"Checking For Main Board...");
 #ifdef DEBUG
 for(count=20;count>0;count--)
 #else
 for(count=50;count>0;count--)
 #endif
 {
  #ifdef DEBUG
   lcd_print(LINE2,"S ACKNULL ");
   DelayMs(100);
  #endif
  SendCommand(ACKNULL);
  #ifdef DEBUG
   lcd_print(LINE2,"W REPLY ");
  #endif
  if(!DataWait(1))
  {
   if((DataRead() & 0xF0) == _ACK_)
   {
    return;
   }
  }
 }
 ShowError(E_NOMAIN);
}
//***************** END OF CheckForMain


//**************************************************************************
//                       ShowError
//**************************************************************************
void ShowError(char Error)
{
 lcd_clear();
 lcd_print(LINE1,"ERROR:");
 switch(Error)
 {
  case E_COMMAND:
   lcd_print(LINE2,"Command");
   break;

  case E_SLOT:
   lcd_print(LINE2,"Slot");
   break;

  case E_CHANNEL:
   lcd_print(LINE2,"Channel");
   break;

  case E_INVERT:
   lcd_print(LINE2,"Invert");
   break;

  case E_STOP:
   lcd_print(LINE2,"Stop");
   break;

  case E_START:
   lcd_print(LINE2,"Start");
   break;

  case E_SRINVERT:
   lcd_print(LINE2,"SR Inv");
   break;

  case E_SRSTOP:
   lcd_print(LINE2,"SR Stop");
   break;

  case E_SRSTART:
   lcd_print(LINE2,"SR Start");
   break;

  case E_NOMAIN:
   lcd_print(LINE2,"No MAIN Detected");
   break;


  default:
   lcd_print(LINE2,"Undefined");
   break;
 }
 Beep(BEEPERROR);
 Pause(1);

}
//*************** END OF ShowError
