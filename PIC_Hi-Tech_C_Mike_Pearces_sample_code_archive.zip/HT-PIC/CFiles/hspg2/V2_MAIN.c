//*****************************************************************************
//                         V2_MAIN.C
//                        Version 2.00
//
// This is the software for the Main Control board That interfaces with
// The Keypad/LCD Module, the Xilinx boards and the Serial Comms controller.
// The system boots - sets up I2C etc then waits for prompts from the
// LCD/Keypad controller to do things.
// When it is communicating with the Xilinx or PC it puts the LCD/Keypad into
// wait mode to stop bus conflicts.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 19 March 1999
//
//*****************************************************************************
//                     VERSION INFORMATION
//*****************************************************************************
// Version 2.00
// 19 March 1999
// Initial Setup and Comms with LCD/Keypad, IIC Comms with EEPROM, Xilinx Comms
// (Serial coms not implemented in 2.00 - not needed initially)
//
//*****************************************************************************
#include <pic.h>

//************************ DEFINES *********************************
#define DEBUG
#define XTAL_FREQ 8MHZ          //-- Crystal speed - for delay routines
#define WDTENABLED              //-- Indicate that WDT is being used


//********* EEPROM ADDRESSES ************
//-- I2C Addresses of EEPROM --
#define PAGE0_ADDR  0xA4        //-- 1010 010x   x= read/write bit
#define PAGE1_ADDR  0xA6        //-- 1010 011x

//-- Base Addresses Inside the EEPROM --
//-- Page 0 --
#define CHANNELBASE    0x00     //-- Start of Channel Data
#define CHANNELDEFAULT 0x80     //-- Start of Start Up Settings (On RESET)
#define INVERTADDR     0xFF     //-- Normal Invert Register
#define INVERTDEFAULT  0xFE     //-- Start Up settings
//-- Page 1 --
#define BOARDTYPE      0x00     //-- Defines the board type
#define HARDWARESTR    0x01     //-- Defines start of hardware string
#define VERSIONSTR     0x80     //-- Defines start of Version string
//--------------------------------------

// TRUE/FALSE  ON/OFF
#ifndef true
 #define true   1
 #define false  0
#endif
#define TRUE   true
#define FALSE  false
#define ON     1
#define OFF    0

//--------- Read Write Modes --------------
#define INVERT 1
#define START  2
#define STOP   3


// Slot Selections
#define SLOT_0        0         //-- Select Slot zero
#define SLOT_1        1         //-- Select slot one
#define SLOT_DESELECT 3         //-- Deselect all slots

// Other Channel Selection controls
#define _START_       0         //-- Indicates writing Start Data
#define _STOP_        1         //-- Indicates writing Stop Data


//************************ I/O PORT DEFINES ************************
// Bit Address Defining command
#define BITNUM(adr, bit) ((unsigned)(&adr)*8+(bit))  //-- used for port defs
//-- PSP Port Pins --
static bit PSPREAD   @ BITNUM(PORTE,0);  //-- Read Pin
static bit TRISREAD  @ BITNUM(TRISE,0);
static bit PSPWRITE  @ BITNUM(PORTE,1);  //-- Write pin
static bit TRISWRITE @ BITNUM(TRISE,1);
static bit PSPCS     @ BITNUM(PORTE,2);  //-- Chip Select Pin
static bit TRISCS    @ BITNUM(TRISE,2);
#define PSP_DATA PORTD        // PSP I/O port

//-- Slot Select pins --
static bit SlotSel0   @ BITNUM(PORTA,0);  //-- Selects card in slot 0
static bit SlotSel1   @ BITNUM(PORTA,1);  //-- Selects card in slot 1

//-- Xilinx Control Pins --
static bit CA0        @ BITNUM(PORTC,0);  //-- Xilinx Counter address 0
static bit CA1        @ BITNUM(PORTC,1);  //-- Xilinx Counter address 1
static bit CA2        @ BITNUM(PORTC,2);  //-- Xilinx Counter address 2
static bit DATACLR    @ BITNUM(PORTC,5);  //-- Clears Xilinx Input Buffers
static bit INVLOAD    @ BITNUM(PORTC,6);  //-- Writes the Inverse Data Register
static bit INVCLR     @ BITNUM(PORTC,7);  //-- Clears the Inverse Data Register
static bit COUNTENABLE @ BITNUM(PORTA,2);//-- Enables the counters to run
static bit LOAD       @ BITNUM(PORTA,3);  //-- Loads the Xilinx data registers
static bit A0         @ BITNUM(PORTA,4);  //-- Xilinx Reg Address Line 0
static bit A1         @ BITNUM(PORTA,5);  //-- Xilinx Reg Address Line 1

//-- I2C Pins --
static bit SCL        @ BITNUM(PORTC,3);  //-- I2C Serial Clock
static bit SDA        @ BITNUM(PORTC,4);  //-- I2C Serial Data


//************************ INCLUDES ********************************
#include "cardtype.h"      //-- Defines the Different cards Avaliable
#include "delay.h"         //-- Delays required for timing etc
#include "delay.c"
#include "i2c.h"           //-- I2C Functions
#include "i2c.c"
//#include "v2_cmds.h"       //-- Command definitions
//#include "v2_ctrl.c"       //-- Command Encoding/decoding etc
#define BOARD_MAIN           //-- Tell v2_coms what funcs to use
#include "v2_coms.h"
#include "v2_coms.c"

//************************ MORE DEFINES ****************************
//#define HARDWARETYPE HW_MAINCTRL          //-- Hardware Type = Main Control Brd
//#define VERSIONBASIC "V2.00 19-03-1999"   //-- Version String
//#define MAXCHANNEL AUTOTRIGGER            //-- Last channel is the AutoTrigger
#define MAXSLOT 1                         //-- Only 2 slots in any unit
#define MAXCHANNEL 6
//************************ GLOBAL VARIABLES ************************
bit OLDPSP;                    //-- Used for temp backup of PSP mode
bit Timeout;                   //-- Indicates if timeout has occured
bit Running;                   //-- Indicates if Selected is running
bit NewCommand=0;              //-- Indicates data in CommandBuff
bit CommandOverflow=0;         //-- Indicates if incoming data has overflowed
unsigned char ChannelMax[2]={0,0}; //-- Number of Channels Avaliable on Board
unsigned char CommandBuff;    //-- Input Buffer from PSP read
unsigned char Channel;        //-- Current channel number
unsigned char Slot;           //-- Current slot number
unsigned char Invert;         //-- Inversion Settings for entire Slot
//unsigned long Start;          //-- Start Time
//unsigned long Stop;           //-- Stop Time
typedef union
{
 unsigned long Long;           //-- Working 32bit value
 unsigned char Array[4];       //-- Array overlaying above
}_DataConvert;
_DataConvert StartTime;
_DataConvert StopTime;


//************************ FUNCTIONS *********************************
void CheckWDT(void);
void InitPorts(void);
void InitVariables(void);
void InitXilinx(void);       //-- Checks for avaliable boards and resets them
unsigned char GetBoardInfo(unsigned char slot);// Reads in board info struct
unsigned char ReadChannelData(unsigned char Board,unsigned char Channel);
unsigned char WriteChannelData(unsigned char Board,unsigned char Channel);
unsigned char UploadChannelData(unsigned char Board,unsigned char Channel);
void DisableLCDKEY(void),EnableLCDKEY(void); //-- does what they say
void XilinxLoadReg(unsigned char *Data); //-- Write to Xilinx 32b reg
char SelectSlot(char Slot);      //-- Toggles I/O pins to select slot
void EnableLCDKEY(void);         //-- Enable LCD_KEPAD to Writing data
void DisableLCDKEY(void);        //-- Disable LCD_KEPAD from Writing data
void LoadChannel(char Channel,char Option); //-- Load Data to channel
void XilinxLoadInvert(unsigned char *Data); //-- Load inversion Data
void DoCommand(unsigned char Data);

//*********************************************************************
//                         main
//*********************************************************************
void main(void)
{
 CheckWDT();       //-- check if Watch Dog timer has timed out
 InitPorts();      //-- Set up I/O port directions and states
 InitVariables();  //-- Set initial values of Variables
 InitXilinx();     //-- Load initial Setting to Xilinx
 ReadChannelData(Slot,Channel); //-- Read current channel data from ROM
 //-- Enable Appropiate Interrupts
 INTCON=0x00;      //-- Clear all interrupts
 PIE1=0x00;
 PIE2=0x00;
 PSPIE=1;          //-- Enable PSP Interrupt
 PEIE=1;           //-- Enable Peripheral Interrupts
 GIE=1;            //-- Enable Global Interrupts
 while(true)
 {
  EnableLCDKEY();               
  if(WaitForNewData())       //-- Wait for a new command
  {
   DoCommand(DataRead());    //-- Decode and do the command
  }
//  else
//  {
//   //-- TIMEOUT OCCURED !!
//  }

 }
}
//**************** END OF main

//*************************************************************************
//                          GetInterrupt
//*************************************************************************
interrupt void GetInterrupt(void)
{
	if(PSPIF)
	{
		//-- PSP Read or write has taken place - only check for writes --
		PSPIF=0;
		if(IBF)
		{
   DataNew=1;
  }
	}
}
//***************** END OF GetInterrupt


//*********************************************************************
//                         CheckWDT
// Checks if reset caused by watch dog timer overflow
// sets Timeout Flag as appropiate
//*********************************************************************
void CheckWDT(void)
{
 Timeout=0;
 if(!TO)
 {
  Timeout=1;
 }
 CLRWDT();
}
//**************** END OF CheckWDT

//*********************************************************************
//                       InitPorts
// Initialises TRIS Registers and Port bits to Powerup Modes
//*********************************************************************
void InitPorts(void)
{
 CLRWDT();
 //-- 4 bit Data and Control Initial setup --
 TRISB=0xFF;  //-- High Impedance Mode initially
 PORTB=0x00;  //-- All pins Low

 //-- The main communication bus --
 TRISD=0xFF;  //-- High Impedance Mode on the pins
 PORTD=0x00;  //-- No data on the bus
 TRISE=0xFF;  //-- High impedance on the Read/Write/Sel signals
 PORTE=0x00;

 //-- Slot/Xilinx Control pins --
 PORTA=0x00;  //-- Initial Ouptut for port A functions (all pins active High)
 TRISA=0x00;  //-- Is the main Control port so set to output

 //-- Xilinx Control and I2C pins --
 PORTC=0x0C;  //-- all but I2C pins Low
 TRISC=0x0C;  //-- all but I2C pins as output

 ADCON1=0xFF;  //-- Set all ADC ports to DIGITAL!!!

}
//**************** END OF InitPorts

//*********************************************************************
//                       InitVariables
// Sets up initlal values for the Variables
//*********************************************************************
void InitVariables(void)
{
 CLRWDT();
 if(!Timeout)    //-- These are the values that only need setting on reboot
 {               //-- So do not change if was a WDT Timout
 }
 OLDPSP=0;
 Running=0;
 NewCommand=0;
 CommandOverflow=0;
 ChannelMax[0]=0;
 ChannelMax[1]=0;
 CommandBuff=0;  //-- Clear the command Buffer
 Channel=0;
 Slot=0;
 Invert=0;
 //Start=0L;
 //Stop=0L;
 StartTime.Long=0L;
 StopTime.Long=0L;
}
//**************** END OF InitVariables

//*********************************************************************
//                      InitXilinx
// Checks for avaliable boards and resets them to Default Settings
// But Disables the Clock until user says otherwise
//*********************************************************************
void InitXilinx(void)
{
 char count;
 if(Timeout) return;  //-- If timeout then brds still set from last time
 for(count=0;count<2;count++)
 {
  if(GetBoardInfo(count))
  {
   //-- Valid Board - So Read Data from EEPROM and upload to The Xilinx
   for(Channel=0;Channel<ChannelMax[count];Channel++)
   {
    ReadChannelData(count,Channel);        //-- Read channel From EEPROM
    #ifdef DEBUG
     DelayMs(10); 
    #endif
    UploadChannelData(count,Channel);      //-- Write Channel To XILINX
   }
  }
 }
 Channel=0;
}
//**************** END OF InitXilinx


//*********************************************************************
//                        GetBoardInfo
// Reads in board info structure and returns true if board is found
//
// NOTE: uses OLDPSP and alters the PSPMODE
//*********************************************************************
unsigned char GetBoardInfo(unsigned char slot)
{
 unsigned char ReturnCode=false,CardType;
 CLRWDT();
 OLDPSP=PSPMODE;        //-- Backup the PSP mode
 PSPMODE=0;             //-- Disable PSP
 PSPCS=0;               //-- Lower CS line to halt the LCD/Keypad Coms
 TRISCS=0;              //-- and make sure it is output


 //*** Select the slot to communicate with ***
 SelectSlot(slot);
 //*** Read the device type string - if error occurs then nothing there!!!
 i2c_WriteTo(PAGE1_ADDR);  //-- Select the device to read from
 i2c_PutByte(BOARDTYPE);   //-- Write the start address to register
 i2c_ReadFrom(PAGE1_ADDR); //-- Restart and send Read of the Address
 CardType=i2c_GetByte(I2C_LAST);    //-- Only read one byte from the ROM
 //*** Check for Valid Card type -- i.e. one that this software can operate
 if(CardType==OPTIC_OUT_6A)
 {
  ChannelMax[slot]=6;
  ReturnCode=true;
 }
 SelectSlot(SLOT_DESELECT);   //-- Deselect slots
 TRISCS=1;                    //-- High impedance on CS
 PSPCS=1;                    //-- To allow LCD to communicate
 PSPMODE=1;

 //##################### DEBUG INFO - FAKE BOARD INFO ########################
 CardType=OPTIC_OUT_6A;
 ChannelMax[0]=6;
 ChannelMax[1]=0;
 ReturnCode=true;
 //###########################################################################
 return(ReturnCode);
}
//**************** END OF GetBoardInfo

//*********************************************************************
//                      ReadChannelData
//
//Reads channel data from the EEPROM and puts into the temporary Buffer
//*********************************************************************
unsigned char ReadChannelData(unsigned char Board,unsigned char Channel)
{
	char count;
 CLRWDT();

 //-- Ensure selected board and channel is in range and exists
 if(ChannelMax[Board] >= Channel && ChannelMax[Board] !=0 )
 {
  DisableLCDKEY();               //-- Disable LCD_KEPAD from Writing data
  i2c_WriteTo(PAGE0_ADDR);       //-- Open the EEPROM at page 0
  i2c_PutByte(Channel*8);        //-- select base address to start reading from
  i2c_ReadFrom(PAGE0_ADDR);      //-- Initiate reading cycle
  for(count=0;count <4;count++)
  {
   StartTime.Array[count]=i2c_GetByte(I2C_MORE); //-- Read 4 Start Bytes
  }
  for(count=0;count <4;count++)
  {
   StopTime.Array[count]=i2c_GetByte(I2C_MORE); //-- Read 4 Stop Bytes
  }
  i2c_WriteTo(PAGE0_ADDR);       //-- Initiate new read from Address
  i2c_PutByte(INVERTADDR);       //-- Address being that of the Inversion data
  Invert=i2c_GetByte(I2C_LAST);  //-- Store the inversion data and end I2C
  EnableLCDKEY();                //-- Enable LCD_KEPAD to Writing data
 }
 else
 {
  //-- either board is not there or invalid channel selection
  return(false);
 }

 return(true);
}
//**************** END OF ReadChannelData

//*********************************************************************
//                      WriteChannelData
//
// Writes data that is in the Buffer to the EEPROM
//*********************************************************************
unsigned char WriteChannelData(unsigned char Board,unsigned char Channel)
{
	char count;
 CLRWDT();
  //-- Ensure selected board and channel is in range and exists
 if(ChannelMax[Board] >= Channel && ChannelMax[Board] !=0 )
 {
  DisableLCDKEY();               //-- Disable LCD_KEPAD from Writing data
  i2c_WriteTo(PAGE0_ADDR);       //-- Open the EEPROM at page 0
  i2c_PutByte(Channel*8);        //-- select base address to start writing to
  for(count=0;count <4;count++)
  {
   i2c_PutByte(StartTime.Array[count]); //-- Write 4 Start Bytes
  }
  for(count=0;count <4;count++)
  {
   i2c_PutByte(StopTime.Array[count]);  //-- Write 4 Stop Bytes
  }
  i2c_Stop();                    //-- End the Write Routine
  DelayMs(10);                   //-- Wait for data to be written to EEPROM
                                 //-- 1ms per byte plus a bit Extra
  i2c_WriteTo(PAGE0_ADDR);       //-- Initiate new read from Address
  i2c_PutByte(INVERTADDR);       //-- Address being that of the Inversion data
  i2c_PutByte(Invert);           //-- Store the inversion data
  i2c_Stop();                    //-- End i2c and start storing
  DelayMs(2);                    //-- Wait for write to complete

  EnableLCDKEY();                //-- Enable LCD_KEPAD to Writing data
 }
 else
 {
  //-- either board is not there or invalid channel selection
  return(false);
 }
 return(true);
}
//**************** END OF WriteChannelData

//*********************************************************************
//                       UploadChannelData
//
// Uploads data that is in the buffer to the selected channel on the
// Xilinx chip.
//*********************************************************************
unsigned char UploadChannelData(unsigned char Board,unsigned char Channel)
{
 CLRWDT();
 DisableLCDKEY();               //-- Disable LCD_KEPAD from Writing data
 //-- Select Slot to write to
 if(SelectSlot(Board))         //-- Only do following if Valid Slot Selected
 {
  //-- Write Start Byte to input register
  XilinxLoadReg(StartTime.Array); //-- Write 4 Start Bytes
  //- Load Start time into Channel Register
  LoadChannel(Channel,_START_);

  //-- Write Stop Time to input register
  XilinxLoadReg(StopTime.Array); //-- Write 4 Stop Bytes
  //- Load Stop Time into the Channel Register.
  LoadChannel(Channel,_STOP_);

  SelectSlot(SLOT_DESELECT);
 }
 EnableLCDKEY();               //-- Enable LCD_KEPAD to Write data
 return(true);
}
//**************** END OF UploadChannelData

//*********************************************************************
//                         XilinxLoadReg
//
// Loads the 32bit register on the Xilinx
//*********************************************************************
void XilinxLoadReg(unsigned char *Data)
{
 char count;
 CLRWDT();
 PSPWRITE=0;                      //-- Disable write pin
 TRISD=0x00;                      //-- Enable output to port
 for(count=0;count<4;count++)
 {
  switch(count)
  {
   case 0:                        //-- Select Byte0 of 32 bit register
    A1=0;A0=0;
    break;

   case 1:                        //-- Select Byte1 of 32 bit register
    A0=1;
    break;

   case 2:                        //-- Select Byte2 of 32 bit register
    A1=1;A0=0;
    break;

   case 3:                        //-- Select Byte3 of 32 bit register
    A0=1;
    break;
  }
  PSP_DATA=*Data;         //- Load the data to write
  PSPWRITE=1;                //- Start the write pulse
  Data++;                 //- Point to next data byte as well as small delay
  PSPWRITE=0;                //- Stop the write pulse
 }
 TRISD=0xFF;
}
//**************** END OF XilinxLoadReg

//*********************************************************************
//                      SelectSlot
//
// Selects the slot to read/write to
//
// 0 = Slot0   1 = Slot1  Anything Else = Deselect
//*********************************************************************
char SelectSlot(char Slot)      //-- Toggles I/O pins to select slot
{
 switch(Slot)
 {
  case 0:                        //-- Select Slot 0
   SlotSel1=0;
   SlotSel0=1;
   break;

  case 1:                        //-- Select Slot 1
   SlotSel0=0;
   SlotSel1=1;
   break;

  default:                       //-- Deselect slots
   SlotSel0=0;
   SlotSel1=0;
   return(false);
 }
 return(true);
}
//**************** END OF SelectSlot
//*********************************************************************
//                 EnableLCDKEY
//*********************************************************************
void EnableLCDKEY(void)
{
 TRISWRITE=1;
 TRISREAD=1;
 TRISD=1;
 PSPMODE=1;
 PSPIE=1;

}
//**************** END OF EnableLCDKEY

//*********************************************************************
//                       DisableLCDKEY
//*********************************************************************
void DisableLCDKEY(void)
{
 PSPIE=0;
 PSPMODE=0;                //-- Change PSP pins to outputs
 PSPWRITE=0;                  //-- And reset them to default states
 PSPREAD=0;
 TRISWRITE=0;
 TRISREAD=0;
 TRISD=1;

 LOAD=0;                   //-- Set other XILINX Control pins to defaults
 INVLOAD=0;
 DATACLR=0;
 INVCLR=0;

}
//**************** END OF DisableLCDKEY

//*********************************************************************
//                      LoadChannel
//
//    Load Data to selected channel and start/stop register
//
//*********************************************************************
void LoadChannel(char channel,char option)
{
 LOAD=0;                            //-- Ensure Load Pulse is Zero
 channel &=0x03;                    //-- Clear out invalid bits
 option &=0x01;
 channel = (channel << 1)|option;   //-- Build the address needed
 PORTC &=0xF8;                      //-- Clear the CA0-CA3 bits leaving others
 PORTC |=channel;                   //-- output selected channel to CA lines
 LOAD=1;                            //-- Start load pulse
 CLRWDT();                          //-- Clear the WDT and add short delay
 LOAD=0;                            //-- End Load pulse
}
//**************** END OF LoadChannel

//*********************************************************************
//                   XilinxLoadInvert
//
// Loads the inversion register with the inversion data
//*********************************************************************
void XilinxLoadInvert(unsigned char *Data)
{
 INVLOAD=0;                 //-- Ensure Inverse Load ctrl is off
 PSP_DATA=*Data;            //-- Put data on the bus
 TRISD=0x00;                //-- Ensure it is output to the bus
 INVLOAD=1;                 //-- Start Load Pulse
 CLRWDT();                  //-- Clear WDT and cause short delay
 INVLOAD=0;                 //-- End the load pulse
 TRISD=0xFF;                //-- Back to High Z mode
}
//**************** END OF XilinxLoadInvert

//*********************************************************************
//                          DoCommand
//
// Decodes the command and performs the required operations
//*********************************************************************
void DoCommand(unsigned char Data)
{
 #ifdef DEBUG
  COUNTENABLE ^=1;              //-- Toggle pin for debug
  DelayMs(1);
 #endif

 switch(Data & 0xF0)     //-- Decode only the command
 {
  //********************** ACK *************************
  case _ACK_:                       //-- Check if an ACK was sent as a command
   switch(Data)
   {
    case ACKNULL:                   //-- If a ACK null respond with the same
     DataWrite(ACKNULL);
     #ifdef DEBUG
      COUNTENABLE ^=1;              //-- Toggle pin for debug
     #endif
     break;

    case ACKMORE:                   //-- Anything else is possible error
    default:
     DataWrite(ACKERROR);
     break;
   }
   break;

  //********************** _WRITE_ *************************
  case _WRITE_:
   //-- Initiates Write Cycle --
   DataWrite(ACKNULL);                 //-- Acknowledge the command
   #ifdef DEBUG
    COUNTENABLE ^=1;                   //-- Toggle pin for debug
   #endif
   switch(ReadWriteMode)
   {
    case INVERT:
     InComing(&Invert,Data & 0x0F);              //-- Read the Invert Data
     break;

    case START:
     InComing(&StartTime.Array[0],Data & 0x0F);  //-- Read the Start Data
     break;

    case STOP:
     InComing(&StopTime.Array[0],Data & 0x0F);   //-- Read the stop data
     break;

    default:
     break;
   }
   //-- Update the EEPROM and Xilinx
   WriteChannelData(Slot,Channel);
   UploadChannelData(Slot,Channel);
   break;

  //********************** _READ_ *************************
  case _READ_:
   //-- Initiates Read Cycle --
   ReadChannelData(Slot,Channel);      //-- Read current selection from EEPROM
   DataWrite(ACKNULL);                 //-- Acknowledge the command
   #ifdef DEBUG
    COUNTENABLE ^=1;              //-- Toggle pin for debug
   #endif
   switch(ReadWriteMode)
   {
    case INVERT:
     OutGoing(&Invert,Data & 0x0F);     //-- Write the Invert Data
     break;

    case START:
     OutGoing(&StartTime.Array[0],Data & 0x0F); //-- Write the Start Data
     break;

    case STOP:
     OutGoing(&StopTime.Array[0],Data & 0x0F);  //-- Write the stop data
     break;

    default:
     break;
   }
   //-- Update the EEPROM and Xilinx
   break;

  //********************** _SELSLT_ *************************
  case _SELSLT_:
   //-- Selects Slot to read/write to
   Slot=Data & 0x0F;
   DataWrite(ACKNULL);
   break;

  //********************** _SELCH_ *************************
  case _SELCH_:
   //-- Selects channel to read/write to/from
   Channel=Data & 0x0F;
   DataWrite(ACKNULL);
   break;

  //********************** _DTYPE_ *************************
  case _DTYPE_:
   //-- Selects the next data type to be read/written to
   switch(Data)
   {
    case DTYPEINVERT:
     ReadWriteMode=INVERT;
     break;

    case DTYPESTART:
     ReadWriteMode=START;
     break;

    case DTYPESTOP:
     ReadWriteMode=STOP;
     break;

   }
   break;

  case _MODE_:
   //-- Selects Run/Pause Reset modes etc...
   switch(Data)
   {
    case MODERUN:
     break;

    case MODEPAUSE:
     break;

    case MODERESET:
     break;
   }
   break;

  default:
   //-- Anything else is an error !!!!
   DataWrite(ACKERROR); //-- Respond with an error code
   break;
 }
}
//**************** END OF DoCommand

//*********************************************************************
//
//*********************************************************************

//**************** END OF



