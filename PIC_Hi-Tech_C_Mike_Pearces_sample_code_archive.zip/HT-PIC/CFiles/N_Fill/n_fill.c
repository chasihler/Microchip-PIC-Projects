//**********************************************************************************
//                               N_Fill.c
//
//                             Version 1.00
//
// Software to replace logic driving the Liquid Nitrogen Filler system
// Uses PIC12C508 - 3 inputs, 1 output, 15 minute timeout.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury.
//
// Started: 30 November 1998
//
//**********************************************************************************
#include <pic.h>

#define  XTAL_FREQ 4MHZ
#include "delay.h"
#include "delay.c"

#define  TIMEOUT  8         //-- Minutes to timeout
#define  MAXTIME  (TIMEOUT * 60 * 1000000)/256    //-- us divided by 256
#define  SECOND   (1000000/256)                  //-- counts per second
#define  OFF 1              //-- OFF State of output
#define  ON  0              //-- ON  State of output
#define  TIMEOUT_ON  1      //-- ON State for Timeout LED
#define  TIMEOUT_OFF 0      //-- OFF State for Timeout LED

#define  TRUE  1
#define  FALSE 0



#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
static bit  DEAD       @ BITNUM(GPIO, 0);  //- Dangerously LOW
static bit  EMPTY      @ BITNUM(GPIO, 1);  //- Lower Limit
static bit  FULL       @ BITNUM(GPIO, 2);  //- Upper Limit
static bit  OUTPUT     @ BITNUM(GPIO, 4);  //- Output Control Pin
static bit  TIMEOUTPIN @ BITNUM(GPIO, 5);  //- Timeout Indicator.

unsigned long Counter;
bit CountEnabled;
bit Filling;
bit TMRHIGH;

void Error(char Type);


//***************************************************************
//main
//***************************************************************
void main (void)
{
	char HourNotUp=0,Minute,Second;
	
 OPTION=0xD8;              //- 11011000  Set upt the option Register
	
	GPIO=0xFF;                //-- All Outputs HIGH
	TIMEOUTPIN=TIMEOUT_OFF;   //-- No Timeout yet so turn LED OFF
	OUTPUT=OFF;               //-- Don't Fill so Output is OFF
	TRIS=0x0F;                //-- Set Up 0 to 3 as input rest as output

	CountEnabled=0;
	Counter=0;
	Filling=0;
	TMRHIGH=0;
	

	while(1)
	{
		//********************* Check the Timeout *********************
		if(CountEnabled)
		{
			if(TMR0 >0x80 && TMRHIGH==0)   //-- If TMR0 > 0x80 then dec counter once
			{
				TMRHIGH=1;                    //-- set flag so multi decrement does not happen
				Counter++;                  //-- increment the counter
				if(Counter > MAXTIME)       //-- Check for Timeout rollaround
				{
					//-- Halt the system cause ya just timed out!!!!
					//-- After a 1 hour wait - give it another go.
					Counter=0;   //-- Reset Outside counter to restart after the hour.
					HourNotUp=1;
					Minute=0;
					Second=0;
					while(HourNotUp)
					{
						OUTPUT=OFF;                //-- Disable the filler
						TIMEOUTPIN=TIMEOUT_ON;     //-- Indicate a timeout occured  
						DelayMs(250);              //-- Flash the LED at 1 Hz
						DelayMs(250);
						TIMEOUTPIN=TIMEOUT_OFF;    //-- with a 50% duty Cycle
						DelayMs(250);
						DelayMs(250);
						if(++Second>=60)           //-- Done a Minute?
						{
							Second=0;                 //-- reset for next count.
       if(++Minute>=60)          //-- Done an Hour?? 
       {
        HourNotUp=0;             //-- Times Up - so restart
       }
						}
					}
					//-- RESTART HERE
    	CountEnabled=0;
    	Counter=0;
	    Filling=0;
	    TMRHIGH=0;
    	TIMEOUTPIN=TIMEOUT_OFF;   //-- No Timeout yet so turn LED OFF
    	OUTPUT=OFF;               //-- Don't Fill so Output is OFF
				}
			}
			else
			{
				//-- enable the next increment of the timeout counter
				if(TMR0 <0x80) TMRHIGH=0; 
			}
		}
		//******************* Check the Pin Status *********************

		//***** Above FULL? *****
		if(FULL) 
		{
			OUTPUT=OFF;              //-- Disable the Filler
			TIMEOUTPIN=TIMEOUT_OFF;  //-- Disable Timeout/Error Indicator
			CountEnabled=FALSE;      //-- Disable the Timeout Counter
			Counter=0;               //-- Reset the Counter
			if(!EMPTY)
			{
				//-- If FULL but indicating Empty then a SENSOR error occured
				Error(1);
			}
		}
		else
		{
		 //***** Below Empty? *****
	  if(!EMPTY)
	  {
	  	OUTPUT=ON;
	  	CountEnabled=TRUE;
	  }
		}
//-- Ignore this pin - no longer required to be monitored.
//		if(!DEAD)
//		{
			//-- Something Badly Wrong - Keep Trying to fill until TimeOut Occurs
//			Error(2);
//		}
	}
}
//***************** END OF main

//***************************************************************
//Error - Flashes the Timeout LED in different Pattern to usual
//***************************************************************
void Error(char Type)
{
	Type++;
	for(;Type>0;Type--)
	{
		TIMEOUTPIN=TIMEOUT_ON;
		DelayMs(100);
		TIMEOUTPIN=TIMEOUT_OFF;
		DelayMs(200);
	}
	DelayMs(250);
	DelayMs(250);
	if(CountEnabled==1)
	{
		Counter-=(SECOND);
	}
}
//********** END OF Error




