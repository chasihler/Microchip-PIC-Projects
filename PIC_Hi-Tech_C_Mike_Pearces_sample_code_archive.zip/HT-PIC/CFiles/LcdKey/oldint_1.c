      //**********************************************************************
//GlobalInterrupt - exactly what it says!!
//**********************************************************************
void interrupt GlobalInterrupt(void)
{
	char count;
 if(PSPIF)
 {
  if(IBF)            // Input Buffer Full
  {
	  NewData=1;
	  Buffer[Head]=PORTD;

   if(Buffer[Head]==LCD_LF) //-- Check for Line Feed
   {
    Buffer[Head]=0;
    if(Head<20)
    {
     Head+=20;      //-- Move Down a Line
    }
    else
    {
		   for(count=0;count<20;count++) //-- Scroll things up but keep head the same
		   {
			   Buffer[count]=Buffer[count+20];
		   }
    }
   }

	  if(Buffer[Head]==LCD_CRLF) //-- Check for Carrige Return + Line Feed
	  {
    Buffer[Head]=0;//-- Terminate Current Position
 	  if(Head < 20)  //-- Check if on first line
	   {
		   Head=20;      //-- Go to Second Line
	   }
	   else           //-- Else on second line
	   {
		   for(count=0;count<20;count++) //-- Scroll things up
		   {
			   Buffer[count]=Buffer[count+20];
		   }
		   Head=20;  //-- Go to start of 2nd line
		   Buffer[Head]=0;  //-- Terminate New Position
	   }
	  }
   else
   {
	   if(Buffer[Head]==LCD_CR)
	   {
		   Buffer[Head]=0;
		   if(Head<20)
		   {
			   Head=0;
		   }
		   else
		   {
			   Head=20;
		   }
	   }
    else
    {
     Head++;
     if(Head>39)
     {
	     Head=0;
     }
    }
   }
  }
  if(!OBF)         // Output Buffer has been read
  {
	  PORTD=0x00;       // Put Null into buffer to indicate no key pressed
	  LastKeyPressed=0; // Allow Beep again on same key
  }
  PSPIF=0;
 }
}
//******************* END OF GlobalInterrupt
