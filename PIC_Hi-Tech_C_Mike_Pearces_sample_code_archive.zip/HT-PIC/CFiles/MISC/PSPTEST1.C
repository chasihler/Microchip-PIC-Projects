//*******************************************************
//                       PSPTest1.C
//
// Test program for using the PSP in a PC Interface Card
// Data sent to port is shifted Left 1 bit and put into
// Outgoing buffer for reading.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 10 March 1998
//
//*******************************************************
#define DEBUG

#include <pic.h>
#include "michaels.h"
#include "gpci.h"

//---- Definitions for things ----
#define  MAXDATA 10        // Maximum amount of data to receive
#define  STARTBYTE 'U'
#define  STOPBYTE  'f'

//---- Define some Bytes in the Array -----
#define  CountIn      TXArray[0]    //-- Number of bytes in Packet
#define  CountOut     RXArray[0]    //-- Ditto
#define  CommandIn    TXArray[1]    //-- Command From PC
#define  CommandOut   RXArray[1]    //-- Command To PC
#define  StartAddrIn  TXArray[2]    //-- Starting Device & Sub Address
#define  StartAddrOut RXArray[2]    //-- Ditto

//---- DEBUG Definitions ----
#ifdef   DEBUG
static bit  Debug   @ PORTBIT(PORTA,4);  //- Debug output bit
#endif

//---- PC Port Designations ----
static bit  FRMERR    @ PORTBIT(PORTA,3);  //- Error occured in last frame
static bit  TXDReady  @ PORTBIT(PORTA,2);  //- Ready to recieve data pin
static bit  RXDReady  @ PORTBIT(PORTA,1);  //- Have data to send to PC
static bit  SERInt    @ PORTBIT(PORTA,0);  //- Interrupt generator pin

//---- GPCI Port Designations ----
#define  GPCIDATA  PORTB                   //- Bidirectional GPCI Data bus
#define  GPCIADDR  PORTC                   //- Address output + below
static bit  GPCIInt   @ PORTBIT(PORTC,6);  //- Interrupt From GPCI bus
static bit  GPCIRead  @ PORTBIT(PORTC,7);  //- /Read from GPCI bus
static bit  GPCIWrite @ PORTBIT(PORTA,5);  //- /Write to GPCI bus

//---- Global TX Variables Etc (TX from PC to Interface) ----
bit   TXStart,TXCountDown,TXDOK,TXProcess,TXCheckOk;
uchar TXCounter,TXChecksum,TXPointer;
uchar TXArray[MAXDATA];

//---- Global RX Variables Etc (RX from interface to PC) ----
bit   RXStart,RXDOK;
uchar RXCount,RXPointer;
uchar RXArray[MAXDATA];

//---- Global Misc Variables ----
bit   FrameError;

//---- Functions ----
void Initialise(void);    //-- Configures data and ports
void TXDInterrupt(void);  //-- IBF Interrupt Routine
void RXDInterrupt(void);  //-- OBF Interrupt Routine
void ProcessData(void);   //-- Process the data packet
void CalcChecksum(void);  //-- Calculates Checksum on outgoing
void EchoData(void);      //-- Echos data back to PC for testing


//***************************************************
//                 Main Routine
//***************************************************
void main(void)
{
	Initialise();
	TXDOK=1;     //-- allow first communication
 TXDReady=1;  //-- Also Tell PC that are ready
 while(1)
 {
	 if(TXProcess==1)
	 {
		 ProcessData();
	 }
	}
}
//***************************************************
//                 Initialise
//***************************************************
void Initialise(void)
{

 GIE=0;    //-- Disable all Interrupts
	//-- Set up Registers
 OPTION=0;
 INTCON=0;  //-- Disable all Interrupts

 TRISB=0xFF; //-- B is Data I/O On GPCI Bus - High Impedance to start with
 TRISD=0xFF; //-- D as inputs - Let PSP stuff sort it out.
 TRISE=0x17; //-- Put into PSP mode and Port E pins as inputs
 TRISA=0x00; //-- All Of Port A are Output / Control lines.
 TRISC=0xC0; //-- 01000000 - Interrupt Pin from GPCI Bus is only input

 //-- Setup Variables and initial Port data settings
 FrameError=0;
 FRMERR=0;
 TXDReady=0;
 RXDReady=0;
 SERInt=0;

 //--- Global TX Variables Etc (TX from PC to Interfae) ----
 TXStart=0;
 TXCountDown=0;
 TXDOK=0;
 TXProcess=0;
 TXCheckOk=0;
 TXCounter=0;
 TXChecksum=0;
 TXPointer=0;
 // TXArray[MAXDATA]=0;
 //---- Global RX Variables Etc (RX from interface to PC) ----
 RXStart=0;
 RXDOK=0;
 RXCount=0;
 RXPointer=0;
 //RXArray[MAXDATA]=0;

 //---- Global Misc Variables ----
 FrameError=0;
 
 //---- Set up the Interrupts ----
 PSPIE=1;   //-- Enable the PSP interrupt
 PEIE=1;    //-- Enable Peripheral Interrupts
 GIE=1;     //-- Enable Global Interrupts

 //---- DEBUG Stuff ----
#ifdef DEBUG
 Debug=1;
#endif
}

//*******************************************************
//ProcessData - Decodes command byte and does it!!
//*******************************************************
void ProcessData(void)
{
	//uchar count;
	//-- Decode Command Byte and perform required operation

 //= FOR TESTING ONLY WILL JUST ECHO DATA BACK TO PC =
// if(TXProcess==0)
 if(TXDOK==1) 
 {
  TXDOK=1;  //-- Recieve data until have something to process
  return;
 }
 #ifdef DEBUG
  Debug=1; //turn LED off  
 #endif
 if((CommandIn & GPCI_ECHO_ON)==GPCI_ECHO_ON)
 {
  //-- Echo on is a test only situation - no other processing is done
  EchoData();
 }
 else
 {
  EchoData(); //-- TEMP FOR TESTING
  //-- Not a Echo Back Test so process the data
  //-- check Command word for read/write, Autoinc/NoInc, Fast/Slow, Resend
  //-- Set up appropiate variables to do above
  //-- Send or read the data to/from the GPCI Bus device
 }
 
 TXDOK=1;        //-- If nothing to process then must be ok to get data
}
//*******************************************************
// CalcChecksum - Calcs checksum for outgoing data Array
//*******************************************************
void CalcChecksum(void)
{
	uchar counter,checksum=0,pointer=0;

	counter=RXArray[0]; //-Should have Byte count in it!!!
	for(;counter>1;counter--)
	{
		checksum+=RXArray[pointer];
		pointer++;
	}
	RXArray[pointer]=checksum; //-- Store checksum in the array
}
//*******************************************************
//   PSPInt - Interupt service Routine
//*******************************************************
void interrupt PSPInt(void)
{
	//-- Service the PSP Interrupt
	if(PSPIF==1)
	{
	 if(IBF)
	 {
	 	//-- New Data in Input Buffer
	 	TXDInterrupt();
	 }
  if(OBF==0)
  {
	  //-- Output buffer has been read
	  RXDInterrupt();
  }
  PSPIF=0;
	}
}

//**********************************************
//    TXDInterrupt - (Input Buffer Full)
//**********************************************
void TXDInterrupt(void)
{
	uchar Data;
 //---- PC has written to the I/O Port ----
 TXDReady=0;      //-- Tell pc not to send any more
 Data = PORTD;   //-- Read the byte from the port
 if(TXDOK==1)
 {
  if(TXStart==0)
	 {
		 //-- Haven't had start byte yet - check for it
		 if(Data==STARTBYTE)
		 {
			 TXStart=1;
			 TXChecksum=0;
			 TXCheckOk=0;
			 TXPointer=0;
    FRMERR=0;         //-- Start of New Frame so Clear any Errors
    FrameError=0;
#ifdef DEBUG
    Debug=0; //-- Turn LED On
#endif
		 }
		 else
		 {
			 //-- Not start byte so have an error!!
    FrameError=1;
		 }
	 }
	 else
	 {
		 //-- Have had start byte previous - so keep going
		 if(TXCountDown==0)
		 {
			 //-- Must be the count down byte
			 if(Data > MAXDATA)
			 {
     //-- If frame size to big then don't read it!!
				 TXCounter=0; //-- Force an end to  things
     FrameError=1;
			 }
			 else
			 {
				 TXCounter=Data;
			  TXCountDown=1;
			 }
   }
			if(TXCounter==1)
			{
			 //--check for Checksum
			 if(TXChecksum==Data)
			 {
				 //--Checksum is correct
				 TXCheckOk=1;             //-- Had valid Checksum so tell about it
     TXArray[TXPointer]=Data; //-- Store the checksum
     TXCounter--;             //-- Count down one more time for Stop
			 }
			 else
			 {
				 //-- Not valid checksum so error occured
     FrameError=1;
			 }
   }
			if(TXCounter==0)
			{
			 //-- Check for Stop Byte
			 if(Data==STOPBYTE)
			 {
				 //-- Yahoo - found valid stop byte
				 TXProcess=1;
				 TXDOK=0;
				 TXCountDown=0;
				 TXStart=0;
			 }
			 else
			 {
				 //-- Not valid Stop Byte
     FrameError=1;
			 }
			 if(FrameError==0 && TXProcess==0 && TXCheckOk==0)
			 {
				 //-- OK to store the data
				 TXArray[TXPointer]=Data;
				 TXPointer++;
     if(TXPointer > MAXDATA)
				 {
					 //-- Last avaliable byte so stay at end of data Array
					 TXPointer=MAXDATA;
				 }
     TXChecksum+=Data;       //-- Add data to checksum
     TXCounter--;            //-- Decrement the number of bytes left to get
			 }
   }
	 }
  if(TXProcess==0)
  {
   TXDReady=1;
  }
 }
 else
 {
  FrameError=1;
 }
 if(FrameError==1)
 {
  FRMERR=1;           //-- Indicate on Output pin
  FrameError=0;       //-- Reset for next round
	 TXStart=0;          //-- Go back to waiting for start byte
  TXDOK=1;            //-- Still try to get data
#ifdef DEBUG
	 Debug=1; //-- Turn LED Off
#endif
 }
 else
 {
  FRMERR=0;           //-- No Error on last reception so turn error off
 }
}
//*******************************************************
// RXDInterrupt - Does outputting to the PC
//*******************************************************
void RXDInterrupt(void)
{
 if(RXDOK==1)
 {
  RXDReady=0;
	 if(RXStart==1)
	 {
		 if(RXCount==0)
		 {
			 //-- Send Stop Byte
			 PORTD=STOPBYTE;
			 RXDOK=0;
			 RXStart=0;
		 }
		 else
		 {
    PORTD=RXArray[RXPointer];     //-- Send Data Byte
    RXPointer++;                  //-- Point to next data byte
    RXCount--;                    //-- Dec Number of bytes left to send
		 }
	 }
	 else
	 {
		 PORTD=STARTBYTE;
		 RXCount=RXArray[0];            //-- Load the counter
		 RXPointer=0;
	 }
	 RXDReady=1;
 }
}

//*********************************************************************
// EchoData  - Echos data frame back to PC - Used for Interface testing
//*********************************************************************
void EchoData(void)
{
 uchar count;
 for(count=0;count<MAXDATA;count++)
 {
  //-- Copy the whole array!!
	 RXArray[count]=TXArray[count];
 }
 TXProcess=0;     //-- Indicate done
 CalcChecksum();  //-- Calculate the checksum for Array
 TXDOK=1;         //-- Ok to get more data from PC
 RXDOK=1;         //-- Ok to send data to PC
 RXDReady=1;      //-- Let the PC Know
 RXCount=RXArray[0]; //-- Let know num of bytes to send 
 #ifdef DEBUG
  Debug=0; //-- turn LED On
 #endif
}
