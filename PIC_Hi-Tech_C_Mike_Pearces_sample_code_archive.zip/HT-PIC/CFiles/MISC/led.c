#include	<pic.h>

/*
 *	Demo program
 *
 *	Flashes LEDs on Port B, responds to switch press
 *	on RA1. Usable on PICDEM board.
 *
 *	Copyright (C)1997 HI-TECH Software.
 *	Freely distributable.
 */

#define	PORTBIT(adr, bit)	((unsigned)(&adr)*8+(bit))

static bit	button @	PORTBIT(PORTA, 1);


main(void)
{
	unsigned	i;
	unsigned char	j;

	TRISB = 0;		/* all bits output */
	j = 0;
	for(;;) {
		PORTB = 0x00;		/* turn all on */
		for(i = 100 ; --i ;)
			continue;
		PORTB = ~j;		/* output value of j */
		for(i = 100 ; --i ;)
			continue;
		if(button == 0)		/* if switch pressed, increment */
			j++;
	}
}
