//--------------
// Simple Interrupt Test Program
// For the PIC16C64
// - Toggles pin on interrupt from INT pin and Timer
//
// M.O.Pearce
//-------------

#include <pic.h>
#include "michaels.h"

//bit TimerLED  @ PORTBIT(PORTC,0);
//bit IntPinLed @ PORTBIT(PORTC,1);
//bit IntLED    @ PORTBIT(PORTC,2);

uchar TmrCnt=0;
uchar IntCnt=0;
bit   LoopCnt=0;

void main (void)
{
	//-- set up the timer and Pins
	OPTION=0x07;   //- int clk, pre to tmr, pre=256, intedg=hitolo
	TRISB=0xFF;    //-- Port B for inputs
	TRISC=0x00;    //-- POrt c for outputs
	
	//-- set up the interrupts
	INTE=1;
	T0IE=1;
	GIE=1;
	
	
 while(1);  //-- let interrupts do everything
}

static void interrupt inttst(void)
{
	if(INTF==1)
	{
		INTF=0;
  IntCnt++;
  switch(IntCnt)
  {
	   default:
	   IntCnt=0; 
	   case 0:
	    RC0=0;
	    break;
	   case 1:
	    RC0=1;
	    break;
  }
	}  
	if(T0IF==1)
	{
		T0IF=0;
		TmrCnt++;
		switch(TmrCnt)
		{
			default:
			 TmrCnt=0;

			case 0:
			 RC1=0;
			 break;

			case 1:
			 RC1=1;
			 break;
		}
	}
	RC2=(LoopCnt^=1);   //-- XOR the bit - anything xored with '1' will toggle
}
