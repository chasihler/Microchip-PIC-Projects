//*************************************************************
//                        GPCIDRV.H
//
// Header file for the GPCI Driver Routines (Serial Simulation)
//*************************************************************

#include "GPCI.H"          //-- Defines For command byte etc

#ifndef uchar
 #define uchar unsigned char
#endif
#ifndef uint
 #define uint unsigned int
#endif

//**********************************************************
// General High Level Functions
//**********************************************************
//-- Read Byte from GPCI Device --
extern uchar GPCIReadB(uchar Address,uchar SubAddr,uchar *Data);

//-- Write Byte to GPCI Device --
extern uchar GPCIWriteB(uchar Address,uchar SubAddr,uchar Data);

//-- Read String from GPCI Device --
extern uchar GPCIReadS(uchar Address,uchar SubAddr,uchar *Data);

//-- Write String to GPCI Device --
extern uchar GPCIWriteS(uchar Address,uchar SubAddr,uchar Data[]);

//-- Set GPCI Bus Speed --
extern uchar GPCISpeed(uchar Speed);

//-- Set Read/Write Mode - AutoInc / NoInc for individual Addresses
extern uchar GPCIRWMode(uchar Address,uchar Mode);

//-- Find And Configure Interface Card
extern uchar GPCIFindCard(void);

//**********************************************************
// I/O Functions between PC and Interface Card (Low Level)
//**********************************************************
//-- For sending a data packet
extern uchar GPCITXD
(
 uint PortAddress,
 uchar BusAddress,
 uchar Command,
 uchar SubAddress,
 uchar Data[],
 uchar Length
);

//-- for receiving a data packet back
extern uchar GPCIRXD(uint PortAddress, uchar *data[]);


