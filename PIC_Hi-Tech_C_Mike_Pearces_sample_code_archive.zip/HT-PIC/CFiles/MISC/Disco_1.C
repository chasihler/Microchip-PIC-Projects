/*
//--------------------------------------
// Disco Light Driver For the PIC12C50x
//      Using HiTech - C Compiler
//
// Author: M.O.Pearce
//
// Started: 15 - December -1997
//--------------------------------------

//-- Pin assignments as follow --
//== OUTPUTS ==
// GP0 - Lamp Drive 0
// GP1 - Lamp Drive 1
// GP2 - Lamp Drive 2
// GP4 - Lamp Drive 3  **** Note it is GP4 cause GP3 is input only
//== INPUTS ==
// GP3 - Beat / Next input
// GP5 - Pattern Select / Randomize switch
*/

#include <pic.h>

#define PORTBIT(adr, bit)       ((unsigned)(&adr)*8+(bit))
static bit  Beat    @ PORTBIT(GPIO, 3);
static bit  Select  @ PORTBIT(GPIO, 5);


unsigned char const PATTERN[129] =
{ 
  0x17,0x0,0x80,0x80,0x80,0x80,0x80,0x80,
  0x10,0x4,0x2,0x1,0x80,0x80,0x80,0x80,
  0x1,0x1,0x17,0x10,0x10,0x17,0x80,0x80,
  0x17,0x7,0x3,0x1,0x0,0x10,0x14,0x16, 
  0x7,0x13,0x15,0x16,0x80,0x80,0x80,0x80, 
  0x0,0x10,0x0,0x1,0x0,0x4,0x0,0x2, 
  0x0,0x0,0x1,0x0,0x0,0x2,0x0,0x0, 
  0x6,0x11,0x80,0x80,0x80,0x80,0x80,0x80, 
  0x14,0x3,0x80,0x80,0x80,0x80,0x80,0x80, 
  0x1,0x3,0x7,0x17,0x7,0x3,0x1,0x0, 
  0x14,0x6,0x3,0x80,0x80,0x80,0x80,0x80, 
  0x10,0x10,0x1,0x1,0x80,0x80,0x80,0x80, 
  0x4,0x4,0x2,0x2,0x80,0x80,0x80,0x80, 
  0x17,0x17,0x17,0x0,0x80,0x80,0x80,0x80, 
  0x2,0x6,0x7,0x17,0x16,0x6,0x4,0x80, 
  0x10,0x2,0x4,0x1,0x2,0x10,0x1,0x4
};

//-----------------------------------------------------
void delay(unsigned char ms);

//-----------------------------------------------------
static unsigned char Sequence=0,Position=0;
union
{
  unsigned char B;
  unsigned int  a : 1 ;
  unsigned int  b : 1 ;
  unsigned int  c : 1 ;
  unsigned int  d : 1 ;
  unsigned int  e : 1 ;
  unsigned int  f : 1 ;
  unsigned int  g : 1 ;
  unsigned int  h : 1 ;
}Bits;
  

main (void)
{
 OPTION=0xDF;    //- T0CS has to be low so GP2 is output
 TRIS = 0x28;    //- GP0,1,2,4 = Out GP3,5 = In
 GPIO = 0xFF;    //- Light everything up
 delay(250);
 delay(250);
 GPIO = 0x00;    //- All lights off
 delay(250);

 while(1)
 {
  //- Check For overflow possibilitys
  Bits.B=PATTERN[((Sequence *8) +Position)];
  if(Bits.h==1) Position=0;  //-- Reset position if told to
  if(Sequence > 15) Sequence=0;
  if(Position > 7) Position=0;
  //- Output data to the port
  GPIO = PATTERN[ ((Sequence * 8) + Position) ];
  //-check for Sequence change or beat
  if(Beat==1)
  {
   //-- Beat Detected so go to next position
   Position++;
   while(Beat)
   {
    //-- Wait for beat to end before change
    delay(10);
   }
  }
  
  if(Select==0)
  {
   //-- Select Key down
   Sequence++;
   while(Select==0)
   {
	   //-- Wait for key release
  	 delay(10);
   }
	 }
 }
}
//********** END OF main

void delay(unsigned char ms)
{
	unsigned char loop,dly,waste;
 for(loop=0;loop < ms;loop++)
 {
	  for(dly=0;dly<100;dly++)
	  {
		  waste=dly+loop;
		  waste+=dly-loop;
	  }
 }
}

