//------------------------------------------------------------
//                        MotoDrv1.C
//
// Program that read in the Required RPM from the PSP 
// and then drives the PWM so that the motor runs at the 
// speed requested.
// Hardware inputs included are:
//  - Data from GPCI through the PSP  
//  - An optical encoder pulse for direct reading of RPM
//  - An over current detection to indicate stall / overloading
//
// Hardware outputs are:
//  - PWM Motor Drive -    
//  - Data output to GPCI through PSP
//  - Current/Stall warning Alarm
//  - Motor Direction Control
//
// Software inputs:
//  - Required Speed in RPM
//  - Direction
//  - Enable/Disable
//
// Software Outputs:
//  - Current Speed in RPM
//  - Current Direction
//  - Current Enabled/Disabled Status
//  - Over Current/Stalled warning
//
// Target Processor: PIC16C64    
//
// Author: Michael Pearce
//         Electronics Workshop, Chemistry Department
//         University of Canterbury
//
// Started: 8 Janurary 1998
//
//---------------------------------------------------------------------
#define  TEST                  // For testing without GPCI

#include <pic.h>
#include "michaels.h"

//------ Defines ------
#define PERIODSHIFT 100000     //-- For 10uS interrupts

#define MAXPWM   0x00          //-- Check if above Max Power
#define MAXPOWER 0xFF          //-- Actual Max Power Value
#define MINPWM   0xFF          //-- Check if below Min Power
#define MINPOWER 0x00          //-- Actual Min Power value

#define PeriodTimer TMR0    //-- Timer used to generate 10uS     
#define TIMERRESET  -48     //-- Reload Value 50 * 200nS = 10uS


//------ Functions -------
// Interrupt Routines
void interrupt MainISR(void);
void PulseInterrupt(void);     //-- Interrupt on edge of RPM Encoder
void TimerInterrupt(void);     //-- Interrupts every 10uS
void PSPInterrupt(void);       //-- Interrupts when PSP Read/Written

// Conversion Routines
uint ConvertData(uint Data);   //-- Converts RPM to Period or Vice Versa

// Configuration Routines
void Setup(void);

// General Routines


//------ Global Variables ------
static struct 
{
	uint Current    : 1;   //- The Over Current inticator
	uint Direction  : 1;   //- The currently selected direction
	uint Enabled    : 1;   //- Motor output is enabled/Disabled
 uint InPulseInt : 1;   //- to stop multi entry of interrupt
 uint InPSPInt   : 1;   //- to stop multi entry of Interrupt
 uint NewData    : 1;   //- Indicates new data read from GPCI
 uint PeriodOvf  : 1;   //- Overflow indicator for Period Counter 
 uint DataError  : 1;   //- Error Occured in getting data from GPCI
}Flags;

struct INDAT
{
	uint  RequiredRPM;
	BITS  Command;
	uchar Spare;
};

static union
{
	uchar  Data[4];         //-- Array read in from port
	struct INDAT  i;
}InData;
	

static uint ComparePeriod;
static uint CurrentPeriod;
static uint CurrentRPM;
static uint PeriodCounter;

//------ Port Pin Designations ------
static bit ErrCurrent @ PORTBIT(PORTB,2); // INPUT  - Over Current
static bit ErrorLED   @ PORTBIT(PORTC,0); // OUTPUT - Error LED
static bit DirPort    @ PORTBIT(PORTC,1); // OUTPUT - Direction
static bit PWMPort    @ PORTBIT(PORTC,2); // OUTPUT - PWM
//---------------------- Start of Code ----------------------------
//****************************************************************
// MainISR - The main Interrupt Service Routine
//****************************************************************
void interrupt MainISR(void)
{
	if(T0IF==1)
	{
   //TimerInterrupt();  //-- Timer 0 is used for 10uS count
	  T0IF=0;  //-- Clear interrupt Flag
	  PeriodTimer=TIMERRESET; //-- reload the timer value
   if((PeriodCounter++)==0)
   {
	   Flags.PeriodOvf=1; //-- indicate if an Overflow error occured
   }
	}
	if(INTF==1 && Flags.InPulseInt==0)
	{
 	 // PulseInterrupt();  //-- External Int Pin
 	uint CurrentPWM;
 	INTF=0;                         //-- Clear the Interrupt Flag
 	Flags.InPulseInt=1;             //-- Prevent Multi occurances
 	CurrentPeriod=PeriodCounter;    //-- Store Current Count
 	PeriodTimer=TIMERRESET; //-- reset the timer to start new count
 	PeriodCounter=0;          //-- set the Period counter to zero
 	if(Flags.PeriodOvf==1)
 	{
 		CurrentPeriod=0xFFFF;  //-- Slowest speed = Stopped
 		Flags.PeriodOvf=0;
 	}
 	if(CurrentPeriod!=ComparePeriod)
 	{
 		CurrentPWM=CCPR1L;
 	 if(CurrentPeriod > ComparePeriod)
 	 {
 	 	//-- Motor Running Slow so speed it up
 	 	if((CurrentPWM++)==MAXPWM) CurrentPWM=MAXPOWER;  //-- Check Max Power
 	 }
 	 else
 	 {
 	 	//-- Motor Running Fast so Slow it down
 	 	if((CurrentPWM--)==MINPWM) CurrentPWM=MINPOWER; //-- Check Min Power
 	 }
 	 CCPR1L=CurrentPWM;
 	 Flags.InPulseInt=0;
 	}
	}
	if(PSPIF==1 && Flags.InPSPInt==0)
	{
 	// PSPInterrupt();    //-- PSP Port R/W
 	uchar Address;
  PSPIF=0;	    //-- Reset interrupt Flag 
  Flags.InPSPInt=1;
  if(IBF)
  {
 	 //-- Byte has been written to port from GPCI
 	 Address=PORTA & 0xFC;       //- Get sub address (2 bits only)
 	 InData.Data[Address]=PORTD; //- Store the Data
   if(Address==2)
   {
 	  //-- command byte was written
 	  if(InData.i.Command.a==1)
 	  {
 		  //-- Execute the new required speed that is in the buffer
 		  Flags.NewData=1;
 	  }
   }
 	 if(IBOV==1)
 	 {
 		 //-- Overflow occured in reading data
 		 IBOV=0;
 	 }
  }
  if(OBF==0)
  {
 	 //-- Byte has been read from port by GPCI
   Flags.InPSPInt=0; 
  }
	}
}
//************ END OF MainISR

//****************************************************************
// main - Start of program code
//****************************************************************
void main(void)
{
 uint OldPeriod;

	Setup();

#ifdef TEST
 Flags.Enabled=1;             //- Enable system
 InData.i.RequiredRPM=1000;   //- Required 1000 RPM
 Flags.NewData=1;             //- Start things in Motion
#endif
	
	while(1)
	{
		if(Flags.Enabled==0)
		{
			CCPR1L=0;    //-- Stop the PWM from Running
			INTE=0;      //-- Turn the Interrupt off
		}
		else
		{ 
			INTE=1;      //-- Re-enable the Interrupt
		}
		if(Flags.NewData==1)
		{
			//--New data read in from GPCI port so convert & store
			ComparePeriod=ConvertData(InData.i.RequiredRPM);
   Flags.NewData=0;
   Flags.Direction=InData.i.Command.b;
   DirPort=Flags.Direction;
		}
		if(CurrentPeriod != OldPeriod)
		{
			//--Current Period Different from Old - so Update 
		 OldPeriod=CurrentPeriod;
		 CurrentRPM=ConvertData(OldPeriod);
		}
		if(ErrCurrent==1)
		{
			//-- If Over Current error occurs - indicate so
			ErrorLED=1;
			Flags.Current=1;
		}
		else
		{
			ErrorLED=0;
			Flags.Current=0;
		}
		//-- Check if motor spinning - if not inc speed
  if(Flags.PeriodOvf)
  {
	  if(CCPR1L < 0xFF)
	  {
		  CCPR1L++;	  //-- Little Increment Until up to speed
	  }
	  else
	  {
		  //-- At full power - Error Occuring....Stalled.
		  ErrorLED=1;
	  }
  }
	}

}
//************ END OF main

//****************************************************************
//CalcPeriod - Converts RPM to Period or Vice Versa
//****************************************************************
uint ConvertData(uint data)     
{
	if(data == 0)
	{
		//-- Cannot divide by zero
		return(0xFFFF);   // - a value of 0xFFFF is returned
	}
	return(PERIODSHIFT/data); //-- 1/data x PeriodShift (1000000 for 1uS)
	                          //-- Result is 16 bit real number
}
//************ END OF CalcPeriod

/*
//****************************************************************
//PSPInterrupt - Keeps correct data up to the PSP
//****************************************************************
void PSPInterrupt(void)
{
	uchar Address;
 PSPIF=0;	    //-- Reset interrupt Flag 
 if(Flags.InPSPInt==1) return; //-- Stop Multipule occurance
 Flags.InPSPInt=1;
 if(IBF)
 {
	 //-- Byte has been written to port from GPCI
	 Address=PORTA & 0xFC;       //- Get sub address (2 bits only)
	 InData.Data[Address]=PORTD; //- Store the Data
  if(Address==2)
  {
	  //-- command byte was written
	  if(InData.i.Command.a==1)
	  {
		  //-- Execute the new required speed that is in the buffer
		  Flags.NewData=1;
	  }
  }
	 if(IBOV==1)
	 {
		 //-- Overflow occured in reading data
		 IBOV=0;
	 }
 }
 if(OBF==0)
 {
	 //-- Byte has been read from port by GPCI
  Flags.InPSPInt=0; 
 }
}
//************ END OF PSPInterrupt
*/


/*
//****************************************************************
//TimerInterrupt - The 10uSec Interrupt
//****************************************************************
void TimerInterrupt(void)
{
	T0IF=0;  //-- Clear interrupt Flag
	PeriodTimer=TIMERRESET; //-- reload the timer value
 if((PeriodCounter++)==0)
 {
	 Flags.PeriodOvf=1; //-- indicate if an Overflow error occured
 }
}
//************ END OF TimerInterrupt
*/
//****************************************************************
//Setup - Sets up all registers required for ints ports etc
//****************************************************************
void Setup(void)
{
	//------ Setup External Int ------
	INTEDG=0;   //- set for falling edge
	//INTE=1;     //- enable interrupt - done in main()
	TRISB=0xFF; //- all port B Pins as inputs
	RBPU=0;     //- Enable pullups

 //------ Setup Timer ------

 TMR0=0; //- start with inital delay of lots
	T0IE=1; //- Enable Interrupt

 //------ Setup PWM ------
 TRISC=0x00;   //- Port C = all outputs
 PR2=0xFF;     //- fastest PWM Rate
 CCPR1L=0x00;  //- No speed to start with (motor Stopped)
 CCP1CON=0x0F; //- Put into PWM mode
 T2CON=0x04;   //- Timer 2 - no post or pre, but enabled
  
 //------ Setup PSP ------
 TRISE=0x17;   //- PSP Mode + control pins as inputs
 PSPIE=1;      //- Enable PSP interrupt
 
 //------ OPTION Register ------
 OPTION=0x08; //  00001000	 PB pullups,Int Neg Edge, Internal Clk,No Pre

 //------ Clear the Flags ------
 Flags.Current=0;              //-- No Over Current Error
 Flags.Direction=0;            //-- Initial Direction
 Flags.Enabled=0;              //-- Not enabled to start with
 Flags.InPulseInt=0;           
 Flags.InPSPInt=0;
 Flags.NewData=0;              //-- No New Data to Process
 Flags.PeriodOvf=0;            //-- No overflow from period counter
 Flags.DataError=0;            //-- No Data read errors
 
 //------ Clear the Variables ------
 ComparePeriod=0xFFFF;         //-- start at stopped.
 InData.i.RequiredRPM=0x0000;  //-- Initially no required speed
 InData.i.Command.a=0;         //-- No Command (Stop false triggering)
   
 //-- Enable global Interrupt
 GIE=1;
}
//************ END OF SetUpPulse

/*
//****************************************************************
//PulseInterrupt - gets the current period
//****************************************************************
void PulseInterrupt(void)
{
	uint CurrentPWM;
	INTF=0;                         //-- Clear the Interrupt Flag
	if(Flags.InPulseInt==1) return; //-- Check if already here.
	Flags.InPulseInt=1;             //-- Prevent Multi occurances
	CurrentPeriod=PeriodCounter;    //-- Store Current Count
	PeriodTimer=TIMERRESET; //-- reset the timer to start new count
	PeriodCounter=0;          //-- set the Period counter to zero
	if(Flags.PeriodOvf==1)
	{
		CurrentPeriod=0xFFFF;  //-- Slowest speed = Stopped
		Flags.PeriodOvf=0;
	}
	if(CurrentPeriod==ComparePeriod)
	{
		return; //-- at required speed - do nothing
	}
	CurrentPWM=CCPR1L;
	if(CurrentPeriod > ComparePeriod)
	{
		//-- Motor Running Slow so speed it up
		if((CurrentPWM++)==MAXPWM) CurrentPWM=MAXPOWER;  //-- Check Max Power
	}
	else
	{
		//-- Motor Running Fast so Slow it down
		if((CurrentPWM--)==MINPWM) CurrentPWM=MINPOWER; //-- Check Min Power
	}
	CCPR1L=CurrentPWM;
	Flags.InPulseInt=0;
}
//************ END OF PulseInterrupt
*/


//************ END OF

//****************************************************************
//
//****************************************************************




      




