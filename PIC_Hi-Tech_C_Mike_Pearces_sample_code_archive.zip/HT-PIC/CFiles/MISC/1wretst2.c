#include <pic.h>
#include <conio.h>
#include <stdio.h>

#define	XTAL_FREQ	   20MHZ	    // Crystal frequency in MHz

#define	XTAL   20000000        // Crystal frequency in Hz
#define SERIALSOFTWARE         // Indicate type of serial output
#define TxPort PORTB           // Pin on Port B
#define RxPort PORTB
#define TxBit  2               // Pin Number to use
#define RxBit  1
#define TxTris TRISB           // Tris Register for Pin
#define RxTris TRISB
#define BRATE  9600            // Baud rate required

#include "m_delay.h"
#include "michaels.h"

#define D_PIN_PORT  PORTB
#define D_PIN_NUM   0
#define D_TRIS_PORT TRISB
#include "1wire002.c"

//-- Function declarations --

float CalcHiResTemp (uchar countl,uchar counth, uchar cpd, uchar cr);
void  SendToSerial(float Temperature);


//************************************************************************
// Main
//************************************************************************
void main (void)
{
	uint count;
	uchar datal,datah,Count_Remain,Count_Per_C;
	signed char data;
 float HiResTemp;
	InitSerial();
// printf("\r\nGidday, This is a test for the Dallas 1-wire Firmware\r\n");
 while(1)
 {

  for(count=0;count<2500;count++)
  {
   DelayUs(50);         //-- 2500*100uS = 0.25 Second
   DelayUs(50);         //-- Delay Between samples
  }

  D_Reset();          //-- Reset Bus
  D_Write(0xCC);       //-- Skip Rom
  D_Write(0x44);       //-- Convert temperature
  for(count=0;count<5000;count++)
  {
   DelayUs(50);         //-- 5000*100uS = 0.5 Second
   DelayUs(50);         //-- Time enough for conversion of temperature
  }
  D_Reset();
  //-- Read in the data
  D_Write(0xCC);       //-- Skip Rom
  D_Write(0xBE);       //-- Read Scratch pad
  //-- Read in the temperature
  datal=D_Read(); //-- read first byte
  datah=D_Read(); //-- read second byte

  //-- Read unwanted bytes from device
  D_Read();       //-- TH/User Byte 1
  D_Read();       //-- TL/User Byte 2
  D_Read();       //-- Reserved
  D_Read();       //-- Reserved

  //-- Read remainders of counters for accurate calculation
  Count_Remain=D_Read(); //Count remain
  Count_Per_C=D_Read();  //Count Per C

  //-- Calculate the temperature accurate to x decimal places
  HiResTemp=CalcHiResTemp(datal,datah,Count_Remain,Count_Per_C);

  //-- Do Control Stuff

  //-- Send Temperature Data to PC
  //SendToSerial(HiResTemp);
  printf("\r\ndl=%d, dh=%d, cr=%d, cpc=%d     ",datal,datah,Count_Remain,Count_Per_C);
  data=datal >>1;
  if(datah !=0)
  {
	  data=data|0x80;
  }
  printf("\r\nLoRes Temp=%d, HiRes Temp=%f    ",data,HiResTemp);
 }
}
//********** END OF main

//*********************************************************************
// CalcHiResTemp - Calculates Temperature to x decimal places
// Specifically for the DS1820 Only
// -Give it the raw data and returns a high res temperature
//*********************************************************************
float CalcHiResTemp (uchar countl,uchar counth, uchar cpd, uchar cr)
{
	float frac_deg;
 float result;
 signed char  temp;

 temp=countl >> 1;        //-- Push 1/2 degree bit out of byte
 if(counth !=0 )
 {
  temp=temp|0x80;       //-- Add the sign to the byte if there is one
 }

	if(cpd !=0)
	{
		frac_deg = ((float)(cpd - cr)) / ((float) cpd);
	}
	else
	{
		frac_deg = 0.25;
	}

 result = ((float)temp) - 0.25 + frac_deg;

	return(result);
}
//************* End Of CalcHiResTemp

//*********************************************************************
//SendToSerial - sends the temperature to the serial port
//*********************************************************************
void  SendToSerial(float Temperature)
{
//	uint count;
// union
// {
//  float temp;
//  char bytes[8];
// }ftob;
// ftob.temp=Temperature;
// putch('R');        //-- Indicate RAW data

// printf("%3.2f",Temperature);

// for(count=0;count<4;count++)
// {
//  putch(ftob.bytes[count]);
// }
// putch('E');                      //-- Indicate end of RAW data
}







