#include	"picbot.h"

/*
 *	A simple PICBot (compile for 16C74)
 *
 *	Try your PICBot out against other PICBots at:
 *		http://www.innovatus.com/
 *
 *	Copyright (C)1997 HI-TECH Software.
 *	Freely distubutable.
 */

static bit	saw_bot, left;
persistent unsigned char	lastdir, range;
persistent unsigned char	cntr, diff;

void interrupt
take_hit(void)
{
	if(SEE_BOT) {
		LEFT = 0;
		RIGHT = 0;
		FIRE = 1;
		FASTER = 1;
		saw_bot = 1;
		lastdir = DIRN;
		range = 31/DIST+1;
		cntr = 0x80-DIST/2;
	} else
		saw_bot = 0;
	if(!GUN_RDY)
		FIRE = 0;
	RBIF = 0;
}


main()
{

	FIRE = 1;
	RIGHT = 1;
	FASTER = 1;
	left = 0;
	range = 30;
	cntr = 0xC0;
	RBIE = 1;
	GIE = 1;
	for(;;) {
		if(DIST < 30 && SPEED > 10) {
			FASTER = 0;
			SLOWER = 1;
		} else {
			SLOWER = 0;
			FASTER = 1;
		}
		if(cntr == 0) {
			LEFT = 0;
			RIGHT = 0;
		}
		if(!LEFT && !RIGHT && !saw_bot) {
			if(cntr & 0xC0) {
				lastdir = DIRN;
				if(cntr & 0x80) {
					LEFT = 1;
					left = 1;
				} else {
					RIGHT = 1;
					left = 0;
				}
			}
		}
		FIRE = 0;
		++cntr;
		if(LEFT || RIGHT) {
			if(RIGHT)
				diff = DIRN-lastdir;
			else {
				diff = lastdir-DIRN;
			}
			if(diff > range) {
				if(LEFT) {
					LEFT = 0;
					RIGHT = 1;
					left = 0;
				} else {
					LEFT = 1;
					RIGHT = 0;
					left = 1;
				}
				range = 55;
			}
		}
	}
}

