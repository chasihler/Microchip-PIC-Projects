//------------------- TST232_1.C ------------------------
//
//Test program to try and get serial routines running in C
//
// Author:  M.O.Pearce 
// Started: 23 June 1998
//--------------------------------------------------------

#include <pic.h>               // Standard PIC header

//-- Set up required infor for RS-232
#define XTAL_FREQ  20MHZ
#define	XTAL   20000000        // Crystal frequency in Hz

#define SERIALSOFTWARE         // Indicate type of serial
#define TxPort PORTB
#define RxPort PORTB
#define TxBit  2
#define RxBit  1
#define TxTris TRISB
#define RxTris TRISB
#define BRATE 9600

#include "delay.h"             //-- us delay Routine
#include "michaels.h"          //-- outch routine

//************************************************************************
// Main
//************************************************************************
void main (void)
{
	uint count;
 const char message[15]="Hello World \r\n";

 InitSerial();   //-- Set up the serial ports
 while(1)
 {
	 for(count=0;count<14;count++)
	 {
   putch(message[count]);        //-- Send the message
  }

//    putch(0x55) ;                 //-- 'U' = b01010101 -- For checking timing
//  outch(0x00);                    //-- All zeros
//  outch(0xff);                    //-- All Ones
  for(count=0;count<10;count++)
  {
   DelayUs(100);        // 100uS*10 = 1ms
  }
 }
} 

