/*
 * Sample application using LCD interface (see lcd.c) and analog input
 * on a 16C71 (see adc.c)
 * 
 * Just read channel 0 of the ADC and write it to the LCD
 * 
 */


#include	<pic.h>
#include	"delay.h"
#include	"lcd.h"
#include	"adc.h"


main()
{
	ADCON1 = 2;		// 16C71 requires Port A reconfiguration - RA2/3 are digital
				// I/O, 0 and 1 are analog
	TRISA = 0xF3;	/* control lines are output */
	TRISB = 0xF0;	// 4 data lines are output
	lcd_init();
	for(;;) {
		adc_read(0);		// read channel 0
		lcd_clear();
		lcd_puts("Value = ");
		lcd_write(ADRES/100+'0');	// hundreds digit
		lcd_write((ADRES/10)%10+'0');	// tens digit
		lcd_write(ADRES%10+'0');	// units
		DelayMs(250);			// wait a while
	}
}

