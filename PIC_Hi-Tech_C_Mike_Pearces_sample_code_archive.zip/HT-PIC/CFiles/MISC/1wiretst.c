#include <pic.h>
#include <conio.h>
#include <stdio.h>

#define	XTAL_FREQ	   20MHZ	    // Crystal frequency in MHz

#define TOUCHTRIS    TRISB     // One wire bus TRIS Reg
#define TOUCHPORT    PORTB     // One Wire bus PORT reg
#define TOUCHBIT     0         // One Wire bus bit number
#define	XTAL   20000000        // Crystal frequency in Hz
#define SERIALSOFTWARE         // Indicate type of serial output
#define TxPort PORTB           // Pin on Port B
#define RxPort PORTB
#define TxBit  2               // Pin Number to use
#define RxBit  1
#define TxTris TRISB           // Tris Register for Pin
#define RxTris TRISB
#define BRATE  9600            // Baud rate required


#include "delay.h"
#include "michaels.h"

#include "1wire001.c"

//-- Function declarations --

float CalcHiResTemp (uchar countl,uchar counth, uchar count_per_degree, uchar count_remain);
void  SendToSerial(float Temperature);


//************************************************************************
// Main
//************************************************************************
void main (void)
{
	uint count;
	uchar datal,datah,Count_Remain,Count_Per_C;
// float HiResTemp;

	TouchSetUp();
	InitSerial();
 while(1)
 {
  TouchReset();          //-- Reset Bus
  TouchByte(0xCC);       //-- Skip Rom
  TouchByte(0x44);       //-- Convert temperature
  for(count=0;count<2500;count++)
  {
   DelayUs(100);         //-- 2500*200*1uS = 0.5 Second
   DelayUs(100);         //-- Time enough for conversion of temperature
  }
  TouchReset();
  //-- Read in the data
  TouchByte(0xCC);       //-- Skip Rom
  TouchByte(0xBE);       //-- Read Scratch pad
  //-- Read in the temperature
  datal=TouchByte(0xFF); //-- read first byte
  datah=TouchByte(0xFF); //-- read second byte

  //-- Read unwanted bytes from device
  TouchByte(0xFF);       //-- TH/User Byte 1
  TouchByte(0xFF);       //-- TL/User Byte 2
  TouchByte(0xFF);       //-- Reserved
  TouchByte(0xFF);       //-- Reserved

  //-- Read remainders of counters for accurate calculation
  Count_Remain=TouchByte(0xFF); //Count remain
  Count_Per_C=TouchByte(0xFF);  //Count Per C

  //-- Calculate the temperature accurate to x decimal places
//  HiResTemp=CalcHiResTemp(datal,datah,Count_Remain,Count_Per_C);

  //-- Do Control Stuff

  //-- Send Temperature Data to PC
  //SendToSerial(HiResTemp);
  printf("\r\ndatah=%X,  datal=%X,  Count_Remain=%X,  Count_Per_C=%X     ",datal,datah,Count_Remain,Count_Per_C);


 }
}
//********** END OF main

//*********************************************************************
// CalcHiResTemp - Calculates Temperature to x decimal places
// Specifically for the DS1820 Only
// -Give it the raw data and returns a high res temperature
//*********************************************************************
#define LSB    0.5
float CalcHiResTemp (uchar countl,uchar counth, uchar count_per_degree, uchar count_remain)
{
	float frac_deg;

 union
 {
  int temp;
  uchar  low;
  uchar  high;
 }rawtemp;

 rawtemp.low=countl;
 rawtemp.high=counth;
 rawtemp.temp=rawtemp.temp & 0x01FE;    //-- Clear unwanted bits

	if(rawtemp.temp>>8 > 0)   //-- check for -ve value
	{
		rawtemp.temp -= 256;
	}
	if(count_per_degree !=0)
	{
		frac_deg = (count_per_degree - count_remain) / ( count_per_degree);
	}
	else
	{
		frac_deg = LSB/2.0;
	}
	return( ((float)rawtemp.temp - (LSB/2.0)) + frac_deg);
}
//************* End Of CalcHiResTemp

//*********************************************************************
//SendToSerial - sends the temperature to the serial port
//*********************************************************************
void  SendToSerial(float Temperature)
{
//	uint count;
// union
// {
//  float temp;
//  char bytes[8];
// }ftob;
// ftob.temp=Temperature;
// putch('R');        //-- Indicate RAW data

// printf("%3.2f",Temperature);

// for(count=0;count<4;count++)
// {
//  putch(ftob.bytes[count]);
// }
// putch('E');                      //-- Indicate end of RAW data
}







