/*
 *	Daffynitions for the PICbot
 */

#include	<pic.h>

#define	PB(port,bit)	((unsigned)&(port)*8+(bit))

static bit	FIRE	@ PB(PORTA,0);
static bit	RIGHT	@ PB(PORTA,1);
static bit	LEFT	@ PB(PORTA,2);
static bit	FASTER	@ PB(PORTA,3);
static bit	SLOWER	@ PB(PORTA,4);


#define	DIRN	(PORTB&0x1F)

static bit	SEE_BOT	@ PB(PORTB,5);
static bit	GUN_RDY	@ PB(PORTB,6);
static bit	NEW_HIT	@ PB(PORTB,7);

#define	DIST	PORTC
#define	DAMAGE	(PORTE&7)
#define	SPEED	(PORTD>>3)


