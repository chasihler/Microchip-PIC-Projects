//--------------------------------------
// Disco Light Driver For the PIC12C50x
//              Version 3
//
//      Using HiTech - C Compiler
//
// Author: M.O.Pearce
//
// Started: 18 - December -1997
//--------------------------------------

//-- Pin assignments as follow --
//== OUTPUTS ==
// GP0 - Lamp Drive 0
// GP1 - Lamp Drive 1
// GP2 - Lamp Drive 2
// GP4 - Lamp Drive 3  **** Note it is GP4 cause GP3 is input only
//== INPUTS ==
// GP3 - Beat / RS-232 RxD
// GP5 - Pattern Select / Address Select

//#define BC       //- Borland C Compiler

#ifdef BC
 #include <stdio.h>
 #include <conio.h>
 #include <ctype.h>
 unsigned char GPIO,OPTION,TRIS;
#else
 #include <pic.h>
#endif


#define MAXSEQ  15
#define MAXPOS  7
#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
#define BAUD    2400
#define BITTIME  ((unsigned char) (((1000000/BAUD)/8)-3))

#ifdef BC
 char Beat,Select;
#else
 static bit  Beat    @ BITNUM(GPIO, 3);  //- Beat input pin
 static bit  Select  @ BITNUM(GPIO, 5);  //- Sequ Select pin
#endif

unsigned char const PATTERN[((MAXSEQ+1)*(MAXPOS+1))] =
{
  0x17,0x0,0x17,0x0,0x17,0x0,0x17,0x0,
  0x10,0x4,0x2,0x1,0x10,0x04,0x02,0x01,
  0x1,0x1,0x17,0x10,0x10,0x17,0x01,0x01,
  0x17,0x7,0x3,0x1,0x0,0x10,0x14,0x16,
  0x7,0x13,0x15,0x16,0x07,0x13,0x15,0x16,
  0x0,0x10,0x0,0x1,0x0,0x4,0x0,0x2,
  0x0,0x0,0x1,0x0,0x0,0x2,0x0,0x0,
  0x6,0x11,0x06,0x11,0x06,0x11,0x06,0x11,
  0x14,0x3,0x14,0x03,0x14,0x3,0x14,0x3,
  0x1,0x3,0x7,0x17,0x7,0x3,0x1,0x0,
  0x14,0x6,0x3,0x14,0x06,0x03,0x0,0x0,
  0x10,0x10,0x1,0x1,0x10,0x10,0x01,0x01,
  0x4,0x4,0x2,0x2,0x10,0x10,0x01,0x01,
  0x17,0x17,0x17,0x0,0x17,0x0,0x17,0x17,
  0x2,0x6,0x7,0x17,0x16,0x6,0x4,0x0,
  0x10,0x2,0x4,0x1,0x2,0x10,0x1,0x4
};

  unsigned char Sequ,Pos;    // Sequence # and Position
//-----------------------------------------------------
void RunAuto(void);
void CheckKeys(void);
//-----------------------------------------------------
struct
{
	unsigned int k1    : 1;
	unsigned int k2    : 1;
	unsigned int ALoop : 1;
}Flags;
//-----------------------------------------------------


//*****************************************************
//  Main - Start of the program
//*****************************************************
void main (void)
{
 OPTION=0xDF;    //- T0CS has to be low so GP2 is output
 TRIS = 0x28;    //- GP0,1,2,4 = Out GP3,5 = In
 Flags.k1=0;
 Flags.k2=0;
 Sequ=0;
 Pos=0;
#ifdef BC
 Beat=1;
 Select=1;
#endif

 RunAuto();
}
//********** END OF main

//*****************************************************
// RunAuto - Runs the Standalone auto routines
//*****************************************************
void RunAuto(void)
{
  unsigned char Pointer,Data;
  while(1) // Loop Forever
  {
	  Flags.ALoop=0;
	  do
	  {
	   Pointer=(unsigned char)((Sequ*(MAXPOS+1))+Pos);
	   Data=PATTERN[Pointer];
	   if(Data > 127)    //-- check for auto loop instruction
	   {
		   Flags.ALoop=1;
		   if(Pos==0)      //-- If at position 0 then move to next Sequ
		   {
	//		   Sequ++;
			   if(Sequ > MAXPOS) Sequ=0;
			  }
		   else
		   {
			   Pos=0;
		   }
	   }
	   else
	   {
     Flags.ALoop=0;
	   }
   }while(Flags.ALoop==1); //-- Keep scanning until data found

   Data=Data^0xFF;      //-- Invert data using XOR
   
	  GPIO=Data;           //-- Output the data to the port
#ifdef BC
 gotoxy(10,10);
 printf("Port Value = %X   ",GPIO);
 gotoxy(10,12);
 printf("Pointer = %d  Sequ = %d  Pos = %d",Pointer,Sequ,Pos);
#endif
	  CheckKeys();
 }
}
//********** END OF RunAuto
//*****************************************************
// CheckKeys - checks the keys + Auto repeats
//*****************************************************
void CheckKeys(void)
{
#ifdef BC
 if(kbhit()!=0)
 {
   switch(toupper(getch()))
   {
     case 'A':
      Beat=0;
      break;

     case 'S':
      Beat=1;
      break;

     case 'Q':
      Select=0;
      break;

     case 'W':
      Select=1;
      break;
   }
  }
  gotoxy(10,14);
  printf("Beat = %d  Select = %d",Beat,Select);

#endif
 //-- Check Beat key
 if(Flags.k1==0)
	{
		if(Beat==0)  //-- Key has been depressed for new time
		{
			Flags.k1=1;
			Pos++;      //-- Move to next position in sequence
			if(Pos > (MAXPOS+1)*(MAXSEQ+1))Pos=0;
		}
	}
	else
	{
		if(Beat==1)  //-- Key has been released
		{
			Flags.k1=0;
		}
	}

 //-- Check change sequence Key
	if(Flags.k2==0)
	{
		if(Select==0)  //-- Key has been depressed for new time
		{
			Flags.k2=1;
//			Sequ++;      //-- Move to next position in sequence
//		if(Sequ > MAXSEQ)Sequ=0;
		}
	}
	else
	{
		if(Select==1)  //-- Key has been released
  {
   Flags.k2=0;
  }
 }
}
//************* END OF CheckKeys
