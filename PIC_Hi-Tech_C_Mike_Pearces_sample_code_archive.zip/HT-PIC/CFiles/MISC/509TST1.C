//--------------------------------------
//            509TST1.C
//
// A simple test routine to see if the
// chip is operational.
// Uses the timer to generate a constant 
// time base to rotate the output pins.
// GP3 (Pin 4) is used to toggle the 
// direction of tht rotating bit.
//
// Author: Michael Pearce, Chem Dept UOC.
//
// Started: 14 Jan 1998
//--------------------------------------
#include <pic.h>

//*****************************************************
//  Main - Start of the program
//*****************************************************
#define PATNUM 10
const unsigned char Pattern[PATNUM]=
{
	0x00,0x01,0x03,0x07,0x17,0x37,0x36,0x34,0x30,0x20
};

void main (void)
{
	unsigned char Pointer,count1,count2;
	struct
	{
	 unsigned int  Timer : 1;
	 unsigned int  Key   : 1;
	 unsigned int  Dir   : 1;
	}Flags;
 OPTION=0x84;    //- 1000 0100 Int Clk | PRE=32
 TRIS = 0x08;    //- GP0,1,2,4,5 = Out |  GP3 = In
 GPIO=0xFF;
 Pointer=0;
 count1=0;count2=0;
 TMR0=0;
 Flags.Dir=0;
 while(1)
 {
	 GPIO=Pattern[Pointer];
	 
 }
}
