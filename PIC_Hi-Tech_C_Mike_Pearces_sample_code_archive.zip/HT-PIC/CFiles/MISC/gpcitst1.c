//********************************************************
//                 gpcitst1.c
//
//  MS-DOS Executable To test the RS-232 Simulation Card
//
// Author: Michael Pearce
//        Chemistry Department, University of Canterbury
//
// Started: 10 March 1998
//*********************************************************
//#define DEBUG 1      //-- Turn Debug stuff on
#define Dly  1

#include <dos.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include "GPCIDRV.H"

#ifdef DEBUG
 int D_x,D_y;
#endif

void RunTest1(void),RunTest2(void);

void main (void)
{
 unsigned char AllDone=0;

 _setcursortype(_NOCURSOR);
 while(AllDone==0)
 {
  clrscr();
  puts("\r\nGPCI Test Program Version 2.00");
  puts("\r\n\nLoops Data Packets to/From Controler");
  puts("\r\n\nSearching for GPCI Interface.......");
  if(GPCIFindCard()==0)
  {
   puts("......Found it!!");
   puts("\r\n\nOptions:\n1 - Run Loop test 1\n2 - Run Loop Test 2\n0 - Exit");
   puts("\r\nAny Other key will repeat check");
   switch(getch())
   {
    case '0':
     AllDone=1;
     break;

    case '1':
     RunTest1();
     break;

    case '2':
     RunTest2();
     break;

    case 0:
     getch();    //-- Was a extended Key
    default:
     cputs("\r\nNon Option Key - repeating tests......");
     delay(1500);
     break;
   }
  }
  else
  {
   puts("......Not Found!");
   puts("\r\nExiting Program. Please ensure card is inserted correctly");
   AllDone=1;
  }
 }
 puts("\r\n\n Shutting Program Down......\r\n\n Goodbye.\r\n");
 _setcursortype(_NORMALCURSOR);
}

//----------- END OF MAIN ------------------


//***************************************************************
//                       RunTest1
//***************************************************************
static uchar Routine1[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x00};
static uchar Routine2[]="Testnum1";
static uchar Routine3[]="Hello";
static uchar Routine4[]="Goodbye";
void RunTest1(void)
{
 uchar loop,num,error,Data[20],Err[5];
 uint  Line;
 clrscr();
 puts("Test Routine 1: Sends and recieves 4 predefined packets several times.");
 puts("\r\n    Packet Sent             Packet Recieved         Error Number");
 puts("                                                     TX     RX");
 for(loop=0;loop<10;loop++)
 {
  for(num=1;num<5;num++)
  {
   switch(num)
   {
    case 1:
     strcpy(Data,Routine1);
     Line=1;
     break;

    case 2:
     strcpy(Data,Routine2);
     Line=2;
     break;

    case 3:
     strcpy(Data,Routine3);
     Line=3;
     break;

    case 4:
     strcpy(Data,Routine4);
     Line=4;
     break;
   }
   Line+=5;
   gotoxy(1,Line);
   cputs("                                                                   ");
   gotoxy(2,Line);
   puts(Data);
   error=GPCIWriteS(0,0,Data);
   gotoxy(54,Line);
   itoa(error,Err,10);
   puts(Err);

   gotoxy(30,Line);
   Data[0]=0; //-- Terminate string so not to get false data
   if(error==0)
   {
    error=GPCIReadS(0,0,&Data[0]);
    puts(Data);
   }
   else
   {
    puts(" **Error**  ");
   }
   gotoxy(61,Line);
   itoa(error,Err,10);
   puts(Err);

//   delay(500);
  }
 }
}
//***************************************************************
//                       RunTest2
//***************************************************************

void RunTest2(void)
{

}

