//**********************************************
//              TACHO1.C
//
// Using the internal timer as a time base and
// counting the number of interrupts between the
// time base overflow - results in the frequency 
// in Hz. Which if using a 60 pole input disk
// will result in the speed in RPM.
// This value is then displayed on an LCD or LED
// display of 4 digits.
//
// Author: Michael Pearce
//         Chemistry Dept Uni of Canterbury
//
// Started: 3 FEB 1998
//**********************************************
#include <pic.h>
#include "michaels.h"
#include "ledseg_0.h"

//---- Defines ----
#define  TIMERRELOAD  -97     // For 10Mhz / 256 / 97 /100 ~= 100Hz 
#define  CLKDIVIDERRELOAD 100 // the final divide.
#define  NUMDIGITS 4          // Number of display units

//---- Global Variables ----
uint  RPM=0;                 //- Last Value read.
uint  RPMCounter=0;          //- Current running count
uchar ClkDivider=100;        //- Divides interrupt by 100
uchar DispPos=0,DispNum=1;   //- Current display position

uchar TenThou,Thousand,Hundreds,Tens,Ones;
uchar ErrorNum;

uchar Disp[] =
{
	0x00,0x00,0x00,0x00
};

struct
{
	uint NewData  : 1;
	uint Error    : 1;
}Flags;



//---- Display Data ----
// Row 1 = '0' to '9'   Row 2 = 'A' to 'J' 
// Row 3 = 'K' to 'T'   Row 4 = 'U' to 'Z'
#define SPACE 0x00
uchar const SegmentData[36] =
{
	 S_0,S_1,S_2,S_3,S_4,S_5,S_6,S_7,S_8,S_9,
	 S_A,S_B,S_C,S_D,S_E,S_F,S_G,S_H,S_I,S_J,
	 S_K,S_L,S_M,S_N,S_O,S_P,S_Q,S_R,S_S,S_T,
	 S_U,S_V,S_W,S_X,S_Y,S_Z
};

//---- Functions ----
void  ConvertData(void);
uchar AToSeg(uchar Ascii);

//***********************************************
//main
//***********************************************
void main (void)
{
 OPTION=0x07;   //-  0000 0111  - setup portb, timer, prescale=256
 TMR0=0x00;     //-  Big Start Reload.
 TRISA=0x10;    //- Display select output + 1 key input (RA4)
 TRISB=0x01;    //- RB0 is the Interrupt input pin rest == display
 
 while(1)
 {
	 if(Flags.NewData==1)
	 {
		 //-- New Data so process and display it
		 Flags.NewData=0;
		 if(Flags.Error==0)
		 {
			 //-- Break down into thousands...... ones
		  TenThou  = RPM /10000;  //-- Not displayed on 4 digit system
		  Thousand = (RPM-=(TenThou*10000)) / 1000;
		  Hundreds = (RPM-=(Thousand*1000)) / 100;
		  Tens     = (RPM-=(Hundreds*100))  / 10;
		  Ones     = RPM-(Tens*10);
		 }
		 else
		 {
			 //-- Error Occured so display 'Err' and Number
			 TenThou  = ' ';  //-- Not displayed on 4 digit system
			 Thousand = 'E';
			 Hundreds = 'R';
			 Tens     = 'R';
			 Ones     = ErrorNum;
			 Flags.Error=0;   //-- Turn Error Flag off since displayed
		 }
		 ConvertData();  //-- Convert the data to displayable information
	 }
 }
}
//************** END OF main

//***********************************************
//DoInt
//***********************************************
void interrupt DoInt (void)
{
 if(INTF==1)
 {
	 INTF=0;
	 RPMCounter++;
	 if(RPMCounter==0)
	 {
		 //-- Greater than 65000 RPM - Too Fast
		 Flags.Error=1;
		 ErrorNum='1';
	 }
 }

	if(T0IF==1)
	{
		TMR0=TIMERRELOAD;
		T0IF=0;
		if((ClkDivider--)==0)
		{
			ClkDivider=CLKDIVIDERRELOAD;
			RPM=RPMCounter;
			RPMCounter=0;
			Flags.NewData=1;
		}
	}
 //---- Display the next digit ----
 DispPos++;
 PORTB=SPACE;       //-- Output Blank to port
 PORTA=(DispNum<<1);          //-- Rotate Port Left 1
 if(DispPos >= NUMDIGITS)
 {
	 DispPos=0;
	 DispNum=1;
	 PORTA=DispNum;
 }
 PORTB=Disp[DispPos];
 
}
//************** END OF DoInt

//***********************************************
//ConvertData
//***********************************************
void ConvertData(void)
{
	//-- Converts from Number or letter to 7 seg format
	//-- and stores it in the Display array
	Disp[0]=AToSeg(Thousand);
	Disp[1]=AToSeg(Hundreds);
	Disp[2]=AToSeg(Tens);
	Disp[3]=AToSeg(Ones);
}
//************** END OF ConvertData

//***********************************************
//AToSeg - converts Ascii to 7 segment display
//
//-- Only interested in ASCII....
//              0x20       ' '  (Space)
//              0x30-0x39  '0' to '9'
//              0x41-0x5A  'A' to 'Z'
//-- This covers most of the avaliable characters
//***********************************************
uchar AToSeg(uchar Ascii)
{
 if(Ascii >= 0x30 && Ascii <= 0x39)
 {
	 //-- It is a Number.
	 Ascii -=0x30;   //-- Calc target position in array
	 return(SegmentData[Ascii]);
 }
 else
 {
  if(Ascii >=0x41 && Ascii <=0x5A)
  {
	  //-- It is a Letter
	  Ascii= Ascii-0x41+10; //-- Calc target position in array
	  return(SegmentData[Ascii]);
  }
  else
  {
	  if(Ascii < 10)
	  {
		  //-- Could be actual raw number - not ascii !!!
		  return(Ascii);
	  }
  }
 }
 //-- If get this far then not avaliable character or a SPACE
 return(SPACE);
}
//************** END OF AToSeg

//***********************************************
//
//***********************************************

//************** END OF

//***********************************************
//
//***********************************************

//************** END OF

//***********************************************
//
//***********************************************

//************** END OF

//***********************************************
//
//***********************************************

//************** END OF








