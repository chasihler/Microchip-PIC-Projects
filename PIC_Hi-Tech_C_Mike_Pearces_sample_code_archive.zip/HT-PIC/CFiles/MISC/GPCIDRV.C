//********************************************************
//                    GPCIDRV.C
//
// Hardware driver Functions for the serial Port simulator
// interface card.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 18 - Mar - 1998
//********************************************************
#define DEBUG 99
//---- Include Files Required ----
#include <dos.h>
#include <string.h>
#include "GPCI.h"             //-- Command,Start,Stop byte definitions etc

//---- Some defines that are required
#ifndef uchar
 #define uchar unsigned char         //-- Define uchar
#endif
#ifndef uint
 #define uint unsigned int           //-- Define uint
#endif


//---- DEBUG STUFF ----
#ifdef DEBUG
 #include <stdio.h>
 #include <conio.h>
 uint DEBUG_X,DEBUG_Y;             //-- X and Y values for getxy.
 uint DEBUG_X1,DEBUG_Y1;
 void wizzy(void);
 uchar wizzypos =0;
#endif

//---- GPCI Interface Defines ----
#define RETRY_TIME 10            //-- ms between retrys
#define READ_WAIT_TIME 100       //-- Wait time for read cycles
#define DELAY_TIME 2             //-- ms between reads/writes

#ifdef DEBUG
 #define MAXERROR  15             //-- Number of retrys before giving up!
#else
 #define MAXERROR  20
#endif


//**************************************************************
//            LOW LEVEL FUNCTION DEFINITIONS
//**************************************************************
//-- Function For writing data packet to GPCI Interface
uchar GPCITXD
(
 uint PortAddress,
 uchar BusAddress,
 uchar Command,
 uchar SubAddress,
 uchar Data[],
 uchar Length
);
//-- Function for receiving a data packet back
extern uchar GPCIRXD(uint PortAddress, uchar *data);



//**********************************************************
//              HIGH LEVEL GPCI FUNCTIONS
//**********************************************************
//-- Read Byte from GPCI Device --
uchar GPCIReadB(uchar Address,uchar SubAddr,uchar *Data);

//-- Write Byte to GPCI Device --
uchar GPCIWriteB(uchar Address,uchar SubAddr,uchar Data);

//-- Read String from GPCI Device --
uchar GPCIReadS(uchar Address,uchar SubAddr,uchar *Data);

//-- Write String to GPCI Device --
uchar GPCIWriteS(uchar Address,uchar SubAddr,uchar Data[]);

//-- Set GPCI Bus Speed --
uchar GPCISpeed(uchar Speed);

//-- Set Read/Write Mode - AutoInc / NoInc for individual Addresses
uchar GPCIRWMode(uchar Address,uchar Mode);

//-- Find And Configure Interface Card
uchar GPCIFindCard(void);


//**************************************************************
//             INTERNAL ONLY GLOBAL VARIABLES
//**************************************************************
uchar MaxInterfaceData = 0;  //-- Max Packet size for current Interface
uchar InterfaceType = 0;     //-- Smart or Dumb Interface Indicator
uint  IOPortAddress = 0;     //-- Port address for card


//################################################################
//                   FUNCTIONS START HERE
//################################################################


//**************************************************************
//GPCIWriteS  -  Writes a String to GPCI Device
//**************************************************************
uchar GPCIWriteS(uchar Address,uchar SubAddr,uchar Data[])
{
 uchar Length,Result,Command=0;
 Length=strlen(Data);
 Command+=GPCI_WRITE+GPCI_SLOW+GPCI_ECHO_ON; //---- DUMMY TEST ONLY ----
 Result=GPCITXD(IOPortAddress,Address,Command,SubAddr,Data,Length);
 switch(Result)
 {
  case 0:
   //-- Everything went well
   return(0);

  case 1:
  case 2:
  case 254:
  case 255:
   //-- Error Occured - If smart controler find out what and try to fix
   return(Result);
 }
 return(128);   //-- Unknown Error
}
//************** END OF GPCIWriteS

//**************************************************************
//GPCIReadS - Read String from GPCI Device
//**************************************************************
uchar GPCIReadS(uchar Address,uchar SubAddr,uchar *Data)
{
 uchar Result;
 Result=GPCIRXD(IOPortAddress,Data);
 switch(Result)
 {
  case 0:
   //-- Everything went well
   return(0);

  case 1:
  case 2:
  case 254:
  case 255:
   //-- Error Occured - If smart controler find out what and try to fix
   return(Result);
 }
 return(128);   //-- Unknown Error
}
//************** END OF GPCIReadS


//**************************************************************
// GPCIFindCard - Find And Configure Interface Card
//**************************************************************
uchar GPCIFindCard(void)
{
 uint ports[4]={0x3F8,0x2F8,0x3E8,0x2E8};
 uchar TempC,TempC2;
 IOPortAddress=0; //-- Indicate No Address till it is found.
 for(TempC=0;TempC<4;TempC++)
 {
  #ifdef DEBUG
   printf("\nCount = %d  Checking addr %X + 2...",TempC,ports[TempC]);
   delay(10);
  #endif

  //-- Check each Serial Port until found a GPCI Device of run out of ports
  TempC2=inportb(ports[TempC]+2);

  if((TempC2 & 0x80)==0x80)
  {
   //-- Possible GPCI found - check if it is
   if(TempC2!=0xFF)
   {
    //-- Yep - Found it!!
    InterfaceType = (TempC2 & 0x08) >> 3;  //-- Get Smart or Dumb Type
    IOPortAddress=ports[TempC];            //-- Set the Port Address
    //-- Get Max data buffer size
    TempC=(TempC2 & 0x70 ) >> 4;
    switch(TempC)
    {
     case 0:
      //-- Ask the Interface for the data size (Must be a smart one
      MaxInterfaceData = 0; //-- unable to do at the moment
      break;

     case 1:
      MaxInterfaceData = 4;
      break;
     case 2:
      MaxInterfaceData = 8;
      break;
     case 3:
      MaxInterfaceData = 16;
      break;
     case 4:
      MaxInterfaceData = 32;
      break;
     case 5:
      MaxInterfaceData = 64;
      break;
     case 6:
      MaxInterfaceData = 128;
      break;

     case 7:
      MaxInterfaceData = 252;            //-- Maximum Data Size
      break;

     default:
      MaxInterfaceData = 0;              //-- Not valid Data
      break;
    }
    #ifdef DEBUG
     printf("\r\nData Buffer Size = %d",MaxInterfaceData);
     if(InterfaceType==0)
     {
      printf("\r\nInterface Type = Dumb\n");
     }
     else
     {
      printf("\r\nInterface Type = Smart\n");
     }
    #endif

    return(0);                          //-- Return an O.K.
   }
  }
 }
 return(1);                             //-- Return an Error - could not find!
}
//************ End Of GPCIFindCard


//**************************************************************
// GPCITXD - Sends data to the GPCI Interface Card
//**************************************************************
uchar GPCITXD(uint PortAddress,uchar BusAddress,uchar Command,
                      uchar SubAddress,uchar Data[],uchar Length)
{
 uchar GPCICount,GPCIAddress=0,GPCIChecksum=0;
 uchar TempC,TempC1,done=0,Started=0;
 uint  errorcount=0,FrameCount=0;
 if(PortAddress==0) return(1); //-- No Device to send anything to.
 if(Length > MaxInterfaceData) return(2); //-- More data than device can handle

 //---- Set Up the Start Address Byte ----
 if(BusAddress >7)
 {
   //-- Sending Information to Controler So set up D7,D6 of Byte
   TempC=BusAddress & 0x18;   //-- Clear actual Address out leaving Ctrlr Info
   TempC=TempC << 3;          //-- Shift Left so is in Top Two Bytes
   GPCIAddress=GPCIAddress | TempC; //-- Or with current info in Address
 }
 TempC=BusAddress & 0x07;           //-- Clear out unwanted Bits
 GPCIAddress=GPCIAddress | TempC;   //-- Or into address byte
 TempC=SubAddress & 0x07;           //-- Clear unwanted bits form subaddress
 TempC=TempC << 3;                  //-- Move into correct position in Byte
 GPCIAddress=GPCIAddress | TempC;   //-- Ad the sub address to the Address Byte

 //---- Calculate Number of Characters in Packet ----
 GPCICount=3;      //- Minimum Packet bytes to send
 if(Length==0)
 {
  //-- No Data Bytes to send So check for Address - if < 0x40 then do not send
  if((GPCIAddress & 0xF0) > 0x40)
  {
   GPCICount++;   //-- Required to send Address for Control use only
  }
 }
 else
 {
  GPCICount+=(1+Length); //-- Need Address Byte + Data bytes added on.
 }

 //---- Calculate The Checksum ----
 GPCIChecksum+=GPCICount+Command+GPCIAddress; //-- everything apart from Data
 for(TempC=0;TempC<(Length-1);TempC++)
 {
   GPCIChecksum+=Data[TempC];  //-- Add each Byte of the Data
 }
 #ifdef DEBUG
  DEBUG_X=wherex();
  DEBUG_Y=wherey();
  gotoxy(1,24);
  puts("                                                                     ");
  gotoxy(1,24);
  printf("Addr=0x%X, Count=0x%X, Com=0x%X, Check=0x%X, Data=\"%s\" ",
          GPCIAddress,GPCICount,Command,GPCIChecksum,Data );
  gotoxy(DEBUG_X,DEBUG_Y);
  delay(500);
 #endif


 //---- Send The data ----
 #ifdef DEBUG
  DEBUG_X=wherex();
  DEBUG_Y=wherey();
  gotoxy(1,20);
  puts("                                                                     ");
  gotoxy(1,20);
 #endif
 Started=0;
 while(done==0 && errorcount < MAXERROR)
 {
//  Started=0;
  #ifdef DEBUG
   wizzy();
  #endif
  if( (inportb(PortAddress+2) & 0x04) == 0x04) //-- Check TX bit
  {
   //-- OK to send data byte
   switch(Started)
   {
    case 0:
     outportb(PortAddress,STARTBYTE);    //-- Send Start Byte
     Started++;
     #ifdef DEBUG
      putch(STARTBYTE);
     #endif
     break;

    case 1:
     outportb(PortAddress,GPCICount);    //-- Send Count Byte
     Started++;
     #ifdef DEBUG
      putch('N');
     #endif
     break;

    case 2:
     outportb(PortAddress,Command);      //-- Send Command Byte
     Started++;
     #ifdef DEBUG
      putch('C');
     #endif
     break;

    case 3:
     outportb(PortAddress,GPCIAddress);  //-- Send GPCI Address Byte
     Started++;
     TempC=Length;
     TempC1=0;
     #ifdef DEBUG
      putch('A');
     #endif
     break;

    case 4:
     outportb(PortAddress,Data[TempC1]);  //-- Send Data byte
     #ifdef DEBUG
      putch(Data[TempC1]);
     #endif
     TempC1++;                            //-- Point to next byte
     if( (TempC--) == 1) Started++;       //-- Check for end of data
     break;

    case 5:
     outportb(PortAddress,GPCIChecksum); //-- Send Checksum
     Started++;
     #ifdef DEBUG
      putch('C');
     #endif
     break;

    case 6:
     outportb(PortAddress,STOPBYTE);     //-- Send STOP Byte
     Started++;
     #ifdef DEBUG
      putch(STOPBYTE);
     #endif
     break;

  //  case 7:  ///------------------------- presume got the stop Byte!!
    default:
     done=1;
     break;
   }
   delay(DELAY_TIME);    //-- Delay to sort transfer out
  }
  else
  {
   #ifdef DEBUG
    DEBUG_X1=wherex();
    DEBUG_Y1=wherey();
    gotoxy(1,23);
    printf("Device Not ready. Base+2 = 0x%X",inportb(PortAddress+2));
    delay(300);
    gotoxy(1,23);
    printf("                                       ");
    gotoxy(DEBUG_X1,DEBUG_Y1);
   #endif
   delay(RETRY_TIME);      //-- Wait a period before retrying
   errorcount++;  //-- If cannot get it before timing out then something wrong
  }
  if( (inportb(PortAddress+5)&0x08) == 0x08)
  {
   //-- Frame Error Has Occured
   //-- If smart Controler can try to ask what happened otherwise
   //   just retry sending the packet.
   errorcount++;
   FrameCount++;
   Started=0;         //-- Start from scratch again
   #ifdef DEBUG
    putch('*');
    DEBUG_X1=wherex();
    DEBUG_Y1=wherey();
    gotoxy(1,23);
    printf("Frame Error: Base+5 = 0x%X",inportb(PortAddress+5));
    delay(300);
    gotoxy(1,23);
    printf("                                       ");
    gotoxy(DEBUG_X1,DEBUG_Y1);
   #endif
   delay(RETRY_TIME);      //-- Wait a period before retrying
   errorcount++;  //-- If cannot get it before timing out then something wrong
  }
  #ifdef DEBUG
   if(kbhit()!=0)
   {
    if(getch()==0x1b)
    {
     errorcount=MAXERROR;  //-- Forced exit by User
    }
   }
  #endif
 }
 #ifdef DEBUG
  gotoxy(DEBUG_X,DEBUG_Y);
 #endif
 if(errorcount==MAXERROR)
 {
  if(FrameCount !=0)
  {
   return(254); //-- Framing Error
  }
  return(255);  //-- Overflow Error
 }
 return(0);
}



//**************************************************************
// GPCIRXD - Receives data from the GPCI Interface Card
//**************************************************************
extern uchar GPCIRXD(uint PortAddress, uchar *data)
{
 uchar done=0,Count=0,Checksum=0,Started=0,Data;
 uchar CheckOk=0,*DataArray;
 uint errorcount=0;
 #ifdef DEBUG
  uint tx,ty;
  tx=wherex();
  ty=wherey();
 #endif

 if(PortAddress==0x00)return(1);

 #ifdef DEBUG
  gotoxy(1,21);
 #endif
 while(done==0 && errorcount < MAXERROR)
 {
  #ifdef DEBUG
   wizzy();
   DEBUG_X=wherex();
   DEBUG_Y=wherey();
   gotoxy(1,23);
   printf("RXD: Base+2 = 0x%X ",inportb(PortAddress+2));
   gotoxy(DEBUG_X,DEBUG_Y);
  #endif



  if((inportb(PortAddress+2)& 0x02) == 0x02)
  {
   //-- Have Ok to read data
   Data=inportb(PortAddress);            //-- Read in the byte
   #ifdef DEBUG
    putch(Data);
   #endif

   if(Started==0)
   {
    //-- Check for Start Byte
    if(Data==STARTBYTE)
    {
     Started=1;
     DataArray=data;
     #ifdef DEBUG
      putch(Data);
     #endif
    }
   }
   else
   {
    if(Started==1)
    {
     //-- read in the count  - note is is the first byte in the array
     Count=Data;
     Started++;
     #ifdef DEBUG
      putch('N');
     #endif
    }
    if(Count==1)
    {
     //-- Check the checksum
     if(Data==Checksum)
     {
      CheckOk=1;
      #ifdef DEBUG
       putch('C');
      #endif
     }
     else
     {
      #ifdef DEBUG
       putch('*');
       gotoxy(tx,ty);
      #endif
      return(254);  //-- Packet Frame Checksum Error
     }
    }
    if(Count==0)
    {
     //-- check for Stop Byte
     if(Data==STOPBYTE)
     {
      #ifdef DEBUG
       putch('f');
      #endif

      done=1;
      #ifdef DEBUG
       gotoxy(tx,ty);
      #endif
      return(0); //-- All Done
     }
     else
     {
      #ifdef DEBUG
       putch('*');
       gotoxy(tx,ty);
      #endif
      return(255); //-- Packet Error
     }
    }
    if(done==0 && CheckOk==0)
    {
     *DataArray=Data;  //-- Store the data in the array
     DataArray++;      //-- Point to next data Byte
     Count--;
     #ifdef DEBUG
      putch(Data);
     #endif

    }
   }
   delay(DELAY_TIME);    //-- Delay to sort transfer out
  }
  else
  {
   delay(READ_WAIT_TIME);
   errorcount++;
  }
 }
 #ifdef DEBUG
  putch('*');
  gotoxy(tx,ty);
 #endif

 if(errorcount >= MAXERROR)
 {
  return(255);  //-- Overflow error - No data was avaliable
 }
 return(128); //-- Unknown error - should not get here
}

//***************************************************************
// wizzy - Indicator to show stuff working used by  DEBUG
//***************************************************************
#ifdef DEBUG
 void wizzy(void)
 {
  int x,y;
  x=wherex();
  y=wherey();
  gotoxy(79,24);
  switch(wizzypos)
  {
   default:
    wizzypos=0;
   case 0:
    putch('|');
    break;

   case 1:
    putch('/');
    break;

   case 2:
    putch('-');
    break;

   case 3:
    putch('\\');
    break;
  }
  wizzypos++;
  gotoxy(x,y);
 }
#endif
