;	global	?a_main
;	global	_PATTERN
;	global	_main
;	signat	_main,88
;	FNSIZE	_main,3,0
;	global	start
;	global	string_table
;	global	used_btemp0
	processor	12C509
;	psect	strings,global,class=STRING,delta=2
;	psect	text0,local,class=CODE,delta=2
;	psect	ctext1,local,size=512,class=ENTRY,delta=2
;	psect	temp,global,ovrld,class=BANK0,space=1
;	file	"C:\WINDOWS\TEMP\$$027449.000"


;	psect	strings
_PATTERN
	retlw	1
	retlw	3
	retlw	7
	retlw	15
	retlw	31
	retlw	63
	retlw	127
	retlw	-1
	retlw	1
	retlw	2
	retlw	4
	retlw	8
	retlw	16
	retlw	32
	retlw	64
	retlw	-128
	retlw	3
	retlw	6
	retlw	12
	retlw	24
	retlw	48
	retlw	96
	retlw	-64
	retlw	-128
	retlw	3
	retlw	14
	retlw	28
	retlw	56
	retlw	112
	retlw	-32
	retlw	-64
	retlw	-128
	retlw	-127
	retlw	66
	retlw	36
	retlw	24
	retlw	24
	retlw	36
	retlw	66
	retlw	-127
	retlw	24
	retlw	66
	retlw	36
	retlw	-127
	retlw	-127
	retlw	66
	retlw	36
	retlw	24
	retlw	-61
	retlw	102
	retlw	24
	retlw	102
	retlw	-61
	retlw	102
	retlw	24
	retlw	-61
	retlw	-1
	retlw	0
	retlw	15
	retlw	-16
	retlw	3
	retlw	-64
	retlw	-128
	retlw	1
	retlw	-86
	retlw	55
	retlw	-86
	retlw	55
	retlw	-86
	retlw	55
	retlw	-86
	retlw	55
	retlw	-37
	retlw	109
	retlw	-37
	retlw	109
	retlw	-37
	retlw	109
	retlw	-37
	retlw	109
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0
	retlw	0

	psect	text0           
_main
;	_next assigned to ?a_main+0
;	_Position assigned to ?a_main+1
;	_Sequence assigned to ?a_main+2
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 52: unsigned char Sequence=0,Position=0,next;
	bcf	4,5
	clrf	(?a_main+2)& (0+31)
	clrf	(?a_main+1)& (0+31)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 54: TRIS = 0x28;
	movlw	40
	tris	6
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 56: while(1)
l3
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 57: {
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 59: if(Sequence > 16) Sequence=0;
	movlw	17
	bcf	4,5
	subwf	(?a_main+2)& (0+31),w
	btfss	3,0
	goto	l5
	bcf	4,5
	clrf	(?a_main+2)& (0+31)
l5
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 60: if(Position > 8 ) Position=0;
	movlw	9
	bcf	4,5
	subwf	(?a_main+1)& (0+31),w
	btfss	3,0
	goto	l6
	bcf	4,5
	clrf	(?a_main+1)& (0+31)
l6
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 62: GPIO = PATTERN[ (Sequence * 8) + Position ];
	movlw	_PATTERN& (0+255)
	movwf	btemp
	bcf	3,0
	bcf	4,5
	rlf	(?a_main+2)& (0+31)
	bcf	3,0
	rlf	(?a_main+2)& (0+31)
	bcf	3,0
	rlf	(?a_main+2)& (0+31),w
	addwf	(?a_main+1)& (0+31),w
	addwf	btemp,w
	lcall	string_table
	movwf	6
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 64: next=0;
	clrf	?a_main& (0+31)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 65: while(next==0)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 80: }
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 81: }
l7
	bcf	4,5
L1
	movf	?a_main& (0+31)
	btfss	3,2
	goto	l3
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 68: {
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 70: Position++;
	bcf	4,5
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 66: {
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 67: if(Beat==1)
	btfss	6,0
	goto	L2
	incf	(?a_main+1)& (0+31)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 71: next=1;
	clrf	?a_main& (0+31)
	incf	?a_main& (0+31)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 72: while(Beat);
l11
	btfsc	6,0
	goto	l11
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 75: {
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 77: Sequence++;
	bcf	4,5
L2
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 73: }
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 74: if(Select==0)
	btfsc	6,1
	goto	L1
	incf	(?a_main+2)& (0+31)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 78: next=1;
	clrf	?a_main& (0+31)
	incf	?a_main& (0+31)
;C:\PIC\HITECHC\SOURCE\DISCO_1.C: 79: while(Select==0);
l15
	btfsc	6,1
	goto	l7
	goto	l15

	psect	ctext1

	psect	temp
btemp
	ds	1
