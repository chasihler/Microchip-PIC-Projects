#include <stdio.h>

#define FREQ 12MHZ

#define MHZ  *1000


void main(void)
{
 printf("%d",(FREQ)/(12 MHZ));
 getch();

}