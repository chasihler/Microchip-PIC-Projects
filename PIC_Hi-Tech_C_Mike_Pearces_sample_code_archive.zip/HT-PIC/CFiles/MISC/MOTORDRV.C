//*********************************************************************
//                         MOTORDRV.C
//
// Cut down version of the GPCI PWM Motor Driver - All the GPCI section
// has been removed and the control is via Faster/Slower Buttons.
// The buttons increase/decrease speed but 50RPM per time.
// This code has been done to get the basic control side of things 
// Operating correctly and Bug free.
//
// Inputs:  60 PPR Pulse      Port B,0
//          UP Key            Port B,1
//          Down Key          Port B,2
//          Direction         Port B,3
//
// Outputs: PWM               Port C,2
//          DIR               Port C,1
//          ERR               Port C,0
//
// Author: M.O.Pearce Chem Dept UOC
//
// Started: 15 Jan 1998
//
//*********************************************************************

#include <pic.h>
#include "michaels.h"

//-- Defines --
#define  ChkCntRELOAD 70 //-- # ints between checking speed
#define  SPEED 50         //-- Amount to change speed by
#define  MAXSPEED 4000    //-- Maximum Speed
#define  MINSPEED 0       //-- Minimum Speed
#define  DIVIDED  40000   //-- For 100us to shift up to normal Number
#define  TMR0RELOAD -118  // 20Mhz/4/125 -a few cycles = approx 25us 
#define  MAXPWM   0xFE    //-- Max PWM duty cycle - slightly less than MAX
#define  MINPWM   0x01    //-- Min PWM cycle - still has slight output level


//-- Port Assignments --
static bit Faster     @ PORTBIT(PORTB,1); // INPUT  - Go Faster
static bit Slower     @ PORTBIT(PORTB,2); // INPUT  - Go Slower
static bit PulseInt   @ PORTBIT(PORTB,0); // INPUT  - Period Int
static bit DirSel     @ PORTBIT(PORTB,3); // INPUT  - Select Dir
static bit ErrorLED   @ PORTBIT(PORTC,0); // OUTPUT - Error LED
static bit DirPort    @ PORTBIT(PORTC,1); // OUTPUT - Direction
static bit PWMPort    @ PORTBIT(PORTC,2); // OUTPUT - PWM
static bit TSTPort1   @ PORTBIT(PORTC,3); // OUTPUT - Interrupt Test
static bit TSTPort2   @ PORTBIT(PORTC,4); // OUTPUT - Timer Test
static bit TSTSpeed   @ PORTBIT(PORTC,5); // OUTPUT - Speed adjust

//-- Global Variables --
uint  PeriodCount;
uint  ComparePeriod;
uint  PeriodCheck;
uint  RequiredSpeed;

struct
{
	 uint KeyFast   : 1 ;
	 uint KeySlow   : 1 ;
	 uint KeyDir    : 1 ;
	 uint PeriodOvf : 1 ;  //-- If counter overflows
	 uint SpeedOvf  : 1 ;  //-- If Speed overflows
} Flags;

//-- Function Definitions --
void CheckKeys(void);
void SetPeriod(void);
void CheckSpeed(void);
void Pause(void);
//static void interrupt CheckInterrupt(void);

//************************************************
// MAIN - Start of the Program    
//************************************************
void main (void)
{
 OPTION=0x00;  //- reset the option register
	TRISB=0xFF;   //-- All inputs
	TRISC=0x00;   //-- All Outputs
 PR2=0xFF;     //- Fastest Period for the PWM (19.53 Khz @ 10 Bit)

 GIE=0;        //- Disable all interrupts

 CCP1CON=0x0C;   //- 00001100 - Put into PWM mode - 8 bit mode
 CCPR1L=MINPWM;  //-- Start at zero speed
 T2CON=0x04;     //-- turn timer 2 on with no post or pre scale.

 TMR0=TMR0RELOAD;
 
 RequiredSpeed=0x00; //-- Start stopped
 ComparePeriod=0xFFFF; 
 PeriodCount=0x0000;

// INTCON=0xB0;  // 10110000  GIE,T0IE,INTE
 T0CS=0;
 T0IE=1;
 INTEDG=0;
 INTE=1;
 GIE=1;

// Set up flags
 Flags.SpeedOvf=0;
 Flags.PeriodOvf=0; 
 
 while(1)
 {
	 CheckKeys();  //-- Check the keys for changes etc
	 SetPeriod();  //-- Continually update the Period
	 CheckSpeed(); //-- Check for Stall or not running
  Pause(); 
 }
}

//**************************************************
//Check Keys
//**************************************************
static bit Direction;
void CheckKeys(void)
{
  //------ Check for FASTER --------
  if(Faster==0 && Flags.KeyFast==0)
  {
	  Flags.KeyFast=1;
	  if(RequiredSpeed < MAXSPEED)
	  {
	   RequiredSpeed+=SPEED;
//	   if(CCPR1L < 0xF0) CCPR1L+=8;   //-- Add some power for increase in speed
	  }
  }
  else
  {
	  if(Faster==1) Flags.KeyFast=0;
  }
  //------ Check for SLOWER -------
  if(Slower==0 && Flags.KeySlow==0)
  {
	  Flags.KeySlow=1;
	  if(RequiredSpeed > MINSPEED)
	  {
	   RequiredSpeed-=SPEED;
	  }
  }
  else
  {
	  if(Slower==1) Flags.KeySlow=0;
  }
  //------- Check For DIRECTION ------
  if(DirSel==0 && Flags.KeyDir==0)
  {
	  Flags.KeyDir=1;
	  //-- Toggle the Direction
	  DirPort=(Direction^=1);
  }
  else
  {
	  if(DirSel==1) Flags.KeyDir=0;
	 }
}
//**************************************************
// SetPeriod - Calculates the period using RPM
//**************************************************
void SetPeriod(void)
{
	 if(RequiredSpeed > 0)
	 {
   ComparePeriod= DIVIDED/RequiredSpeed;
	 }
	 else
	 {
		 ComparePeriod=0xFF;
	 }
}
//**************************************************
// CheckSpeed - Checks if motor is at current speed
//**************************************************
void CheckSpeed(void)
{
	if(Flags.PeriodOvf==1)
	{
		//-- At Maximum power Plus running slow/stalled
  ErrorLED=1;
	}
 else
 {
	 ErrorLED=0;
	}		

}

//**************************************************
// CheckInterrupt - does the interrupt stuff
//**************************************************
static bit T_Toggle,I_Toggle;
static uint ChkCounter;
static void interrupt CheckInterrupt(void)
{
	if(T0IF==1)
	{
		TMR0=TMR0RELOAD;
		T0IF=0;
		PeriodCount++;
		if(PeriodCount==0x0000)
		{
			if(ComparePeriod < 0xFFFF)
			{
			 Flags.PeriodOvf=1;       //-- Overflow Occured
			 PeriodCount=0xFFFF;      //-- Keep Value high until Cleared.
			}
		}
		else
		{
			Flags.PeriodOvf=0;
		}
		TSTPort2=(T_Toggle^=1);
	}
	if(INTF==1)
	{
		//-- External Interrupt - Compare Period Values
		PeriodCheck=PeriodCount;
		TMR0=TMR0RELOAD;
		PeriodCount=0;
		INTF=0;
  //-- TEST  - Toggle every time interrupt occurs
  TSTPort1=(I_Toggle^=1);
	}
	
	//-- Check speed every xth interrupt
	if((ChkCounter--)==0 || Flags.PeriodOvf==1)
	{
		ChkCounter=ChkCntRELOAD;
	 if(PeriodCheck < ComparePeriod)
	 {
		 //-- Slow Down
	 	if(CCPR1L > MINPWM)
	 	{
	 		CCPR1L--;
	 		TSTSpeed=0;   //-- Indicate that in this area
	 	}
	 }
	 else
 	{
 		if(PeriodCheck > ComparePeriod)
 		{ 
	 		//-- Speed Up
 		 if(CCPR1L < MAXPWM)
 		 {
			  CCPR1L++;
			  TSTSpeed=1;  //-- Indicate that in this area
 		 }
 		}
 	}
		if(Flags.PeriodOvf==1)
		{
 		CCPR1L=MAXPWM;  //-- give it full power to try and get out of Jam
 	}
 }
}
//*******************************************
// PAUSE
//*******************************************
void Pause(void)
{
	uchar count,count1;
	for(count=0;count<0xff;count++)
	{
		count1+=count;
	}
}

