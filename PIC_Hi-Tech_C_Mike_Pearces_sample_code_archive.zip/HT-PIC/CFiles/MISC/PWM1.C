// PWM test program
// For the 16C64 on the GPCI development kit 1.11
//
// Author:  Michael Pearce
//          Chemistry Dept, University of Canterbury
//
// Started: 7 Jan 1998
//

#include <pic.h>
#include "michaels.h"         //-- for uint,uchar,BITS,BITBYTE

static bit PC0 @ PORTBIT(PORTC,0);
static bit PC1 @ PORTBIT(PORTC,1);

void delay(int time);

void main (void)
{
  uchar keydly;	
  OPTION=0x00;  //- reset the option register
  GIE=0;        //- Disable all interrupts
  CCP1CON=0x0C; //- 00001100 - Put into PWM mode - 8 bit mode
//  CCP1CON=0x3C; //- 00111100 - Put into PWM mode - 10 bit mode
  
  PR2=0xFF;     //- Fastest Period for the PWM (19.53 Khz @ 10 Bit)
  TRISC=0xFB;   //- port C = xxxx x0xx  PWM==Output mode
  CCPR1L=0x80;  //-- 50% duty cycle to start with
  T2CON=0x04;   //-- turn timer 2 on with no post or pre scale.

  while(1)
  {
	   if(PC0==0)
	   {
		   CCPR1L++;
	   }
	   if(PC1==0)
	   {
		   CCPR1L--;
	   }
	   //-- wait for key to be released or delay to run out
	   keydly=0;
	   while(PC0==0 | PC1==0)
	   {
		   delay(100);
		   if((keydly++)<10) break;
	   }
	 }
}

void delay(int time)
{
	 int count=0,dly1,dly2;
	 for(;count<time;count++)
	 {
		 for(dly1=0;dly1<1000;dly1++)
		 {
			  dly2+=dly1;
		 }
	 }
}
