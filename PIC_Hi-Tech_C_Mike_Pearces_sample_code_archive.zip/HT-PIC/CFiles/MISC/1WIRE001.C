//********************************************************************
//                        1WIRE001.C
//
// Code so that a PIC can communicate with Dallas 1-wire bus devices
//
// Low Level Functions called from external:
//            TouchReset - Resets the Bus
//            TouchByte  - Writes and reads data
//
// High Level Functions called from external:
//            TouchSendAddr - Select addressed device for read/write
//            TouchGetAddr  - Reads an address (single device on bus only!)
//            TouchSetUp    - Sets up port registers etc
//
//
// Author: Michael Pearce
//         Electronics Workshop,
//         Chemistry Department, University of Canterbury.
//
// Started: Tuesday 2nd June 1998
//
//********************************************************************


#ifndef DELAY_ROUTINE
 #include "delay.h"   //-- Include the delay routines
#endif

//-- Type Defines required --
#ifndef MikesLibrary
 #include "michaels.h"
#endif

//-- The 64 bit address for dallas devices
typedef struct
{
 uchar Family;         //-- Family Code
 uchar SerialNum[6];   //-- 48 bit serial number (LSB in 0 MSB in 5)
 uchar CRC;            //-- CRC for the whole lot!!
}T_ADDR;


//-- Functions called from External
uchar  TouchSetUp(void);            //-- Sets up port registers etc
uchar  TouchReset(void);            //-- Resets the 1-wire bus
uchar  TouchByte(uchar Byte);       //-- Sends and recieves the data
uchar  TouchSendAddr(void); // Select addressed device for read/write
void   TouchGetAddr(void);          // Reads address from ONLY device on bus!


//-- Internal Functions --
void TouchClearErrors(void);        // clears the error message list


//-- Ports Used - MUST BE DEFINED PRIOR TO THIS  --
#ifndef TOUCHPORT
 #define TOUCHPORT PORTA            //- Port that pin I/O pin is on
#endif
#ifndef TOUCHTRIS
 #define TOUCHTRIS TRISA            //- The TRIS register used.
#endif
#ifndef TOUCHPIN
 #define TOUCHBIT 0                 //- Bit address of pin on the port
#endif

static bit OneWire @ PORTBIT(TOUCHPORT,TOUCHBIT);//-- I/O Pin for one wire bus
static bank1 bit TouchTris @ PORTBIT(TOUCHTRIS,TOUCHBIT); //--Tris bit for port


//-- Error Code data --
struct
{
	unsigned ShortCircuit      : 1 ;            //-- If short Circuit on the bus
	unsigned AddrNotFound      : 1 ;            //-- If requested Address not there
 unsigned NoDevicesOnBus    : 1 ;            //-- If no devices at all on the bus
 unsigned ResetFailed       : 1 ;            //-- For some reason could not reset bus
 unsigned UndeterminedError : 1 ;            //-- Something abnormal happened
} TouchError;


//-- Global Variables ---
static bit TouchTest=0;

union
{
 T_ADDR  T_Addr;            //-- Address Data in seperated format.
 uchar   Addr[8];           //-- A single long string for the address
}TouchAddress;


//***********************************************************************
// TouchReset
//***********************************************************************
uchar TouchReset(void)
{
 uint count;
 TouchClearErrors();      //--Clear the Error Flags

 TouchTest=0;
 //-- Clear the port pin
 OneWire=0;
 TouchTris=0;            //--Force to output mode to echo pin status

 //-- delay 480uS
 DelayUs(120);               //--480uS delay approx
 DelayUs(120);
 DelayUs(120);
 DelayUs(120);

 //-- Release the port pin to resistor pull up
 TouchTris=1; //-- make pin an input so external resistor pulls high
 //-- Short delay till checking presence pulse + setup counter
 DelayUs(4);

 //-- Check for presence pulse
 count=3000;
 while(OneWire==0)
 {
  DelayUs(1);
  count--;
  if(count==0)
  {
   //-- if low after 3000uS approx then short circuit situation
   TouchError.ShortCircuit=1;
   return(1);                  //- A non zero to indicate possible error
  }
 }
 //-- if high then a device or devices are on the bus
 //-- delay for another 500uS approx oring the input for status
 for(count=0;count<500;count++)
 {
  if(OneWire==1)
  {
   TouchTest = 1; //-- Capture Presence Pulse
  }
  DelayUs(1);
 }
 if(TouchTest==1)
 {
  // Presence Detected
  return(0);            //-- Return 0 saying everything OK.
 }
 TouchError.NoDevicesOnBus=1;  //-- No Presence = No Device on bus
 return(1);  //-- return Error Status
}
//*************** END OF TouchReset

//***********************************************************************
//TouchByte
//***********************************************************************
uchar TouchByte(uchar Byte)
{
 uchar count;
 typedef struct
 {
  unsigned b0 : 1 ;  // MSB of Byte
  unsigned    : 6 ;  // Ignore middle six
  unsigned b7 : 1 ;  // LSB of Byte
 }BITS;
 union
 {
  uchar Byte;
  BITS  b;
 }Data;
 TouchClearErrors(); //--Clear the Error Flags
 OneWire=0;          //-- Force low when enabled
 Data.Byte=Byte;
 for(count=8;count>0;count--)
 {
  //- Clear the Output
  TouchTris=0;  //-- Output zero to bus

  //- delay 4uS
  DelayUs(4);

  //- Output lowest bit from Data (weak pullup only!!)
  TouchTris=Data.b.b0;       //-- input mode if 1, output if 0

  //- delay 6uS
  DelayUs(6);

  //- Read data in from bus

  TouchTest=OneWire;

  //- delay to end of timeslot - approx 40uS
  DelayUs(40);

  //- rotate bit data into byte - also prepares next bit for writing
  Data.Byte= Data.Byte >> 1;
  Data.b.b7=TouchTest;
 }
 TouchTris=1;             //-- Set output high
	return(Data.Byte);       //--  Return Data read in
}
//*************** END OF TouchByte

//***********************************************************************
//TouchRead - reads a byte from the device
//***********************************************************************
uchar TouchRead(void)
{

}
//************** END OF TouchRead


//***********************************************************************
//TouchSendAddr - Send address to write/read data to
//***********************************************************************
uchar TouchSendAddr(void)
{
 TouchClearErrors(); //--Clear the Error Flags

 return(0);
}
//*************** END OF TouchSendAddr

//***********************************************************************
//TouchGetAddr - read address from the ONLY device on the bus!
//***********************************************************************
void TouchGetAddr(void)
{
	TouchClearErrors(); //--Clear the Error Flags
}
//*************** END OF TouchGetAddr

//***********************************************************************
//TouchClearErrors - Clears the error Struct
//***********************************************************************
void TouchClearErrors(void)
{
	TouchError.ShortCircuit=0;
	TouchError.AddrNotFound=0;
 TouchError.NoDevicesOnBus=0;
	TouchError.ResetFailed=0;
 TouchError.UndeterminedError=0;
}
//*************** END OF TouchClearErrors

//***********************************************************************
// TouchSetUp - Sets up port registers etc
//***********************************************************************
uchar  TouchSetUp(void)
{
 //-- Set up Variables
 TouchClearErrors();   //-- Clear the Error Messages

 //-- Set up TRIS Register bit
 TouchTris=1;          //-- Set to input mode so resistor pulls up

 //-- Set inital state of port pin to HIGH status
 OneWire=0;
 return(0); //-- Setup OK
}
//*************** END OF TouchSetUp




