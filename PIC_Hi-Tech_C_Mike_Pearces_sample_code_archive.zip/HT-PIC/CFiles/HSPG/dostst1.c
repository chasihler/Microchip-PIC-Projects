#include <stdio.h>


void main (void)
{
 unsigned char temp,count;
 unsigned long OutputTimes[4]={1234567890,123456,11111111,22222222};
 unsigned Start_Stop_Time;
 char TimeValue[12];

 for(Start_Stop_Time=0;Start_Stop_Time<3;Start_Stop_Time++)
 {
  temp=sprintf(TimeValue,"%010lu",OutputTimes[Start_Stop_Time]);
  printf("Value=%s  Temp=%d  \n",TimeValue,temp);
  if(temp<10)                               //-- Ensure has full 10 Digits
  {
	  for(count=10;count>(9-temp);count--)
	  {
		  TimeValue[count]=TimeValue[count-(10-temp)]; //-- Shift to end of buffer
    printf("  %d,",count);
    putch(TimeValue[count-(10-temp)]);
    TimeValue[count-(10-temp)]='0';
	  }
//	  for(;count<0xFF;count--)
//	  {
// 	  TimeValue[count]='0';            //-- Fill With Zeros
//	  }
	  TimeValue[10]=0;                  //-- Ensure correct termination
	 }
  puts("\r\n");
  puts(TimeValue);
  puts("\r\n");
 }
 puts("Hit Key when done");
 getch();
}
