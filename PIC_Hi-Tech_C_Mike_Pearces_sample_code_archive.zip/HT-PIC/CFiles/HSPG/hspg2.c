//******************************************************************
//                       HSPG2.C
//
//       Firmware Version 2.00 For the HSPG master controller
// This version of the software to control version 1 of the output card.
// Will be written for 2 cards but initially will only drive 1.
//
// Author: Michael Pearce
//         Electronics Workshop, Chemistry Department
//         University of Canterbury
//
// Started: 12 November 1998
//
//******************************************************************

#include	<pic.h>
#include <stdio.h>

#define XTAL_FREQ 20MHZ
#include "delay.h"

//********* LCD CONTROL COMMANDS *********
#define  LCD_CLS   0x10         //-- Clear Screen
#define  LCD_CR    0x11         //-- Carrage Return
#define  LCD_LF    0x12         //-- New Line
#define  LCD_CRLF  0x13         //-- CR and NL
#define  LCD_BEEP  0x14         //-- Makes a beep!!
#define  LCD_L0    0x15         //-- Goes to start of Line 0
#define  LCD_L1    0x16         //-- Goes to start of Line 1
#define  LCD_PUTCH 0x1D         //-- put next char direct to LCD
#define  LCD_GOTO  0x1E         //-- Moves Cursor to next byte location
#define  LCD_SHOW  0x1F         //-- Update the display
//****************************************

#define PUTCHDLY   10           //-- us Delay when Writing characters
#define GETCHDLY   10           //-- us Delay for reading data
#define GAPDELAY   10           //-- ms Delay between characters

#define DATA PORTD

#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
static bit  READ      @ BITNUM(PORTE, 0);  //- Read Output pin
static bit  TREAD     @ BITNUM(TRISE, 0);

static bit  WRITE     @ BITNUM(PORTE, 1);  //- Write Output pin
static bit  TWRITE    @ BITNUM(TRISE, 1);

static bit  PANSEL    @ BITNUM(PORTE, 2);  //- Pannel Select pin
static bit  TPANSEL   @ BITNUM(TRISE, 2);

static bit  SLS0      @ BITNUM(PORTA, 0);  //- Slot Select 0
static bit  TSLS0     @ BITNUM(TRISA, 0);

static bit  SLS1      @ BITNUM(PORTA, 1);  //- Slot Select 1
static bit  TSLS1     @ BITNUM(TRISA, 1);

static bit  COUNTEN   @ BITNUM(PORTA, 2);  //- Counter enable Pin
static bit  TCOUNTEN  @ BITNUM(TRISA, 2);

static bit  SWRESET   @ BITNUM(PORTB, 0);
static bit  TSWRESET  @ BITNUM(TRISB, 0);  

//------- Global Variables, Buffers etc ---------
union
{
	unsigned long Data32;
 char Bytes[4];
} LongByte;
	


unsigned char MenuNumber=0,Key,count,GotoBase;
unsigned long StartLong,StopLong;

struct 
{
	char Paused;
}Slot[3];

//------- FLAGS ----------

//------- Functions Used in Program --------
void Delay(unsigned int d);
void puts(const char * s);
char getch(void);

void StartDelay(void);
void MainMenu(void);
void MainSelect(void);
void SlotSelect(char Num);
void ConfigSelect(void);
void ConfigChannel(char Board);
unsigned long ReadData(char Board,char Channel);

//long atol(char * s);


//**********************************************************************
//Main
//**********************************************************************
void main(void)
{
// char tempc;
 //-- Setup Variables --
 OPTION=0;
 GIE=0;
 SWRESET=1;                //-- No RESET!!
 READ=1;
 WRITE=1;
 PANSEL=1;
 SLS0=1;
 SLS0=1;

 //-- Set up Ports --
 TRISA=0xFF;
 TRISB=0xFF;
 TRISC=0xFF;
 TRISD=0xFF;    //-- PSP configured as input
 TRISE=0x0F;    //-- Control Pins into Input Mode Initially

 //-- Halt all Operation of the cards --
 COUNTEN=0;
 TCOUNTEN=0;

 //-- Wait for LCD Initialisation
 StartDelay();

// putch(LCD_CLS);
// puts("Detecting.");
// putch(LCD_SHOW);

 //-- Search for cards

// putch(LCD_CR);
// puts("Loading.");
// putch(LCD_SHOW);
 //-- Load Cards From E2PROM

 //-- Main Program Loop --
 while(1)
 {
	 MainMenu();
	}
}
//******************* END OF Main

//**********************************************************************
//StartDelay - Waits for LCD Initialisation
//**********************************************************************
void StartDelay(void)
{
 while(PANSEL==1);         //-- If Pin High then wait till pulsed low
 while(PANSEL==0);         //-- Wait Till it goes High again.
 TRISE=0x00;               //-- Control Port into output mode

 Delay(100);

 putch(LCD_CLS);
 puts("HSPG Version 2.00");
 putch(LCD_SHOW);
 Delay(500);
}
//******************* END OF StartDelay

//**********************************************************************
//putch - puts a character to the LCD unit.
//**********************************************************************
void putch(char c)
{
 READ=1;             //-- Ensure That read mode is over
	DATA=c;             //-- Set data up to send
	TRISD=0x00;         //-- Output Data to the Bus
 DelayUs(PUTCHDLY);  //-- Delay to let data settle
	PANSEL=0;           //-- Select the LCD
 DelayUs(PUTCHDLY);  //-- Delay
	WRITE=0;            //-- Write
	DelayUs(PUTCHDLY);  //-- Delay
	WRITE=1;            //-- End The Write
	PANSEL=1;           //-- End the Select
 DelayUs(PUTCHDLY);  //-- Delay
	TRISD=0xFF;         //-- Bus to HiZ
	Delay(1);           //-- 1mS Delay b4 next character
 if(c >=LCD_CLS && c <=LCD_SHOW)
 {
  Delay(10); //-- allow time for Display to sort itself out for commands
 }
}
//******************* END OF putch

//**********************************************************************
//Delay - Roughly in ms - but not 100% accurate.
//**********************************************************************
void Delay(unsigned int d)
{
	unsigned char Dcount;
	for(;d>0;d--)
	{
		for(Dcount=0;Dcount<100;Dcount++)
		{
   DelayUs(10);
		}
	}
}
//******************* END OF Delay


//**********************************************************************
//getch
//**********************************************************************
char getch(void)
{
	char c=0;
	while(!c)     //-- Keep Checking until a key is pressed
	{
  WRITE=1;     //-- Ensure That write mode is over
  READ=1;      //-- Ensure Read is High
	 TRISD=0xFF;  //-- Input Mode on data Bus
	 PANSEL=0;    //-- Select the LCD
  DelayUs(GETCHDLY); //-- Delay
	 READ=0;      //-- Signal a Read
	 DelayUs(GETCHDLY); //-- Delay
	 c=PORTD;     //-- Read the data in
	 READ=1;      //-- End The Write
	 PANSEL=1;    //-- End the Select
	 Delay(GAPDELAY);    //-- Wait before checking again
	}
	return(c);
}
//******************* END OF getch


//**********************************************************************
//puts
//**********************************************************************
void puts(const char * s)
{
 while(*s)	putch(*s++);
}
//******************* END OF puts


//**********************************************************************
//MainMenu
//**********************************************************************
void MainMenu(void)
{
 while (MenuNumber !=9)
 {
	 putch(LCD_CLS);
  putch(LCD_L1);
  switch(MenuNumber)
  {
   case 0:
    MainSelect();
    break;

   case 1:
    SlotSelect(1);
    break;

   case 2:
    SlotSelect(2);
    break;

   case 3:
    ConfigSelect();
    break;
  }
 }
}
//******************* END OF MainMenu

//**********************************************************************
//MainSelect
//**********************************************************************
void MainSelect(void)
{
 while(MenuNumber==0)
 {
	 putch(LCD_L1);
  puts("MAIN Stat Mode Info");
  putch(LCD_SHOW);
	 Key=getch();
  putch(LCD_L0);
  switch(Key)
  {
   case 'M':
    MenuNumber=1;
    break;

   case 'a':
    puts("Status: ");
    break;

   case 'b':
    puts("Mode: ");
    break;

   case 'c':
    puts("Info: ");
    break;

   default:
    putch(LCD_BEEP);
    Key=0;
    break;
  }
  putch(LCD_SHOW);
 }
}

//******************* END OF MainSelect
//**********************************************************************
//SlotSelect
//**********************************************************************
void SlotSelect(char Num)
{
	while(Num)
 {
	 putch(LCD_L1);
	 switch(Num)
	 {
	  case 1:
    puts("SL1:");
    break; 

   case 2:
    puts("SL2:");
    break;

   default:
    puts("ERR");
  }
  puts(" Mode Cfg  Info");
  putch(LCD_L0);
  puts("Board #");
  putch(Num+'0');
  putch(' ');
  if(Slot[Num].Paused==0)
  {
   puts("Paused");
  }
  else
  {
   puts("Running");
  }
  putch(LCD_SHOW);
  Key=getch();
  putch(LCD_L0);
  switch(Key)
  {
	  case 'a':   //-- Change the mode setting
	   Slot[Num].Paused++;
	   if(Slot[Num].Paused >1) Slot[Num].Paused=0;
	   break;
	   
	  case 'b':
	   ConfigChannel(Num);
	   break;

	  case 'c':
	   puts("INFO:");
	   putch(LCD_SHOW);
	   Delay(500);
	   break;

	  case 'M':
	   MenuNumber++;
	   Num=0;
	   break;

	  default:
	  putch(LCD_BEEP);
  }
  putch(LCD_SHOW);
 }
}

//******************* END OF SlotSelect
//**********************************************************************
//ConfigSelect - Configures the Comms, Display Etc
//**********************************************************************
#define ResetCodeLen 4
static char ResetCode[]="951E";

void ConfigSelect(void)
{
	char temp=0;
	Key=1;
	while(Key)
	{
	 putch(LCD_L1);
  puts("CFG: Coms Disp Rset");
  putch(LCD_SHOW);
  Key=getch();
  putch(LCD_L0);
  switch(Key)
  {
   case 'M':
    MenuNumber=0;
    Key=0;
    break;
    
   case 'a': //-- Comms
    puts("Com:");
    break;
    
   case 'b': //-- Display
    puts("Display Normal");
    break;
    
   case 'c': //-- Reset
    puts("Reset Code?");
    putch(LCD_SHOW);
    putch(LCD_L0);
    count=0;
    temp=0;
    while(Key !='E')
    {
	    Key=getch();
	    if(Key!=ResetCode[count]) temp=1;
	    if(count<ResetCodeLen)
	    {
		    count++;
	    }
	    else
	    {
		    temp=1;
	    }
	   }
    if(temp==1)
    {
	    puts("WRONG!");
	    putch(LCD_BEEP);
    }
    else
    {
	    puts("Resetting....");
	    putch(LCD_L1);
	    for(count=0;count<10;count++)
	    {
		    putch(LCD_BEEP);
		    Delay(100);
	    }
	    SWRESET=0;                //******** DO RESET OF SYSTEM **********
	    TSWRESET=0;
    }
    break;
    
   default:
    putch(LCD_BEEP);
  }
  putch(LCD_SHOW);
 }  
}
//******************* END OF ConfigSelect

//**********************************************************************
//ConfigChannel  - Sets up the timing for each channel on Board
//**********************************************************************
void ConfigChannel(char Board)
{
	char Channel,Done=0,X,Y;
	char TempS[12];
	putch(LCD_CLS);
	while(Done==0)
	{
		putch(LCD_CLS);
		puts("Channel 0 - 6?");
		putch(LCD_SHOW);

  Channel=getch();
  if(Channel >= '0' && Channel < '7')
  {
	  Channel=Channel-'0';   //-- Convert to Value 0 to 6
	  putch(LCD_L0);
	  puts("Channel ");
	  putch(Channel+'0');
	  putch(LCD_L1);
	  puts("Reading Data..");
	  putch(LCD_SHOW);
	  Delay(500);

   //-- Read in current setting from EEPROM (I2C).
   StartLong=ReadData(Board,Channel);  //-- Read Start Time
   StopLong=ReadData(Board,Channel+8); //-- Read Stop Time
   X=sprintf(TempS,"%ld",StartLong); //-- Convert First Lot of data
   
   putch(LCD_L0);
   putch(Channel+'0');
   puts(" Start=");
   puts(TempS);
   putch(LCD_L1);
   putch(Channel+'0');
   puts(" Stop =");
   puts(TempS);
   putch(LCD_SHOW);

   //-- Allow Editing of Setting
   // convert long to string - edit the string then put back to int.
   Y=0;     //-- Go To First Line
   X=sprintf(TempS,"%ld",StartLong); //-- Convert First Lot of data
   if(X<10) //-- Ensure has full 10 Digits
   {
	   for(count=11;count>(11-X);count--) 
	   {
		   TempS[count]=TempS[count-X]; //-- Shift to end of buffer
	   }
	   for(;count<0xFF;count--)
	   {
 	   TempS[count]='0';            //-- Fill With Zeros
	   }
	   TempS[10]=0;
	  }
	  X=0;
	  GotoBase=48;
   do
   {
	   putch(LCD_GOTO);       //-- Goto Command
	   putch(GotoBase+X);            //-- Character Position 8+X
	   Key=getch();
	   switch(Key)
	   {
		   case 'E':
//		    StartLong=atol(TempS);
		    Key=0;
		    break;

//		   case 'C':   //-- Clear the Data
//      QuestionYN("Clear Data?");    //-- Using Menu Buttons For Yes or No   
//      //-- Set Current value to 0000000000ns
//      break;     		   
	
 	   case 'L':
      if(X>0) X--;      //-- LEFT  
      break;
      
		   case 'R':
		    if(X<9)X++;      //-- RIGHT
		    break;
		    
 	   case 'U':          //-- UP
	     GotoBase=8;
	     break;
	     
 	   case 'D':          //-- DOWN
 	    GotoBase=48;
 	    break;
 	    
		   case 'M':     //-- Menu Button - Do not save changes!!
		    Key=0;
		    break;

		   default:
		    if(Key >='0' && Key <='9')
		    {
			    TempS[X]=Key;
			    putch(LCD_PUTCH);
			    putch(Key);
			    if(X<9)
			    {
				    X++;
			    }
			    else
			    {
				    X=9;
			    }
		    }
		    break;
	   }
   }while(Key);
  }
  else
  {
	  if(Channel =='M')
	  {
		  Done=1;
   }
   else
   {
    putch(LCD_BEEP);
   }
  }
 }
}
//******************* END OF ConfigChannel
//**********************************************************************
//ReadData - Reads the current settings from EEPROM on selected board
//**********************************************************************
unsigned long ReadData(char Board,char Channel)
{
 LongByte.Data32=1234567890;	
 count=0;
 //-- Select the Slot number to read from
 PANSEL=1;      //-- Ensure not talking to pannel
 SLS1=1;    //-- Disable any curent Comms
 SLS0=1;
 switch (Board)
 {
	 case 1:
	  SLS0=0;
	  break;
	  
	 case 2:
	  SLS1=0;
	  break;
	  
	 default:
	  count=5;    //-- Force Skip Of Reading Data
	  break;
 }
	  
 //-- Read in the 4 bytes from EEPROM associated with slot and channel
 for(;count<4;count++)
 {
	 // IICData=ReadIIC(Address,Start,1); //--Read 1 byte from EEPROM
	 // LongByte.Bytes[count]=IICData;    //--Add to the data array
 }
 //-- Disable comms with slots.
 SLS0=1;
 SLS1=1;  
 return(LongByte.Data32);
}
//******************* END OF ReadData

//**********************************************************************
//
//**********************************************************************

//******************* END OF
//**********************************************************************
//
//**********************************************************************

//******************* END OF
//**********************************************************************
//
//**********************************************************************

//******************* END OF
//**********************************************************************
//
//**********************************************************************

//******************* END OF




