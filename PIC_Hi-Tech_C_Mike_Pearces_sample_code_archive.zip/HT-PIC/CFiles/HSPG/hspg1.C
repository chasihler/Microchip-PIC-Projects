//******************************************************************
//                       HSPG1.C
//
//       Firmware Version 1.00 For the HSPG master controller
// This version of the software is used to test the LCD and Keypad.
// and possibly grow to testing other things as well.
//
// Author: Michael Pearce
//         Electronics Workshop, Chemistry Department
//         University of Canterbury
//
// Started: 5 November 1998
//
//******************************************************************

#include	<pic.h>
#include <stdio.h>

#define XTAL_FREQ 20MHZ
#include "delay.h"

//********* LCD CONTROL COMMANDS *********
#define  LCD_CLS   0x10         //-- Clear Screen
#define  LCD_CR    0x11         //-- Carrage Return
#define  LCD_LF    0x12         //-- New Line
#define  LCD_CRLF  0x13         //-- CR and NL
#define  LCD_BEEP  0x14         //-- Makes a beep!!
#define  LCD_L0    0x15         //-- Goes to start of Line 0 
#define  LCD_L1    0x16         //-- Goes to start of Line 1
#define  LCD_SHOW  0x1F         //-- Update the display
//****************************************

#define PUTCHDLY   10           //-- Delay when Writing characters

#define DATA PORTD

#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
static bit  READ      @ BITNUM(PORTE, 0);  //- Read Output pin
static bit  TREAD     @ BITNUM(TRISE, 0);   
static bit  WRITE     @ BITNUM(PORTE, 1);  //- Write Output pin
static bit  TWRITE    @ BITNUM(TRISE, 0);  
static bit  PANSEL    @ BITNUM(PORTE, 2);  //- Pannel Select pin
static bit  TPANSEL   @ BITNUM(TRISE, 0);  
static bit  SLS0      @ BITNUM(PORTA, 0);  //- Slot Select 0
static bit  TSLS0     @ BITNUM(TRISA, 0);  
static bit  SLS1      @ BITNUM(PORTA, 1);  //- Slot Select 1
static bit  TSLS1     @ BITNUM(TRISA, 1);  

//------- Global Variables, Buffers etc ----------

//------- FLAGS ----------

//------- Functions Used in Program --------
void Delay(unsigned int d);
void puts(const char * s);
char getch(void);

//**********************************************************************
//Main
//**********************************************************************
void main(void)
{
 char tempc;
 //-- Setup Variables --
 READ=1;
 WRITE=1;
 PANSEL=1;
 SLS0=1;
 SLS0=1;

 //-- Set up Ports --
 TRISA=0xFF;
 TRISB=0xFF;
 TRISC=0xFF;
 TRISD=0xFF;    //-- PSP configured as input
 TRISE=0x07;    //-- Control Pins into Input Mode Initially

 //-- Start Up Delay --

 while(PANSEL==1);         //-- If Pin High then wait till pulsed low
 while(PANSEL==0);         //-- Wait Till it goes High again.
 TRISE=0x00;               //-- Control Port into output mode

 Delay(10);

 putch(LCD_CLS);
 puts("HSPG is on line!");
 putch(LCD_CRLF);
 puts("Firmware V1.00");
 putch(LCD_SHOW);
 Delay(500);

 //-- Main Program Loop --
 while(1)
 {
	 putch(LCD_CLS);
	 puts("Main Menu.");
	 putch(LCD_CRLF);
	 puts("Main Game Msg  Reset");
  putch(LCD_SHOW);

	 switch((tempc=getch()))
	 {
   case 'M':
    break;

		 case 'a':
		  putch(LCD_CRLF);
		  puts("You Selected\"Game\"");
		  break;

		 case 'b':
		  putch(LCD_CRLF);
		  puts("You Selected\"Msg\"");
		  break;

		 case 'c':
		  putch(LCD_CRLF);
		  puts("You Selected\"Reset\"");
    break;

		 default:
		  putch(LCD_BEEP);
		  putch(LCD_CLS);
		  puts("Invalid Selection!");
		  putch(LCD_CRLF);
		  puts("Unknown Key -> ");
		  putch(tempc);
		  break;
	 }
  putch(LCD_SHOW);
	 Delay(500);
	}
}
//******************* END OF Main

//**********************************************************************
//putch - puts a character to the LCD unit.
//**********************************************************************
void putch(char c)
{
 READ=1;             //-- Ensure That read mode is over
	DATA=c;             //-- Set data up to send
	TRISD=0x00;         //-- Output Data to the Bus
 DelayUs(PUTCHDLY);  //-- Delay to let data settle
	PANSEL=0;           //-- Select the LCD
 DelayUs(PUTCHDLY);  //-- Delay
	WRITE=0;            //-- Write
	DelayUs(PUTCHDLY);  //-- Delay
	WRITE=1;            //-- End The Write
	PANSEL=1;           //-- End the Select
 DelayUs(PUTCHDLY);  //-- Delay
	TRISD=0xFF;         //-- Bus to HiZ
	Delay(1);           //-- 1mS Delay b4 next character
 if(c >=LCD_CLS && c <=LCD_SHOW)
 {
  Delay(10); //-- allow time for Display to sort itself out for commands
 }
}
//******************* END OF putch

//**********************************************************************
//Delay - Roughly in ms - but not 100% accurate.
//**********************************************************************
void Delay(unsigned int d)
{
	unsigned char count;
	for(;d>0;d--)
	{
		for(count=0;count<100;count++)
		{
   DelayUs(10);
		}
	}
}
//******************* END OF Delay


//**********************************************************************
//getch
//**********************************************************************
char getch(void)
{
	char c=0;
	while(!c)     //-- Keep Checking until a key is pressed
	{
  WRITE=1;     //-- Ensure That write mode is over
  READ=1;      //-- Ensure Read is High
	 TRISD=0xFF;  //-- Input Mode on data Bus
	 PANSEL=0;    //-- Select the LCD
  DelayUs(10); //-- Delay
	 READ=0;      //-- Signal a Read
	 DelayUs(10); //-- Delay
	 c=PORTD;     //-- Read the data in
	 READ=1;      //-- End The Write
	 PANSEL=1;    //-- End the Select
	 Delay(5);    //-- Wait 5ms before checking again
	}
	return(c);
}
//******************* END OF getch


//**********************************************************************
//puts
//**********************************************************************
void puts(const char * s)
{
 while(*s)	putch(*s++);
}
//******************* END OF puts


//**********************************************************************
//
//**********************************************************************

//******************* END OF



