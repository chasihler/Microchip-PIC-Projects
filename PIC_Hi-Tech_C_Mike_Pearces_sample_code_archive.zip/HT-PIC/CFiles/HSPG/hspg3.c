//******************************************************************
//                       HSPG3.C
//
// Firmware Version 3.00 For the HSPG master controller
// This is a cut down version to save space on the PIC.
//
// Only Basic Menus used and only control for FIRST Slot.
// Only Controls one Slot (Slot1).
//
//
// Author: Michael Pearce
//         Electronics Workshop, Chemistry Department
//         University of Canterbury
//
// Started: 24 November 1998
//
//******************************************************************
//#define DEBUG
//#define RESETON             //-- Enable soft Reset capabilitys
//#define IICBUSON            //-- Enables I2C Bus for Storage
#define PICSTORAGE            //-- Uses 16F84 for data storage

#include <pic.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXCHANNEL 6
#define XTAL_FREQ 10MHZ
#include "delay.h"
#include "hspg_io1.c"

#define GotoBase 7       //-- start of the Count Value on display
#define MAXDIGIT 8       //-- Number of Digits -1 that is editable.
#define BoardNumber 0    //-- Only One board allowed in this ver

#ifdef PICSTORAGE
#define PICDelayTime  1
#define PICEEPROMTime 5
#endif

//------- Output Speed Designation --------------
#define CLOCK_DELAY_TIME  20      //-- Resolution in ns of Board


//------- Global Variables, Buffers etc ---------
union
{
	unsigned long Data32;
 char Bytes[4];
} LongByte;

//unsigned char MAXDIGIT=8;
unsigned char TimeValue[13];
unsigned char Start_Stop_Time = 0;
unsigned char MenuNumber=0;
unsigned char CurrentChannel=0;
unsigned long OutputTimes[3]={12345,1234567890,0}; //-- start/stop/temp
unsigned char temp,count,temp1;
#ifdef PICSTORAGE
unsigned char PICTemp;
#endif


//-------- Functions ---------
void SaveSettings(void), LoadSettings(void), EditSettings(void);
void ShowTimeValue(void);
void SendCurrent(void);
void SelectAddress(char Num);  //-- Selects Loader Address
void SelectSlot(char Num);     //-- Selects Slot Number
void SelectChannel(void);      //-- Selects Channel address

#ifdef PICSTORAGE              //-- Using 16F84 for E2PROM Data
void PICWrite(char Data,char Mode);
char PICRead();
#endif

//******************************************************************
// main
//******************************************************************
void main (void)
{
 //-- Initialise Ports
 InitPorts();

 //-- Wait For LCD Ready --
 while(PANSEL==1);  //-- Wait for it to go low
 while(PANSEL==0);  //-- Wait for it to be released
 TRISE=0x00;        //-- Control Port into output mode
	//TREAD=0;TWRITE=0;
 Delay(100);        //-- Let things settle before sending data

 //-- Load the Xilinx with the stored data --
 SelectSlot(BoardNumber);
 for(CurrentChannel=0;CurrentChannel<7;CurrentChannel++)
 {
	 LoadSettings();          //-- Load both settings from storage
	 Start_Stop_Time=0;       //-- Send first setting to Xilinx
  SendCurrent();
	 Start_Stop_Time=1;       //-- Send Second setting to Xilinx
	 SendCurrent();
 }
 CurrentChannel=0;         //-- Start at first channel
 Start_Stop_Time=0;        //-- And start time
 
 //-- Run the Menu System --
 while(1)
 {
  switch(MenuNumber)
  {
	  //********************* EDITING MENU *********************
	  default:
   case 1:
    putch(LCD_L0);
    ShowTimeValue();
    //-- Display the menu Items
    putch(LCD_L1);
    puts("Slot Out");putch(CurrentChannel+'0');puts(" Type Edit");
    putch(LCD_SHOW);

    switch(getch())
    {
	    case 'M': //-- Next menu
	     MenuNumber++;
	     break;

	    case 'a': //-- Next Channel
      SaveSettings();
	     CurrentChannel++;
	     if(CurrentChannel > MAXCHANNEL) CurrentChannel=0;
      LoadSettings();
	     break;

	    case 'b': //-- Select Start or Stop Time
	     if(Start_Stop_Time==0)
	     {
       Start_Stop_Time=1;
		    }
		    else
		    {
       Start_Stop_Time=0;
		    }
	     break;


	    case 'c':
      EditSettings();
	     break;
    }
    break;

   //******************* MAIN MENU *********************
/*   case 0:
    putch(LCD_CLS);
//    puts("HSPG Firmware V3.00");
    putch(LCD_L1);
    puts("M ");
    if(COUNTEN)
    {
	    puts("On");
    }
    else
    {
	    puts("Off");
    }
#ifdef RESETON
    puts("  RESET");
#endif
    putch(LCD_SHOW);
    switch(getch())
    {
	    case 'M':
	     MenuNumber++;   //-- Go To Next Menu
	     break;

	    case 'a':
	     if(COUNTEN==0)    //-- Toggle the HALT/RUN of the system
	     {
		     COUNTEN=1;
	     }
	     else
	     {
		     COUNTEN=0;
	     }
		    break;

#ifdef RESETON
	    case 'c':
      putch(LCD_L0);
      puts("?");
      putch(LCD_SHOW);
	     if(getch()=='L')
	     {
       SWRESET=0;
       TSWRESET=0;
	     }
#endif
    }
    break;
   //******************** DEFAULT ***********************
   default:
    MenuNumber=0;
    break;
 */
  }
 }
}
//**************** END OF main

//******************************************************************
//SaveSettings - Stores the current values in I2C E2ROM
//******************************************************************
void SaveSettings(void)
{
	putch(LCD_L0);
	puts("SD");
	putch(LCD_SHOW);
	SelectSlot(BoardNumber); //-- store current selection

	//Write to the 4 bytes with base at (channel * 8) + (4 * Type)
	//This uses a total of 56 Bytes per 6 channels.
	temp1=Start_Stop_Time;
	for(Start_Stop_Time=0;Start_Stop_Time<2;Start_Stop_Time++)
	{
  LongByte.Data32=OutputTimes[Start_Stop_Time];    // Get Value to save
 	temp=(CurrentChannel * 8)+(Start_Stop_Time * 4); // Calc Base Address

#ifdef PICSTORAGE
 	PICWrite(temp,0);   //-- Write base address to start at
#endif
 	for(count=0;count<4;count++)
 	{
#ifdef IICBUSON      //-- Use I2C Bus for data storage
// 		 IICWrite(I2CAddr,SubAddr,Data);
 		 IICWrite(0x00,temp+count,LongByte.Bytes[count]);  // Write data to EEPROM
#endif

#ifdef PICSTORAGE    //-- Use PIC16F84 For data storage
 	  PICWrite(LongByte.Bytes[count],1);
#endif
 	}
	 OutputTimes[Start_Stop_Time]=LongByte.Data32;   //-- Store the number
	}
	Start_Stop_Time=temp1;  //-- Restore current selection
}
//**************** END OF SaveSettings

//******************************************************************
//LoadSettings - Loads values from I2C E2ROM
//******************************************************************
void LoadSettings(void)
{
	temp1=Start_Stop_Time;
	putch(LCD_L0);
	puts("RD");
	putch(LCD_SHOW);
 SelectSlot(BoardNumber);
	//Read the 4 bytes with base at (channel * 8) + (4 * Type)
 	temp=(CurrentChannel * 8)+(Start_Stop_Time * 4); // Calc Base Address
#ifdef PICSTORAGE
	PICWrite(temp,0);
#endif
	for(Start_Stop_Time=0;Start_Stop_Time<2;Start_Stop_Time++)
	{
	 temp=(CurrentChannel * 8)+(Start_Stop_Time * 4);                // Calc Sub Address
	 for(count=0;count<4;count++)
	 {
#ifdef IICBUSON
	 	// char IICRead(I2CAddr,SubAddr);
	 	LongByte.Bytes[count]=IICRead(0x00,temp+count);  // Read From EEPROM
#endif
#ifdef PICSTORAGE
   LongByte.Bytes[count]=PICRead();
#endif
	 }
  OutputTimes[Start_Stop_Time]=LongByte.Data32; // Store the value
	}
	Start_Stop_Time=temp1;
}
//**************** END OF LoadSettings

//******************************************************************
//EditSettings - Edits current value on screen and converts it
//******************************************************************
void EditSettings(void)
{
 count=0;
 temp=0;
// if( (MAXDIGIT=strlen(TimeValue)-1) >9 ) MAXDIGIT=9;
 do
 {
  putch(LCD_GOTO);       //-- Goto Command
	 putch(GotoBase+temp);            //-- Character Position 8+X
	 count=getch();
	 switch(count)
	 {
	  case 'E':
    OutputTimes[Start_Stop_Time]=atol(TimeValue);
    // Write to EEPROM
    SaveSettings();      //-- Stores information of the current channel
    // Write to Xilinx
    SendCurrent();       //-- Sends current channel settings to Xilinx
    count=0;
	   break;

   case 'C':   //-- Clear the Data
    if(getch()=='C')
    {
	    OutputTimes[2]=OutputTimes[Start_Stop_Time]; //-- Save Current Value
	    OutputTimes[Start_Stop_Time]=0;              //-- Clear Value
	    putch(LCD_L0);
	    ShowTimeValue();                             //-- Display the zeros
	    putch(LCD_SHOW);
	    OutputTimes[Start_Stop_Time]=OutputTimes[2]; //-- Restore current
    }
    break;

   case 'L':
    if(temp>0) temp--;      //-- LEFT
    break;

   case 'R':
    if(temp<MAXDIGIT)temp++;      //-- RIGHT
    break;

//   case 'U':          //-- UP
//    GotoBase=8;
//    break;

//   case 'D':          //-- DOWN
//    GotoBase=48;
//    break;

   case 'M':     //-- Menu Button - Do not save changes!!
    count=0;
    break;

   default:
    if(count >='0' && count <='9')
    {
	    //-- Do Not let count go over 3.999999999 seconds!! (only 32 bit number)
	    if(temp==0)
	    {
		    if(count > '3')count='3';
	    }
	    TimeValue[temp]=count;
	    putch(LCD_PUTCH);
	    putch(count);
	    if(temp<MAXDIGIT)
	    {
		    temp++;
	    }
	    else
	    {
		    temp=MAXDIGIT;
	    }
    }
    break;
  }
 }while(count);
}
//**************** END OF EditSettings

//******************************************************************
//ShowTimeValue
//******************************************************************
void ShowTimeValue(void)
{
 //-- Get Selected Value --
 sprintf(TimeValue,"%010lu",OutputTimes[Start_Stop_Time]);
 //-- Since sprintf does not pad with zeros - add them in!!
 for(count=0;count<10;count++)
 {
  if(TimeValue[count]==' ') TimeValue[count]='0';
 }
 //-- Show What type it is
 if(Start_Stop_Time)
 {
  puts("Lo:");
 }
 else
 {
  puts("Hi:");
 }
 //-- Show the Value and add the ns
 puts(TimeValue);
 puts("ns");
}
//**************** END OF ShowTimeValue

//**********************************************************************
//SendCurrent - Sends the current channel data to board
//**********************************************************************
void SendCurrent(void)
{
 // Start_Stop_Time = start or Stop Timing
 // CurrentChannel  = channel selected
 // OutputTimes[3]  = data to send
 // BoardNumber     = current selected board

 //-- Indicate that are loading Xilinx
 putch(LCD_L0);
 puts("UD");
 putch(LCD_SHOW);

 //-- Select the Board to write data to --
 PANSEL=1;      //-- Active Low so set it High
 SLS0=0;        //-- Active HIGH so set low
 SLS1=0;
 TSLS0=0;
 TSLS1=0;
 READ=0;
 WRITE=0;
 TREAD=0;
 TWRITE=0;

#ifdef DEBUG
 Delay(500);
#endif
 SelectSlot(BoardNumber);
 //-- Load the 32 bit register 8 bits at a time --
 TDATA=0x00;   //-- Data port to output
 LongByte.Data32=OutputTimes[Start_Stop_Time]/CLOCK_DELAY_TIME;
 for(count=0;count<4;count++)
 {
  DATA=LongByte.Bytes[count];
  //-- Write the Byte
  SelectAddress(count);
  Delay(1);
  WRITE=1;
#ifdef DEBUG
 Delay(250);
#endif
  Delay(1);
  WRITE=0;
#ifdef DEBUG
 Delay(250);
#endif
 }
 SelectChannel();
 //-- Write the channel address
 //RC0,1,2     (CA0,1,2)

 //-- Strobe the LOAD pin.
 LOAD=1;
#ifdef DEBUG
 Delay(500);
#endif
 Delay(1);
 LOAD=0;

 //-- All Done so release the board and clean up
 SelectAddress(0);
 SelectSlot(10);
 TDATA=0xFF; //-- Data Bus to Hi-Z
}
//******************* END OF SendCurrent

//******************************************************************
//SelectAddress
//******************************************************************
void SelectAddress(char Num)
{
 switch(Num)
 {
  default:
  case 0:
   A0=0;A1=0;
   break;
  case 1:
   A0=1;
   break;
  case 2:
   A0=0;A1=1;
   break;
  case 3:
   A1=1;
   break;
 }
}
//**************** END OF SelectAddress

//******************************************************************
//SelectSlot
//******************************************************************
void SelectSlot(char Num)
{
	SLS0=0;
	SLS1=0;
	PANSEL=1;
 switch(Num)
 {
	 case 0:
   SLS0=1;
   break;

	 case 1:
   SLS1=1;
   break;

  case 2:
   PANSEL=0;
   break;
 }
}
//**************** END OF SelectSlot

//******************************************************************
//SelectChannel
//******************************************************************
void SelectChannel(void)
{
 temp=((CurrentChannel * 2)+Start_Stop_Time); //-- Calculate the address
 temp&=0x07;          //-- Clear any unwanted bits (shouldn't be needed!!)
 count=PORTC;         //-- Read current port settings
 count&=0xF8;         //-- Clear the address Bits
 count|=temp;         //-- Add the address bits the the port data
 PORTC=count;         //-- Apply new address to the port
}
//**************** END OF SelectChannel

//******************************************************************
//PICWrite - Writes Base address or Data
//******************************************************************
#ifdef PICSTORAGE
void PICWrite(char Data,char Mode)
{
	TRISB=0x00;           //-- All Pins To output mode
	PICTemp=Data>>4;      //-- Get High Nibble
	if(Mode==0)
	{
  PICTemp|=0x90;        //   1001xxxx    rWAHxxxx    Write Address	High
	}
	else
	{
  PICTemp|=0xB0;        //   1011xxxx    rWdHxxxx    Write data	High
	}
 PORTB=PICTemp;        //-- Write High Nibble
 Delay(PICDelayTime);  //-- Allow Time To Write Data
 PORTB=0xFF;           //-- End the Write of the high Nibble
 PICTemp=Data && 0x0F; //-- Get Low Nibble
 if(Mode==0)
 {
  PICTemp|=0x80;        //    1000xxxx   rWAlxxxx    Write Address low
 }
 else
 {
  PICTemp|=0xA0;        //    1010xxxx   rWdlxxxx    Write data low
 }
 PORTB=PICTemp;        //-- Write Low Nibble
 Delay(PICDelayTime);  //-- Allow Time To Write          
 PORTB=0xFF;           //-- Back to Normal
}
//**************** END OF PICWriteAddress
#endif
//******************************************************************
//PICRead - Reads data from 16F84 E2PROM
//******************************************************************
#ifdef PICSTORAGE
char PICRead()
{
	PICTemp=0;
 TRISB=0x0F;           //-- Data to input mode rest as output

 //-- Read High Nibble First --
 PORTB=0x50;           //  0101	         RwDH       Read Data High
 Delay(PICEEPROMTime); //-- Delay to get data from E2PROM
 PICTemp=PORTB<<4;     //-- Store High Nibble
 PORTB=0xFF;           //-- End the read procedure

 Delay(PICDelayTime);  //-- Delay to allow other end to change port etc

 //-- Read Low Nibble Second --
 PORTB=0x40;           //0100            RwDl       Read Data low
 Delay(PICEEPROMTime);
 PICTemp |=(PORTB & 0x0F); //-- Store remaining Nibble
 PORTB=0xFF;               //-- End the read Cycle

// Delay(PICDelayTime); //-- Another Delay to sort things out.
	return(PICTemp);
}
#endif
//**************** END OF PICReadData

//******************************************************************
//
//******************************************************************

//**************** END OF
//******************************************************************
//
//******************************************************************

//**************** END OF




