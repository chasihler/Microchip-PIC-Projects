//********************************************************************
//                        EEPROM.C
//                      Version 1.00
//
// This is the Software for the 16F84 used on the main board of the
// High Speed Pulse Generator Project.
// This is the basic code that turns the 16F84 into a EEPROM for
// storage of a single boards data. (To get things up and Running)
//
// Author: Michael Pearce
//         Chemistry Department,University of Canterbury
//
// Started: 1st December 1998
//
//********************************************************************
#include <pic.h>

//******** Set up Port Pins ********
#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))

//-- HSPG Communication Port --
#define DATAPORT  PORTB                     //- Data input bits 0-3
static bit  HIGHLOW    @ BITNUM(PORTB, 4);  //- High or Low Nibble
static bit  ADDRDATA   @ BITNUM(PORTB, 5);  //- Address or data nibble
static bit  WRITE      @ BITNUM(PORTB, 6);  //- Pin for write to memory
static bit  READ       @ BITNUM(PORTB, 7);  //- Pin for read from memory

//-- Serial Port --
static bit  TXD        @ BITNUM(PORTA, 0);  //- Serial Xmit data To PC
static bit  RXD        @ BITNUM(PORTA, 1);  //- Serial Rcv data from PC
static bit  CTS        @ BITNUM(PORTA, 2);  //- Clear to Send to PC
static bit  RTS        @ BITNUM(PORTA, 3);  //- Req to send from PC

//-- Software controlled Hardware Reset --
static bit  RESET      @ BITNUM(PORTA, 4);  //- Software reset pin

//******** Global Data used ***********
unsigned char DataIN,DataOUT,Temp,Address;
bit HighLowBit,Write,AddrDataBit,Read;
bit WriteHigh,EEPROMRead;


//******** Functions in Program ********
void StoreData(void),RecallData(void);

//********************************************************************
//main
//********************************************************************
void main(void)
{
 OPTION=0x88;            //-- 1000 1000  Pull up enabled + Pre for WDT
	//-- Set Up Ports
 INTCON=0;           //-- Disable all interrupts

	PORTB=0xFF;  //-- All Pins High
	TRISB=0xFF;  //-- All Pins Input unless being read from

	PORTA=0xFF;
	TRISA=0x0A;  // xxx0 1010  Reset and Serial Pins

 HighLowBit=1; Write=1; AddrDataBit=1; Read=1;
 WriteHigh=0; EEPROMRead=0;

 //-- Set up Interrupts --
 RBIE=1;                    //-- Port B interrupt on change enabled
 GIE=1;                     //-- Enable Global interrupts

	//-- Main Program loop
	while(1)
	{
		//-- wait for command from Master controller
  if(!Write)
  {
   if(!WriteHigh) DataIN=0;     //-- If ReadHigh Flag not set then clear the data
   if(HighLowBit)
   {
    DataIN=PORTB<<4;           //-- Read High Byte of Data
    WriteHigh=1;
   }
   else
   {
				DataIN &= 0xF0;            //-- Ensure Low Nibble of data is clear
    DataIN |= (PORTB & 0x0F);  //-- Read Low Nibble in
    WriteHigh=0;               //-- Indicate time to clear the data next time
   }
   if(!WriteHigh)
   {
    //-- All required data is read so store as address or write to EEPROM
    if(AddrDataBit)
    {
     //-- If HIGH then is an address
     Address=DataIN;
     Address &=0x3F;    //-- Clear the top two bits - stops unwanted addressing
    }
    else
    {
     //-- If LOW then is data to be stored
     //-- Write data to EEPROM at given address.
     EEADR=Address;   //-- Load EEPROM data address
     EEDATA=DataIN;   //-- Load Data to Store

     //-- Write Sequence Follows --
     GIE=0;           //-- Disable General Interrupts
     WREN=1;          //-- Allow Write to EEPROM

     EECON2=0x55;     //-- Required sequence
     EECON2=0xAA;
     WR=1;            //-- Write the Data to EEPROM

     while(WR);       //-- wait for write cycle completion

     WREN=0;          //-- Disable write to EEPROM
     GIE=1;           //-- Enable General Interrupts
     //-- End Write Sequence --

     Address++; //-- point to next byte in EEPROM - Auto Inc Address
    }
   }
  }
  else
  {
   if(!Read)
   {
    //-- Read Byte From Selected Address --
    if(!EEPROMRead)   //-- Only read EEPROM Once per address
    {
     EEADR=Address;   //-- Load address to read from
     RD=1;            //-- Initiate read cycle
     DataOUT=EEDATA;  //-- Put EEPROM data into temp storage
     EEPROMRead=1;    //-- Indicate that have read data from EEPROM
    }
    if(HighLowBit)
    {
     //-- if high then High Nibble needs to be written to port
     PORTB=DataOUT >> 4; //-- Output High Nibble Only
     TRISB=0xF0;      //-- set port to output
     while(!Read);    //-- Wait for Read to finish
     TRISB=0xFF;      //-- Port back to input mode
    }
    else
    {
     PORTB=DataOUT & 0x0F;  //-- output Low nibble only
     TRISB=0xF0;         //-- Output the data to the port
     while(!Read);       //-- Wait for read cycle to finish
     TRISB=0xFF;         //-- Back to input mode
     EEPROMRead=0;       //-- Allow read of Next Byte
     Address++;          //-- Auto Increment address for next read
    }
   }
  }
 }
}
//*************** END OF main

//******************************************************************
// PortChanged Interrupt
//******************************************************************
interrupt PortChanged(void)
{
	if(RBIF)
	{
		//-- Check What pin has changed and set appropiate markers etc.
  HighLowBit=HIGHLOW;
  Write=WRITE;
  AddrDataBit=ADDRDATA;
  Read=READ;
  RBIF=0;   //-- Clear the interrupt flag to enable next change
	}

}
//************* END OF PortChanged

//********************************************************************
//StoreData - Stores the last recieved byte in E2ROM
//********************************************************************
void StoreData(void)
{

}
//*************** END OF  StoreData
//********************************************************************
//RecallData - Reads the E2ROM Data ready for sending
//********************************************************************
void RecallData(void)
{

}
//*************** END OF RecallData
//********************************************************************
//
//********************************************************************

//*************** END OF
//********************************************************************
//
//********************************************************************

//*************** END OF 

