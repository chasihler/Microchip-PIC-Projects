//**********************************************************************
//                       HSPG_IO1.C
//
// This File contains all of the I/O Functions used on the main Board.
// Including Printing, Reading Keypad, Reading/Writing EEPROM,
// Writing the XILINX Data etc.
//
// Author: Michael Pearce
//         Electronics Workshop, Chemistry Department
//         University of Canterbury
//
// Started: 24 November 1998
//
//**********************************************************************

//********* LCD CONTROL COMMANDS *********
#define  LCD_CLS   0x10         //-- Clear Screen
#define  LCD_CR    0x11         //-- Carrage Return
#define  LCD_LF    0x12         //-- New Line
#define  LCD_CRLF  0x13         //-- CR and NL
#define  LCD_BEEP  0x14         //-- Makes a beep!!
#define  LCD_L0    0x15         //-- Goes to start of Line 0
#define  LCD_L1    0x16         //-- Goes to start of Line 1
#define  LCD_PUTCH 0x1D         //-- put next char direct to LCD
#define  LCD_GOTO  0x1E         //-- Moves Cursor to next byte location
#define  LCD_SHOW  0x1F         //-- Update the display
//****************************************
#define BEEP_ON    1            //-- Enable beep when getch used
#define PUTCHDLY   1            //-- us Delay when Writing characters
#define GETCHDLY   1            //-- us Delay for reading data
#define GAPDELAY   3            //-- ms Delay between characters


//******************* DEFINE THE PORT SETTINGS **************************
#define DATA PORTD
#define TDATA TRISD

#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
static bit  READ      @ BITNUM(PORTE, 0);  //- Read Output pin
static bit  TREAD     @ BITNUM(TRISE, 0);

static bit  WRITE     @ BITNUM(PORTE, 1);  //- Write Output pin
static bit  TWRITE    @ BITNUM(TRISE, 1);

static bit  PANSEL    @ BITNUM(PORTE, 2);  //- Pannel Select pin
static bit  TPANSEL   @ BITNUM(TRISE, 2);

static bit  SLS0      @ BITNUM(PORTA, 0);  //- Slot Select 0
static bit  TSLS0     @ BITNUM(TRISA, 0);

static bit  SLS1      @ BITNUM(PORTA, 1);  //- Slot Select 1
static bit  TSLS1     @ BITNUM(TRISA, 1);

static bit  COUNTEN   @ BITNUM(PORTA, 2);  //- Counter enable Pin
static bit  TCOUNTEN  @ BITNUM(TRISA, 2);

static bit  SWRESET   @ BITNUM(PORTB, 0);
static bit  TSWRESET  @ BITNUM(TRISB, 0);

static bit  A0        @ BITNUM(PORTA, 4);
static bit  A1        @ BITNUM(PORTA, 5);
static bit  LOAD      @ BITNUM(PORTA, 3);


//******************** THE FUNCTIONS *************************
void puts(const char * s);
char getch(void);
void InitPorts(void);
void Delay(unsigned int d);




//**********************************************************************
//putch - puts a character to the LCD unit.
//**********************************************************************
void putch(char c)
{

 READ=1;             //-- Ensure That read mode is over
	DATA=c;             //-- Set data up to send
	TRISD=0x00;         //-- Output Data to the Bus
 Delay(1);           //-- Delay to let data settle
	PANSEL=0;           //-- Select the LCD
 Delay(1);           //-- Delay
	WRITE=0;            //-- Write
	Delay(1);           //-- Delay
	WRITE=1;            //-- End The Write
	PANSEL=1;           //-- End the Select
 Delay(1);           //-- Delay
	TRISD=0xFF;         //-- Bus to HiZ
	Delay(GAPDELAY);    //-- 1mS Delay b4 next character
 if(c >=LCD_CLS && c <=LCD_SHOW)
 {
  Delay(GAPDELAY);   //-- allow time for Display to sort itself out for commands
 }
}
//******************* END OF putch


//**********************************************************************
//puts
//**********************************************************************
void puts(const char * s)
{
 while(*s)	putch(*s++);
}
//******************* END OF puts


//**********************************************************************
//getch
//**********************************************************************
char getch(void)
{
	char c=0;
	while(!c)     //-- Keep Checking until a key is pressed
	{
  WRITE=1;     //-- Ensure That write mode is over
  READ=1;      //-- Ensure Read is High
	 TRISD=0xFF;  //-- Input Mode on data Bus
	 PANSEL=0;    //-- Select the LCD
  Delay(GETCHDLY); //-- Delay
	 READ=0;      //-- Signal a Read
	 Delay(GETCHDLY); //-- Delay
	 c=PORTD;     //-- Read the data in
	 READ=1;      //-- End The Write
	 PANSEL=1;    //-- End the Select
	 Delay(GAPDELAY);    //-- Wait before checking again
	}
#ifdef BEEP_ON
	putch(LCD_BEEP);
#endif
	return(c);
}
//******************* END OF getch

//**********************************************************************
//InitPorts
//**********************************************************************
void InitPorts(void)
{
 //-- Setup Pins and Interrupt settings --
 OPTION=0;
 GIE=0;
 SWRESET=1;                //-- No RESET!!
 READ=0;                   //-- Do Not READ
 WRITE=0;                  //-- Do Not WRITE
 PANSEL=0;                 //-- No Selection
 SLS0=0;                   //  of any device
 SLS1=0;                   //  at this stage.
 COUNTEN=0;       //-- Disable the counters

 //-- Set up Ports --
 TRISA=0x00;    //-- Port A to outputs!!
 TRISB=0xFF;    //-- UNused so leave as inputs (apart from RESET)
 PORTC=0x00;    //-- CA0,1,2 + IDCL,DA + INV Load, Clr to LOW Status
 TRISC=0x18;    //-- All Output apart from IDCL and IDDA
 TRISD=0xFF;    //-- PSP configured as input
 TRISE=0x07;    //-- Control Pins into Input Mode Initially

 TCOUNTEN=0;    //-- Disable the System by stopping counters

}
//******************* END OF InitPorts


//**********************************************************************
//Delay - Roughly in ms - but not 100% accurate.
//**********************************************************************
void Delay(unsigned int d)
{
	unsigned char Dcount;
	for(;d>0;d--)
	{
		for(Dcount=0;Dcount<100;Dcount++)
		{
   DelayUs(10);
		}
	}
}
//******************* END OF Delay


//**********************************************************************
//
//**********************************************************************

//******************* END OF 

//**********************************************************************
//
//**********************************************************************

//******************* END OF 

//**********************************************************************
//
//**********************************************************************

//******************* END OF 

//**********************************************************************
//
//**********************************************************************

//******************* END OF 

