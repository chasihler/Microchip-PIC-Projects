
//---------------- Global Variables ------------------
extern int PowerPercent;         //-- Current Power output
extern int LastReactorTemp;      //-- Last recorded Reactor Temperature
extern int LastJacketTemp;       //-- Last Jacket Temperature
extern int TargetTemp;           //-- The Target Temperature
extern int Cooling;              //-- The Cooling Valve status

//---------------- FUNCTIONS -------------------------
extern void CalculatePower( int CReactor,int CJacket); //-- calculates the power output

