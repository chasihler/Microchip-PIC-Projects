#include <stdio.h>
#include <conio.h>
#include <math.h>

#define PI 3.14159

//-- Try to find 100 even areas under a half cycle of a sin wave
void main (void)
{
 FILE *fptr,*fptr2;
 int angle,time2,time3,sum2=0,sum3=0;
 float calc=0.98;
 float result,lastresult=0.0,time,gap,sum=0;

 fptr=fopen("sinedata.dat","w");
 fptr2=fopen("sinedata.sum","w");
 for(angle=1;angle <= 100 ;angle++)
 {
  //result=acos(calc);
  result=acos(calc)*(180/PI);
  gap=result-lastresult;
  time=( (gap*100) /180)*100;        // -- Result in uS
  sum+=time;


  printf("\r\nPercent=%d  Angle=%f Gap=%f Time=%fus Sum=%f",angle,result,gap,time,sum);

  time2=(int)time;
  time3=time2/39;
  sum2+=time2;
  sum3=0xff-(sum2/39);

  fprintf(fptr,"\nPercent=%d  Time=%dus  Sum=%d  Time/39=%d  Sum=%d",angle,time2,sum2,time3,sum3);
  fprintf(fptr2,"\n    RETLW 0x%2X     ;-- %d%% Output Power",sum3,angle);
  calc-=0.02;
  lastresult=result;
//  getch();
 }
 fcloseall();
 while(getch()!='q');

}
