//*********************************************************************
//                        calcpwr.c
//
// This is the test software to see if a method of temperature control
// works by manually entering the values and seeing the results.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 1 July 1998
//
//*********************************************************************


#define ON  1                      //-- Valve On Value
#define OFF 0                      //-- Valve Off Value


//---------------- Defined Limitations -----------------
#define MAXPOWER 255               //-- = 100% power Output
#define MAX_JACKET_TEMP 96         //-- Max Jacket Temperature Allowed
#define FINE_CHANGE 2              //-- Max Heater Level change in Fine
#define COURSE_CHANGE 20           //-- Max Heater Level change in Course
#define COURSE_OFFSET 10           //-- Offset to select if heating or cooling

//---------------- Global Variables ------------------
int PowerPercent;         //-- Current Power output
int LastReactorTemp;      //-- Last recorded Reactor Temperature
int LastJacketTemp;       //-- Last Jacket Temperature
int TargetTemp;           //-- The Target Temperature
int Cooling;              //-- The Cooling Valve status
int OverHeat;

//---------------- FUNCTIONS -------------------------
void CalculatePower( int CReactor,int CJacket); //-- calculates the power output
void Change5Percent(int CReactor,int CJacket); // Very close to target
void Change20Percent(int CReactor,int CJacket); // Approaching above range



//********************************************************************
//CalculatePower -- calculates the power output
//********************************************************************
void CalculatePower( int CReactor,int CJacket)
{

 int Percent20,Percent5;

 Cooling=OFF;     //-- Set Cooling status to Off to start with

 Percent20=(int)((float)TargetTemp * 0.2);     //-- Calculate 20% of Target
 Percent5= (int)((float)TargetTemp * 0.05);    //-- Calculate 5% of Target

 if(CReactor < TargetTemp+Percent5 && CReactor > TargetTemp-Percent5)
 {
  //-- Withing 5% of Target Temperature - Small Changes required
  Change5Percent(CReactor,CJacket);
 }
 else
 {
  if(CReactor < TargetTemp+Percent20 && CReactor >TargetTemp-Percent20)
  {
   //-- Outside of 5% mank but withing 20% Range - Larger changes in Temperature
   Change20Percent(CReactor,CJacket);
  }
  else
  {
   if(CReactor <= TargetTemp-Percent20)
   {
    //-- Less than 80% of target temperature so give max heating avaliable
    PowerPercent=MAXPOWER;  //-- 100% Heating Power

   }
   else
   {
    //-- Must be More that 120% of target so Need major cooling!!
    PowerPercent-=COURSE_CHANGE;  //-- Reduce but do not shut off instantly
    Cooling=ON;                       //-- Add Cooling to Drop Quickly
   }
  }
 }

 //-- Check if dropped below zero power required
 if(PowerPercent < 0) PowerPercent=0;

 //-- Check if above MAX Power output
 if(PowerPercent > MAXPOWER) PowerPercent=MAXPOWER;

 //-- Check if Jacket above Maximum Temperature (i.e. aproaching boiling)
 if(CJacket >= MAX_JACKET_TEMP)
 {
  OverHeat=1;       //-- Indicate That Jacket is at or aboove Maximum Allowed
  PowerPercent=0;   //-- Outside of limit so shut heating down to stop boiling
  Cooling=ON;       //-- Turn Cooling On - Get rid of as much heat as possible.
 }

 LastReactorTemp=CReactor;
 LastJacketTemp=CJacket;
}
//********************* END OF CalculatePower


//********************************************************************
//Change5Percent - within 5% - so do finer calculations
//********************************************************************
void Change5Percent(int CReactor,int CJacket)
{
 int Temp1,Temp2,Temp3;
 //-- Withing 5% of Target Temperature - Small Changes required
 Temp1=CReactor-LastReactorTemp;    //-- Change in temperature since last time
 Temp2=CJacket-LastJacketTemp;      //-- Change in Jacket temp since last time
 Temp3=TargetTemp-CReactor;         //-- difference from Target temperature

 if(Temp3 !=0)
 {
  //-- If Not Exactly on the target
  PowerPercent-=(Temp3*FINE_CHANGE); //-- Target Difference * amount = change
 }
 else
 {
  //-- Am Exactly on Target - Check Jacket change rate to try and settle
  if(Temp2 !=0)
  {
   //-- There was movement in last time slot - Try to Flatten it out
   PowerPercent-=(Temp2/FINE_CHANGE);  //-- Only change if was big shift!!
  }
 }
}

//********************************************************************
//Change20Percent - within 20% - so do course calculations
//********************************************************************
void Change20Percent(int CReactor,int CJacket)
{
 int Temp1,Temp2,Temp3,Temp4;

 Temp1=CReactor-LastReactorTemp;    //-- Change in temperature since last time
 Temp2=CJacket-LastJacketTemp;      //-- Change in Jacket temp since last time
 Temp3=TargetTemp-CReactor;         //-- difference from Target temperature
 Temp4=TargetTemp-CJacket;          //-- difference between jacket and target

 if(Temp3 > 0)
 {
  //-- +ve Value So Below Target Temperature
  //-- Check aproach angel by reactor and roll it toward target
  //-- Also using Jacket temperature to see if may need to reduce

  if(Temp4 < 0)
  {
   // Jacket is hotter than Target Temperature
   // Check rate of change of reactor internal temperature
   // if small rate then need more heat, if large rate then need less heat

   PowerPercent+=(COURSE_CHANGE/Temp3)-(COURSE_OFFSET);
   // If Temp3 small value then result is +ve and power is increased
   // If Temp3 large Value then result is -ve and power is decreased

  }
  else
  {
   // Equal to or less than Target temperature
   // Need More heat cause it just won't get to the target like this!
   // If rate of change is large then don't increase power by much
   // Otherwise may overshoot the mark.
   // If not much change happening then change by lots

   PowerPercent+=(COURSE_CHANGE/Temp3);
  }
 }
 else
 {
  //-- Reactor is Above Target Temperature
  if(Temp4 < 0)
  {
   //-- Jacket temperature is above Target Temperature - cool things down quick
   PowerPercent-=(COURSE_CHANGE/4)*(1-Temp3); //--Big Power Change required!!
  }
 }
}

