//*********************************************************************
//                       ctrlpic.c
//
// Program for using a PIC16C64 to control the heating/cooling
// for the PVC Reactor.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury.
//
// Started: 3 July 1998
//
//*********************************************************************




void main (void)
{

 //-- initialise Comms, 1-wire and I/O Ports

 //-- Print Opening message
 puts("\r\nTemperature Control V2.00 Activated");

 //-- Run the main loop
 while(1)
 {
   //--Read the temperature in


 }
}

