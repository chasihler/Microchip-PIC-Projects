//*********************************************************************
//                        ctrltst1.c
//
// This is the test software to see if a method of temperature control
// works by manually entering the values and seeing the results.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 1 July 1998
//
//*********************************************************************
#include <stdio.h>
#include "CalcPwr.h"



void main(void)
{
 int CJ=20,CR=20,a,Target,temp;

 PowerPercent=0;          //-- Current Power output
 LastReactorTemp=20;      //-- Last recorded Reactor Temperature
 LastJacketTemp=20;       //-- Last Jacket Temperature
 TargetTemp=80;           //-- The Target Temperature
 Cooling=0;

  Target=TargetTemp;
 clrscr();
 printf("Test Program for Temperature control System");
 printf("\r\n\r\n Press any key to run simulation....");
 getch();
 printf("\r\nStarting Simulation...");
 printf("\r\nTarget  Jacket   Reactor   Power %");
 for(a=1;a<1000;a++)
 {
  CalculatePower(CR,CJ);
  printf("\r\n %d     %d        %d        %d",Target,CJ,CR,PowerPercent);
  getch();

  if(PowerPercent > 100)
  {
   CJ++;
   CR++;
  }
  else
  {
   if(PowerPercent < 90)
   {
    if((temp=PowerPercent)==0) temp=1;
    CJ-=10/temp;
    if(CJ>CR)
    {
     CR++;
    }
    if(CR>CJ)
    {
     CR--;
    }
   }
  }
 }
}


