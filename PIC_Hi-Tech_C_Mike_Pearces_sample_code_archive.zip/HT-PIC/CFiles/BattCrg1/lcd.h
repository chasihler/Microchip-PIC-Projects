/*
 *	LCD interface header file
 *	See lcd.c for more info
 */

/* write a byte to the LCD in 4 bit mode */
extern void lcd_write(unsigned char);

/* Clear and home the LCD */
extern void lcd_clear(void);

/* write a string of characters to the LCD */
extern void lcd_puts(const char * s);

/* Go to the specified position */
extern void lcd_goto(unsigned char pos);
	
/* intialize the LCD - call before anything else */
extern void lcd_init(void);


//*********************************************
// ADDED BY Michael Pearce....
//*********************************************

#define LCD_LINE1  0x00         //-- Start location of Line 1
#define LCD_LINE2  0x40         //-- Start location of Line 2




