/*
 *	LCD interface example
 *	Uses routines from delay.c
 *	This code will interface to a standard LCD controller
 *	like the Hitachi HD44780. It uses it in 4 bit mode, with
 *	the hardware connected as follows (the standard 14 pin
 *	LCD connector is used):
 *
 *	call lcd_init(), then other routines as required.
 *
 */

//*************************************************************************
// MODIFIED: 10 March 1999
// BY:      Michael Pearce
// CHANGES: Need to Define LCD_RS, LCD_EN and now LCD_PORT
//          Writing to Port only writes to lower 4 bits,this was done so 
//          That if the remainder of the port is used as output it is not 
//          interfered with (hopefully). Also allows other ports to be used
//          
//          To use these Setup LCD_xxxx options, set the correct TRIS bits
//          in the appropite TRIS registers and then use lcd_init().
//          You are now ready to run the other routines.
//
// ADDED ROUTINES:
//          lcd_putch(), lcd_print();
//
//***********************************************************


//static bit LCD_RS	@ ((unsigned)&PORTA*8+4);	// Register select
//static bit LCD_EN	@ ((unsigned)&PORTA*8+5);	// Enable

#define	LCD_STROBE	((LCD_EN = 1),(LCD_EN=0))

/* write a byte to the LCD in 4 bit mode */

void
lcd_write(unsigned char c)
{
	LCD_PORT &=0xF0;              //-- Clear Low 4 Bits
	LCD_PORT |= (c >> 4) & 0x0F;  //-- Send High 4 Bits without changing High 4
	LCD_STROBE;                   
	LCD_PORT &=0xF0;              //-- Clear Low 4 Bits
	LCD_PORT |= c & 0x0F;         //-- Send Low 4 Bits to port
	LCD_STROBE;
 DelayUs(40);
}

/*
 * 	Clear and home the LCD
 */

void
lcd_clear(void)
{
	LCD_RS = 0;
	lcd_write(0x1);
	DelayMs(2);
}

/* write a string of chars to the LCD */

void
lcd_puts(const char * s)
{
	LCD_RS = 1;	// write characters
	while(*s)
		lcd_write(*s++);
}

/*
 * Go to the specified position
 */

void
lcd_goto(unsigned char pos)
{
	LCD_RS = 0;
	lcd_write(0x80+pos);
}
	
/* initialise the LCD - put into 4 bit mode */

void
lcd_init(void)
{
	LCD_RS = 0;	// write control bytes
	DelayMs(15);	// power on delay
	
	LCD_PORT &=0xF0;  //-- Clear the port
	LCD_PORT |= 0x03;	// attention! - send only low 4 bits
	LCD_STROBE;
	DelayMs(5);
	LCD_STROBE;
 DelayUs(100);
	LCD_STROBE;
	DelayMs(5);
	LCD_PORT &=0xF0;   //-- Clear the port
	PORTB |= 0x02;   	// set 4 bit mode - to low 4 bits only
	LCD_STROBE;
 DelayUs(40);
	lcd_write(0x28);	// 4 bit mode, 1/16 duty, 5x8 font
	lcd_write(0x08);	// display off
	lcd_write(0x0F);	// display on, blink cursor on
	lcd_write(0x06);	// entry mode
}
