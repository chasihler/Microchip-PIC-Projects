/*
 *	Delay functions
 *	See delay.h for details
 *
 *	Make sure this code is compiled with full optimization!!!
 */

#ifndef DelayUs
 #include	"delay.h"
#endif

void DelayMs(unsigned char cnt)
{
#if	XTAL_FREQ <= 2MHZ
	do
	{
		DelayUs(996);
	} while(--cnt);
#endif

#if XTAL_FREQ > 2MHZ	
 #if XTAL_FREQ > 8MHZ
	 unsigned char	i;
	 do
	 {
	 	i = 8;
	 	do
	 	{
	 		DelayUs(125);
 		} while(--i);
 	} while(--cnt);
 #else 
  //-- Less than 8MHZ but greater than 2 MHz
	 unsigned char	i;
	 do
	 {
	 	i = 4;
	 	do
	 	{
	 		DelayUs(250);
	 		CLRWDT();            //-- Needs Clearing every 18ms MAX
 		} while(--i);
 	} while(--cnt);
 #endif
#endif
}

//*********************************************
//pause - waits n seconds (up to 255 Seconds)
//*********************************************
void pause(unsigned char n)
{
	char c=4;
	while(n-- >0)
	{
		do
		{
		 DelayMs(250);
		}while(--c >0);
	}
}
//************ END OF pause



