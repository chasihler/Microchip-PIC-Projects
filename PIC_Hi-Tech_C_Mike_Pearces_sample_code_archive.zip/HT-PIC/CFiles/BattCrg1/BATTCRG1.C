//**************************************************************************
//                            BATTCRG1.C 
//                           Version 1.00
//
// Software to Cause correct charging and discharge cycling of 8 seperate
// Nicd Battery Packs. Initially The Discharge cycle will only be done
// once every 28 days but requires the user to start the cycle, this should
// stop the problem of discharging at inappropiate times.
// Eventually in later versions (above 1.00) the following features may be
// added in:
//   Individual Selection of battery for discharge.
//   Fault Detection on Batterys.
//   Better Cycling methods (e.g. discrg, crg 75%, discrg, crg 100%)
//   Better Charge calculation methods
//   Better Display Options.
//
// Processor:
//  Designed for the PIC16C74A micro-controller with ADC and lots a ROM/RAM
//
// Author:
//  Michael Owen Pearce
//
// Started:
//  10 March 1999
//
//**************************************************************************
//                        Version Information
//--------------------------------------------------------------------------
// Version 1.00: Started 10 Mar 1999
//     Start to the project - Automatic charging of batterys.
//     Discharge Request on 28 day cycle - User input required to start it
//     No Fancy features in this version
//
//**************************************************************************

//------- DEFINES --------
// uchar / uint
typedef unsigned char uchar;
typedef unsigned int uint;

//#define DEBUG
#define XTAL_FREQ 8MHZ          //-- Crystal speed - for delay routines

// TRUE/FALSE  ON/OFF
#define TRUE   1
#define FALSE  0
#define ON     1
#define OFF    0

// Time Generation Info
#define SECINHOUR 60*60         //-- Number of seconds in 1 hour
#define MSINSEC   1000          //-- Number of ms in 1 second
#define DISCHARGEMONTH 24*28    //-- 24 Hours per day - 28 Day Month
#define TMR0RELOAD -125         //-- clk/4/16/125 = 1ms Timer Load value
#define CHANNELSWITCHTIME 1     //-- Number of seconds between channel change
#define DISCHARGESHOW 5         //-- Delay between showing"TIME TO DISCHARGE"
#define KEYENTERDELAY 4         //-- Seconds before accepting key entry
#define UNITCOUNT     85        //-- Seconds Per Unit for TimeLeft

// Channels Information
#define MAXCHANNEL 8            //-- Total number of channels -1

// Charge and Discharge controls
#define CRGON          0        //-- Individual Charge ON/OFF
#define CRGOFF         1        // Neg Logic due to Transistor buff inversion
#define CRGALLON       0x00     //-- Global Charge ON/OFF
#define CRGALLOFF      0xFF     // Neg Logic due to Transistor buff inversion
#define DISCRGON       1        //-- Individual Discharge ON/OFF
#define DISCRGOFF      0
#define DISCRGALLON    0xFF     //-- Global Discharge ON/OFF
#define DISCRGALLOFF   0x00
#define TRICKLEON      1        //-- Global Trickle Charge CTRL
#define TRICKLEOFF     0

// Charge/Discharge status/info
#define CHARGEDVOLTAGE    (uchar)(5 * (255/5))  //-- Fully Charged State
#define DISCHARGEVOLTAGE  (uchar)(4 * (255/5))  //-- Voltage at batt is flat
#define DEADVOLTAGE       (uchar)(3 * (255/5))  //-- Batt assumed dead 
#define NOBATTERYVOLTAGE  (uchar)(1 * (255/5))  //-- Reading when no battery

//User I/O Controls
#define BUZZERON       1        //-- Buzzer Control
#define BUZZEROFF      0
#define KEYDOWN        0        //-- Key postion Indication
#define KEYUP          1

//Channel information codes for Status part of structure
#define NOBATTERY      0        //-- Indicates no battery connected  
#define CHARGING       1        //-- Indicates battery is Charging
#define DISCHARGING    2        //-- Indicates Battery is Discharging
#define BATTFULL       4        //-- Indicates Battery is Fully charged
#define TRICKLECHARGE  8        //-- Indicates Trickle Charging
#define STATUS4        16       //-- Unused
#define STATUS5        32       //-- Unused
#define STATUS6        64       //-- Unused
#define BATTERROR      128      //-- Indicates Error - still attempts charge

// Bit Address Defining command
#define BITNUM(adr, bit) ((unsigned)(&adr)*8+(bit))  //-- used for port defs

//------- HEADER FILE INCLUDES ------
#include <pic.h>
#include "delay.h"
#include "lcd.h"

//------- I/O PORT ALLOCATIONS ------
// Put here cause need some .h files
static bit MasterTrickleCharge @ BITNUM(PORTA, 4);  //- Trickle Charge Ctrl
static bit Buzzer      @ BITNUM(PORTD, 6);    //-- Buzzer Control Pin
static bit SelectInput @ BITNUM(PORTD, 7);    //-- User Button Input Pin 
#define ChargeCtrl     PORTB                  //-- Charge Control Port
#define DischargeCtrl  PORTC                  //-- Discharge Control Port
static bit LCD_RS      @ BITNUM(PORTD, 4);    //-- LCD RS Control
static bit LCD_EN      @ BITNUM(PORTD, 5);    //-- LCD E  Control
#define LCD_PORT       PORTD                  //-- LCD Data Port (Low 4bits)

//------- C FILE INCLUDES -----------
// Put here cause they need some of above defines
#include "delay.c"
#include "lcd.c"

//------- GLOBAL VARIABLES ----------
// Key Input
bit KeyDown;                      //-- Indicates KEY state updated every sec
unsigned char KeyDelayCounter;    //-- How many second key has been depressed


// Time
unsigned int MilliSeconds,Seconds,Hours;
bit SecondTick;                    //-- Toggles state once per second
bit	DischargeSecondState;          //-- Hold last state of SecondTick
bit KeySecondState;                //-- Holds last second tick state
bit DischargeTime;                 //-- Holds last second tick state
unsigned char DischargeCounter;    //-- Counter for delay between displays
unsigned char UnitCounter;         //-- For Counting seconds in TimeLeft unit
bit LastUnitSecond;                //-- Holds last second tick state

// Channel Information
struct
{
 unsigned char Status;             //-- Current state of the channel
 unsigned char TimeLeft;           //-- Time Left in minutes
} ChannelInfo[MAXCHANNEL];                  //-- Information about each channel

unsigned char CurrentChannel;      //-- Currently selected channel
unsigned char LastChannel;         //-- Previous selected channel
bit ChannelChangeTick;             //-- Indicator to switch to next Channel
unsigned char NextChannelTime;     //-- Time Counter for switching channels

// Discharge Control
unsigned char DischargeCycleNumber; //-- Part Of discharge Cycle

// Watch Dog Timer Indication
bit WDTReset;

//------- FUNCTION DEFINITIONS ------
void interrupt InterruptFunction(void);
void InitVariables(void),RunTests(void);
unsigned char SampleADC(unsigned char Channel);
void	UpdateDisplay(void);      //-- Update changes to display
void	CheckBattery(void);       //-- Check the current battery charge status
void	CheckButton(void);        //-- Check if button has been Pressed
void	CheckDischarge(void);     //-- Check Discharge Status Flag
void CheckChargeTimer(void);   //-- Checks and alters charge Time counters


//**************************************************************************
//main
//**************************************************************************
void main (void)
{
 //-- Check for RESET by Watch Dog Timer --
 if(!TO)
 {
	 WDTReset=1;
	 //-- Reset Caused by Watch Dog Timer --
	 //-- Try to Figure Out What cause the problem --
  //-- If not Found then reset everything except time values --
  //-- Also Indicate that an error occured on the LCD Display

 }
 else
 {
	 WDTReset=0;
 }
 OPTION=0; 
	//---- Initialiase Variables ----
	CLRWDT();
	InitVariables();

	//---- SET UP PORTS ----
	TRISA=0xEF;      //-- 0-3 & 5 Analog Input  4 Output
	TRISB=0x00;      //-- All Output (Charge Control)
	TRISC=0x00;      //-- All Output (Discharge Control)
	TRISD=0x00;      //-- All Output (LCD, Buzz, Key)
	TRISE=0xFF;      //-- All Analog Input

	//---- Initialise LCD ----
	CLRWDT();
	lcd_init();

	//---- Initialise ADC ----
	ADCON1=0x00;    //-- All Analogue input pins a ADC
	ADCON0=0x00;    //-- Reset to defaults
	ADCS1=1;        //-- Sample Clock = fosc/32 = 8MHz/32 = 4us
	ADCS0=0;        //
	ADON=1;         //-- Turn ADC ON

 //---- Set up Timer ----
 TMR0=TMR0RELOAD;  //-- ms Reload time
 PSA=0;            //-- Set Prescaller for use with timer
 PS2=0;            //-- Set prescaller to divide by 16
 PS1=1;            //
 PS0=1;            //
 T0CS=0;           //-- Clr RTS to operate as timer from internal clock
	
 //---- Run Test Routines -----	
 CLRWDT();
 RunTests();

 //---- Set Up Interrupts ----
 PIE1=0;           //-- Disable all Peripheral Interrupts
 PIE2=0;           //-- Disable PWM Interrupt
 INTCON=0;         //-- Disable all interrupts
 T0IF=0;           //-- Clear any pending interrupt
 T0IE=1;           //-- Enable the timer interrupt
// ADIF=0;           //-- Clear anf pending interrupt
// ADIE=1;           //-- Enable ADC Interrupt
 GIE=1;            //-- Enable Global Interrupts

	//---- Main Loop ----
	while(1)
	{
		
  CLRWDT();
		UpdateDisplay();      //-- Update changes to display
		CLRWDT();
		CheckBattery();       //-- Check the current battery charge status
		CLRWDT();
		CheckButton();        //-- Check if button has been Pressed
		CLRWDT();
		CheckDischarge();     //-- Check Discharge Status Flag
  CLRWDT();
  CheckChargeTimer();   //-- Checks and alters charge Time counters
  CLRWDT();
 
		if(ChannelChangeTick)
		{
			ChannelChangeTick=FALSE;   
			LastChannel=CurrentChannel;
   if(++CurrentChannel >= MAXCHANNEL) CurrentChannel=0;
		}
	}
}
//****************** END OF main

//**************************************************************************
// InterruptFunction
//**************************************************************************
void interrupt InterruptFunction(void)
{
	//-- ADC Conversion complete --
	if(ADIF)
	{
		ADIF=0;
	}
 //-- Timer Overflow Interrupt -- Used to generate seconds/hours
 // Tmr0 Pre set to 16, Reload set to 125 @ 8Mhz Xtal = 1ms Interrupt 
 if(T0IF)
 {
	 TMR0=TMR0RELOAD;   //-- Reload Timer
	 T0IF=0;            //-- Re Enable Interrupt
	 //-- Check if done 1 second yet
	 if(++MilliSeconds == MSINSEC)
	 {
		 MilliSeconds=0;
		 if(SecondTick)
		 {
			 SecondTick=0;
		 }
		 else
		 {
			 SecondTick=1;
		 }
		 //-- Check if time to switch to the next channel
		 if(++NextChannelTime >=CHANNELSWITCHTIME)
		 {
    ChannelChangeTick=TRUE;
		 }
		 //-- Check if an hour is up yet
		 if(++Seconds>=SECINHOUR)
		 {
			 Seconds=0;
			 //-- Check if time to discharge/cycle batterys
			 if(++Hours >=DISCHARGEMONTH)
			 {
				 Hours--;         //-- Hours set to zero when user initiates discharge
     DischargeTime=TRUE;
			 }
		 }
		}
	}
	//----- end of Timer 0 Overflow Interrupt
 //-- Check Keyboard once a second --
	if(MilliSeconds==0)
	{
		KeyDown = SelectInput;       //-- Get Current Key Status
	}
}
//****************** END OF InterruptFunction


//**************************************************************************
//InitVariables
//**************************************************************************
void InitVariables(void)
{
	//-- I/O --
	Buzzer=BUZZEROFF;
	MasterTrickleCharge=TRICKLEOFF;
	ChargeCtrl=CRGALLOFF;          
 DischargeCtrl=DISCRGALLOFF;	

 //-- TIME --
 if(!WDTReset)
 {
	 //-- Only reset time values on powerup or manual RESET --
  MilliSeconds=0;
  Seconds=0;
  Hours=0;
  ChannelChangeTick=0;
  UnitCounter=0;
 }

 KeyDelayCounter=0;
 KeySecondState=0;
 DischargeCounter=0;
 DischargeSecondState=0;
 

 //-- Monitoring --
 CurrentChannel=0;    //-- Start at channel 0
 LastChannel=MAXCHANNEL;  //-- Different to above channel
 DischargeTime=ON;    //-- Give User Option to do Discharge cycle on Power up
 
}
//****************** END OF InitVariables

//**************************************************************************
//RunTests -- Runs Basic Diagnostics Tests 
//  Note: In Version 1.00 this is the LCD and Beeper Only
//**************************************************************************
void RunTests(void)
{
	char count;
	if(WDTReset)
	{
		//-- If system was rebooted by Watch Dog Timer Indicate so!! --
		Buzzer=BUZZERON;             //-- Sound the alarm to get attention -
	 lcd_clear();                 //-- Clear the display
	 lcd_puts("ERR: WDT Timeout");//-- Indicate WDT Timeout occured
	 pause(2);                    //-- 2 second Delay
	 lcd_goto(LCD_LINE2);
	 lcd_puts("System Was Reset"); //-- Indicate System Rebooted
	 pause(1);
	 lcd_goto(LCD_LINE2);
	 lcd_puts("Continuing......"); //-- Indicate that will continue
	 pause(1);
	 Buzzer=BUZZEROFF;             //-- Turn the buzzer OFF
	}
	//--- If Key held down then Force test of WDT ---
	if(SelectInput==KEYDOWN)
	{
		lcd_clear();
		if(!WDTReset)
		{
		 lcd_puts("**TESTING WDT**");
		 lcd_goto(LCD_LINE2);
		 lcd_puts("Please Wait....");
		 while(1); //-- Force Timeout of WDT
		}
		else
		{
			//-- If Key held down while a WDT Reboot in effect then ERROR
			Buzzer=BUZZERON;
			lcd_puts("ERR: Key Error");
			lcd_goto(LCD_LINE2);
			lcd_puts("Wait...");
			pause(5);
			Buzzer=BUZZEROFF;
		}
	}

	
	lcd_clear();
	lcd_puts("*Smart Charger*");
	lcd_goto(LCD_LINE2);
	lcd_puts("V1.00 M.O.Pearce");
	pause(1);
	lcd_clear();
	lcd_puts("Testing Charger");
	lcd_goto(LCD_LINE2);
 //---- Do Systems Checks Here - somehow ----
	for(count=0;count<15;count++)
	{
	 lcd_puts(".");      //-- Fake the test sequence since not really testing
	 DelayMs(150);
	}
	
	Buzzer=BUZZERON;     //-- Test the beeper
	pause(1);            //-- for 1 second      
	lcd_puts(".");       //-- Print the last dot 
	Buzzer=BUZZEROFF;    //-- Turn Buzzer Off
	pause(1);            //-- Wait a bit so display shown 
}
//****************** END OF RunTests

//**************************************************************************
//SampleADC - Samples and returns value from ADC
//**************************************************************************
unsigned char SampleADC(unsigned char Channel)
{
	CLRWDT();                   
 DelayUs(30);              //-- Ensure previous ADC setling time!!
	Channel &=0x07;           //-- Clear unwanted bits
 ADCON0 &= 0xC7;           //-- Clear Channel Selection
 ADCON0 |= Channel << 3;   //-- Select Channel
 DelayUs(20);              //-- Ensure enough Sampling time
 ADGO=1;                   //-- Turn the ADC Converter On
 while(ADGO);              //-- Wait for conversion to complete 
         //***** Above Line NOT SAFE should do something else !!!! *****
 CLRWDT();                 //-- But using WDT will try to keep things going 
 return(ADRES);            //-- Return Result
}
//****************** END OF SampleADC

//**************************************************************************
//UpdateDisplay - Refresh the values displayed
//
// Displays the charge status of each Battery.
// Top Line something like:   "1 2 3 4 5 6 7 8 "
// Bot Line something like:   "C x C F F x C E "
//
// Where: C = Charging
//        F = Full - Only when ALL Batterys read FULL then trickle is active
//        x = No Battery Detected (i.e ADC reads less than 1 Volt)
//        E = ERROR - Possibly faulty battery (Not in version 1.00)
//        D = DISCHARGE
//     
//**************************************************************************
void	UpdateDisplay(void)
{
	unsigned char count;
	lcd_goto(LCD_LINE1);
	lcd_puts("1 2 3 4 5 6 7 8 ");
	lcd_goto(LCD_LINE2);
	for(count=0;count<MAXCHANNEL;count++)
	{
		switch(ChannelInfo[count].Status)
		{
			case NOBATTERY:           
			 lcd_puts("x ");                  //-- Indicate no battery connected
			 break;

			case CHARGING:
			 lcd_puts("C ");                  //-- Indicate Charging
			 break;

		 case DISCHARGING:
		  lcd_puts("D ");                  //-- Indicate Discharging
		  break;

		 case BATTFULL:
		  lcd_puts("F ");                  //-- Indicate Fully Charged
		  break;

		 case TRICKLECHARGE:
		  lcd_puts("T ");                  //-- Indicate Trickle Charge
		  break;

		 case BATTERROR:          
		 default:
		  lcd_puts("E ");                  //-- Indicate an error
		  break;
		}
	}
}
//****************** END OF UpdateDisplay

//**************************************************************************
//CheckBattery - Checks on the battery status and charge
//
// if Not charging then checks if needs charging and calcs time required
// if charging, disables charge circuit, enables discharge, samples voltage
//  disables discharge, calculates if needs charging, turns charge back on.
// Also checks time each battery has been on charge.
//**************************************************************************
void	CheckBattery(void)
{
	uchar temp=0x01,voltage;
	if(CurrentChannel==LastChannel) return; //-- if been checked - do not check
	LastChannel=CurrentChannel;             //-- indicate current battery tested

 //-- Disable Individual Charge Control --
 temp = temp << CurrentChannel;          //-- Move to Channel Position
	ChargeCtrl |= temp;                     //-- Disable Charge on channel
	
	//-- Enable Discharge control on channel --
	DischargeCtrl |= temp;                  //-- Enable discharge on channel

	//-- Read in the voltage from the port
	voltage=SampleADC(CurrentChannel);      //-- Read battery voltage under load

	//-- Disable the Discharge Control
 temp ^= 0xFF;                           //-- Invert temp
 DischargeCtrl &= temp;                   //-- Disable selected channel
 
 //-- Check and determine what to do with the battery
	if(voltage<CHARGEDVOLTAGE)                         //-- Below Max Charge??
	{
		
	 //-- Currently charging???
		if(ChannelInfo[CurrentChannel].Status != CHARGING)
		{
			//if not then set to charge mode and calculate time required
		 ChannelInfo[CurrentChannel].Status=CHARGING;  //-- Start to charge Battery

		 //-- Calculate Charge Time Required
		 if(voltage < DISCHARGEVOLTAGE)
		 {
			 //-- Give Maximum Time for anything less than DISCHARGEVOLTAGE
    ChannelInfo[CurrentChannel].TimeLeft=255;
		 }
		 else
		 {
			 // 255 / 5hrs = 51 AND 255 - DISCHARGEVOLTAGE = 51
			 // Therefore anything above DISCHARGEVOLTAGE should have a shorter
			 // charge time. For Example:
			 // 4V   = 204 --> 255-204=51 51*5 = 255 --> (255/255)*5hrs = 5.0Hrs
			 // 4.1V = 209 --> 255-209=46 46*5 = 230 --> (230/255)*5hrs = 4.5Hrs
			 // 4.8V = 244 --> 255-244=11 11*5 = 55  --> (55/255) *5hrs = 1.1Hrs
			 //
			 // NOTE: This may not be the correct calculation for charging but will
			 // do for initial trial runs - possible need to scale a bit differently
			 // But with this method - if the battery does not hold the full voltage
			 // then it will recalculate the charge time and give it another go.
			 // To try to stop this the minimum charge time has been set to 1 hour
			 			 
			 ChannelInfo[CurrentChannel].TimeLeft=255-voltage*5; 
			 //-- Set minimum time to 1 hour to ensure charge.
			 if(ChannelInfo[CurrentChannel].TimeLeft < (255/5))
			 {
			  ChannelInfo[CurrentChannel].TimeLeft =255/5;
			 }
			}
		}
		
		//-- Possible Dead Battery ???
		if(voltage<DEADVOLTAGE)
		{
			//-- if yes then indicate so
			ChannelInfo[CurrentChannel].Status=BATTERROR;

			//-- but check if battery not actually there
			if(voltage<NOBATTERYVOLTAGE)
			{
				//-- If no battery detected then indicate so and clear TimeLeft
				ChannelInfo[CurrentChannel].Status=NOBATTERY;  //-- No Battery
				ChannelInfo[CurrentChannel].TimeLeft=0;        //-- No Charge Time
			}
		}
	}
	else
	{
		//-- If Battery above Full then see if charge time still remaining
		//-- Check for Timeout - if so then indicate Full.
		if(ChannelInfo[CurrentChannel].TimeLeft==0)
		{
			ChannelInfo[CurrentChannel].Status=BATTFULL;
		}
	}
	//-- Check if Charge circuit needs to be turned back on
	if(ChannelInfo[CurrentChannel].Status==CHARGING
	   || ChannelInfo[CurrentChannel].Status==BATTERROR)
	{
		//-- if CHARGING or BATTERROR flags showing then attempt charge
		ChargeCtrl &= temp; //-- lower current channels pin
	}
}
//****************** END OF CheckBattery

//**************************************************************************
//CheckButton - Checks if button pressed and selects options
//
// In version 1.00 - will see if button held down for 4 sec min
//  then bring up the discharge option. key must then be released and held 
//  for another 4 seconds to enable discharge cycle (count down given)
//
//  Uses:
//  SecondTick  - as timer (toggles state each second)
//  KeyDown     - as key indicator (updated each second)
//  KEYUP KEYDOWN - to check what state the key is in
//  KEYENTERDELAY - How long to wait to accept Key as Pressed
//  KeyDelayCounter - Counter for above
//  KeySecondState - state of the last second tick
//  
//**************************************************************************
void	CheckButton(void)
{
	
	

}
//****************** END OF CheckButton

//**************************************************************************
// CheckDischarge - Checks Discharge Status flag 
//
// if Discharge Flag indicates that it is time to discharge batterys then
//  starts beeping and displaying message every 4 - 6 seconds for a second
//
// Uses:
//  SecondTick - as timer for showing the display
//  DischargeCounter - as counter for above
//		DischargeSecondState - holds last state of Second Tick
//  DischargeTime - to indicate if its time to discharge
//  DISCHARGESHOW - number of seconds between displaying
//**************************************************************************
void	CheckDischarge(void)
{
	if(DischargeTime)
	{
	 if(DischargeSecondState != SecondTick)
	 {
		 DischargeSecondState=SecondTick;
		 DischargeCounter++;
		 if(DischargeCounter >= DISCHARGESHOW)
   {
	   DischargeCounter=0;
	   Buzzer=BUZZERON;
	   lcd_clear();
	   lcd_puts("TIME TO DISCHARGE");
 	  lcd_goto(LCD_LINE2);
	   lcd_puts("Hold Button 5 sec");
	   Buzzer=BUZZEROFF;                //-- Buzz enough to hear not annoy
	   pause(1);                        //-- Display long enough to read
   }
	 }
	}
}
//****************** END OF CheckDischarge

//**************************************************************************
//CheckChargeTimer - Checks and alters Time counters
//
// Alters the status of the TimeLeft part of the structure.
// The Timeleft variable is in units. Resolution = 51 units/hr
// This leads to 85 Seconds per unit count.
// This monitors the SecondTick for timing
// 
//**************************************************************************
void CheckChargeTimer(void)
{
	char count;
 if(SecondTick != LastUnitSecond)
 {
	 LastUnitSecond=SecondTick;
 	UnitCounter++;
 	if(UnitCounter >= UNITCOUNT)
 	{
	 	UnitCounter=0;
	 	for(count=0;count<MAXCHANNEL;count++)
	 	{
		 	//-- Check if already timed out
		 	if(ChannelInfo[count].TimeLeft !=0)
		 	{
			 	//-- if not then Decrement the count
			 	if(--ChannelInfo[count].TimeLeft==0)
			 	{
				 	//-- If no time left then assume Battery is fully charged
      ChannelInfo[count].Status=BATTFULL;
			 	}
		 	}
	 	}
 	}
 }
}
//****************** END OF CheckChargeTimer

//**************************************************************************
//
//**************************************************************************

//****************** END OF

//**************************************************************************
//
//**************************************************************************

//****************** END OF


//**************************************************************************
//
//**************************************************************************

//****************** END OF

//**************************************************************************
//
//**************************************************************************

//****************** END OF


//**************************************************************************
//
//**************************************************************************

//****************** END OF

//**************************************************************************
//
//**************************************************************************

//****************** END OF






