/*
 *	Serial port driver for 16Cxx chips
 *	using software delays.
 *
 *	Copyright (C)1996 HI-TECH Software.
 *	Freely distubutable.
 */

/*
 *	Tunable parameters
 */

#include	<pic.h>
#include	<conio.h>

/*	Transmit and Receive port bits */

#ifndef SerialPorts
 #define SerialPorts
 static bit	TxData @ (unsigned)&PORTA*8+3;		/* bit3 in port A */
 static bit	RxData @ (unsigned)&PORTA*8+2;		/* bit2 in port A */
 #define	INIT_PORT	TRISA = 7			/* set up I/O direction */
#endif

/*	Xtal frequency */
#ifndef XTAL
 #define	XTAL	4000000
#endif
/*	Baud rate	*/
#ifndef BRATE
 #define	BRATE	9600
#endif

/*	Don't change anything else */

#define	DLY		3		/* cycles per null loop */
#define	TX_OHEAD	13		/* overhead cycles per loop */
#define	RX_OHEAD	12		/* receiver overhead per loop */

#define	DELAY(ohead)	(((XTAL/4/BRATE)-(ohead))/DLY)

//static char RSTIMEOUT;
//static unsigned int RSTimeOut;

void
putch(char c)
{
	unsigned char	dly, bitno;

	bitno = 11;

	INIT_PORT;
	TxData = 0;			/* start bit */
	bitno = 12;
	do {
		dly = DELAY(TX_OHEAD);	/* wait one bit time */
		do
			/* nix */ ;
		while(--dly);
		if(c & 1)
			TxData = 1;
		if(!(c & 1))
			TxData = 0;
		c = (c >> 1) | 0x80;
	} while(--bitno);
}

char
getch(void)
{
	unsigned char	c, bitno, dly;
//	RSTimeOut=0xFFFF;
//	RSTIMEOUT=0;
 for(;;) {
		while(RxData)
 		 continue;
//		{
//			RSTimeOut--;
//			if(RSTimeOut==0)
//			{
//				RSTIMEOUT=1;
//				return(0);
//			}
//		}
//			continue;	/* wait for start bit */
		dly = DELAY(3)/2;
		do
			/* nix */;
		while(--dly);
		if(RxData)
			continue;	/* twas just noise */
		bitno = 8;
		c = 0;
		do {
			dly = DELAY(RX_OHEAD);
			do
				/* nix */;
			while(--dly);
			c = (c >> 1) | (RxData << 7);
		} while(--bitno);
		
#ifdef RSDEBUG
		putch(c);
#endif
	
		return c;
	}
}

char getche(void)
{
	char c;
	c=getch();
	putch(c);
	return(c);
}

			




