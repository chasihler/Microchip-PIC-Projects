//****************************************************************
//                       PWRCTRL2.C
//
// This program is a serial communication between Dallas Temp Probes
// PC and Phase Controler.
//
// This will be used to determine the required calculations and
// code for driving Chris Fergusons Reactor Temperature.
//
// Author: Michael Pearce
//         Electronics Workshop,
//         Chemistry Department, University of Canterbury
//
// Started: 24 July 1998
//
// Updated:
//  6 August 1998 - Version 1.10
//   - Major changes to Serial i/o setup to add checking and soft handshaking
//
//
//****************************************************************
//#define RSDEBUG

#include <pic.h>

#define FALSE 0
#define TRUE  1

//-- Define all things for serial and 1-wire --
#define	XTAL	8000000           //-- For serial
#define	XTAL_FREQ	8MHZ         //-- For delay us

//******* Defines For Both PC and Controler ***********
//-- Valve States --
#define VOFF     10     //-- Valve Off
#define VON      20     //-- Valve ON

//-- Power States --
#define POWERMAX     100  //-- Power Maximum
#define POWEROFF     101  //-- Power off for sending to controller

//-- Communications Stuff --
#define START   'S'               //- The Start character
#define END     'E'               //- The Stop character
#define ACK     'A'               //- The Acknowledge character
#define REPEAT  'T'               //- The repeaT character
#define READ    'R'               //- The Read command Character
#define WRITE   'W'               //- The Write command Character
#define CLRALL  'C'               //- The Clear all command Character
#define PROGRAM 'P'               //- For Programming the Probe address
#define OKTOSEND 'O'              //- PC Looks for this B4 Sending data

//*****************************************************


//-- Delay routine specifically for 8Mhz
#define	DelayUs(x)	{ unsigned char _dcntZ; \
			  _dcntZ =(unsigned char)( (x)/1.5); \
			  while(--_dcntZ != 0) \
				  continue; }


//-- 1-wire Pin setup
#define D_PIN_PORT PORTA       //-- Port A pin 3 For 1-wire Bus
#define D_PIN_NUM 1
#define D_TRIS_PORT TRISA
#define _D_MATCHROM_

//-- Serial Port Set up
#define SerialPorts
static bit	TxData @ (unsigned)&PORTA*8+4;		/* bit4 in port A */
static bit	RxData @ (unsigned)&PORTA*8+3;		/* bit3 in port A */
static bit S_TRIS @ (unsigned)&TRISA*8+4;  // Output Tris Bit
#define	INIT_PORT	S_TRIS = 0		 	/* set up I/O direction */

//-- Include Required header files --
#include "michaels.h"
#include "1wire002.c"
#include "serial.c"

//-- Functions Used
void ReadTemperature(void),SendToPC(void),ReadFromPC(void),SetPower(void);
void SetValve(void),Delay(void);
void RunCommand(void),ClrAll(void),Program(void);

//-- PORT BITS ETC --
static bit ZeroCross @ PORTBIT(PORTB,0);
static bit OFF       @ PORTBIT(PORTB,4);
static bit PLUS      @ PORTBIT(PORTB,1);
static bit VALVEBIT  @ PORTBIT(PORTB,7);
static bit VALVETRIS @ PORTBIT(TRISB,7);


//-- Store the addresses for the 2 Dallas Probes in use
//-- ADDR1 = Inlet Temperature     ADDR2 = Internal Temperature
const char  ADDR1[8]={0x10,0x80,0x9c,0x0e,0x00,0x00,0x00,0x92};
const char  ADDR2[8]={0x10,0x1d,0x8d,0x0e,0x00,0x00,0x00,0xd8};
static unsigned char DATA1[9],DATA2[9];
static char POWER;
static char VALVE;


//**************************************************************************
//main
//**************************************************************************
void main(void)
{
	PORTB=0xFF;       // All outputs HIGH
 TRISB=0xED;       // RB1 and RB4 are outputs. Rest ar inputs
 POWER=0;          // Initial Power setting =0%;
 VALVE=VOFF;          // Initial Valve Setting
 VALVEBIT=1;       // Lower the Output Bit so when toggled it goes low
 VALVETRIS=0;      // High Impedance Mode on Valve Bit

 while(1)
 {
  RunCommand();
 }
}
//****************** END OF main
//**************************************************************************
// RunCommand - Gets instruction from PC and executes it
//**************************************************************************

static char Buffer[11];
void RunCommand(void)
{
 char Command=0,Count=0,CountUp,CheckSum=0;

// putch(OKTOSEND);
 if(getche() == START)   //-- Wait For Start Byte --
 {
	 Command=getche();
  CheckSum+=Command;    //-- The Command is Part of the Checksum
  switch(Command)       //-- Get the number of bytes in the packet
  {
   case CLRALL:
   case READ:
    Count=1;
    break;

   case WRITE:
    Count=3;
    break;

   case PROGRAM:
    Count=10;
    break;

   default:
    Count=0;
    Command=FALSE;
    break;
  }
  for(CountUp=0;CountUp<Count;CountUp++) //-- Read in the Required Data
  {
   Buffer[CountUp]=getche();              //-- Store in a buffer
  }
  if(getche()!=END)                         //-- Check For end Marker
  {
   Command=FALSE;                        //-- If not End marker then ERROR
  }
  
  if(Count > 0)                        //-- If data in the buffer then check it
  {
   //-- Do a checksum of the Data
   for(CountUp=0;CountUp<(Count-1);CountUp++)
   {
    CheckSum+=Buffer[CountUp];         //-- Add all bytes together and then...
   }
   if(CheckSum!=Buffer[Count-1])       //-- ... check with last byte in array
   {
    Command=FALSE;                     //-- If not the same then error Occured
   }
  }
  if(Command == FALSE)                 //-- Check for Error
  {
   putch(REPEAT);                      //-- If Error then get data resent
   return;                             //-- Return and restart Process
  }
  putch(ACK);                          //-- If good data then ACKnowledge it

  switch(Command)                      //-- Process the Data
  {
   case READ:                          //-- READ New Power Settings
    SendToPC();
    break;

   case WRITE:                         //-- Send lastest Temperature to PC
    ReadFromPC();
    break;

   case CLRALL:                        //-- Resets the I/O
    ClrAll();
    break;

   case PROGRAM:                       //-- Programs the Address in EEPROM
    Program();
    break;
  }
 }
}
//****************** END OF RunCommand

//**************************************************************************
// ReadTemperature - Reads two temperature probes
//**************************************************************************
void ReadTemperature(void)
{
 int count;
 D_Reset();           // Reset The Bus
 D_Write(0xCC);       // Skip ROM
 D_Write(0x44);       // Convert T Command

 for(count=0;count<5000;count++)
 {
  DelayUs(100);       // 5000 * 100us = 0.5 seconds
 }

 //-- Read First Device
 D_Reset();           // Reset the Bus Again
 D_MatchRom(ADDR1);
 D_Write(0xBE);      // Read Scratch Pad Command
 for(count=0;count<9;count++)
 {
  DATA1[count]=D_Read();
 }

 //-- Read Second Device
 D_Reset();           // Reset the Bus Again
 D_MatchRom(&ADDR2[0]);
 D_Write(0xBE);      // Read Scratch Pad Command
 for(count=0;count<9;count++)
 {
  DATA2[count]=D_Read();
 }
}
//****************** END OF Read Temperature

//**************************************************************************
// SendToPC - Sends All Data to the PC
//**************************************************************************
void SendToPC(void)
{
 char count,CheckSum=0;
 //-- Read the Latest Temperatures In
 ReadTemperature();

 //-- Indicate Start of Data
 putch(START);

 //-- Send First Probes Data
 for(count=0;count<8;count++)
 {
  putch(DATA1[count]);
  CheckSum+=DATA1[count];
 }

 //-- Send Second probes Data
 for(count=0;count<8;count++)
 {
  putch(DATA2[count]);
  CheckSum+=DATA2[count];
 }

 //-- Send Power and Valve Settings
 putch(POWER);
 CheckSum+=POWER;
 putch(VALVE);
 CheckSum+=VALVE;

 //-- Send the Checksum
 putch(CheckSum);

 //-- Send End of message Character
 putch(END);

}
//****************** END OF SendToPC

//**************************************************************************
//ReadFromPC
//**************************************************************************
void ReadFromPC(void)
{
   POWER=Buffer[0];
   VALVE=Buffer[1];                //-- Get Valve Status
   if(POWER == POWEROFF) POWER=0;  //-- For Serial system that can't handle NULL's
   SetValve();
   SetPower();
}
//****************** END OF ReadFromPC

//**************************************************************************
//SetPower
//**************************************************************************
void SetPower(void)
{
	 char count;

	 //-- Endsure POWER is in range
	 if(POWER > 100) POWER=100;

  //-- Wait for zero cross
  while(ZeroCross==1);
  while(ZeroCross==0);
   //-- Reset Device
  OFF=0;
  DelayUs(40);
  OFF=1;

  //-- Pulse POWER% number of times
  for(count=0;count<POWER;count++)
  {
   DelayUs(36);
   PLUS=0;
   DelayUs(36);
   PLUS=1;
  }
}
//****************** END OF SetPower
//**************************************************************************
// SetValve - Toggles the Valve Acuator
//**************************************************************************
void SetValve(void)
{
	 if(VALVE == VON)
	 {
		 VALVEBIT=0;     //-- only turn valve on if a '1' is present
	 }
	 else
	 {
		 if(VALVE == VOFF)
		 {
		  VALVEBIT=1;     //-- Other wise turn the valve OFF.
		 }
		 //-- Do nothing if not correct value
	 }
}

//**************************************************************************
// Delay
//**************************************************************************
void Delay(void)
{
	int count;
	for(count=0;count<5000;count++)
	{
		DelayUs(100);
	}
}
//****************** END OF Delay

//**************************************************************************
//ClrAll - Turns everything Off
//**************************************************************************
void ClrAll(void)
{
 POWER=0;
 VALVE=VOFF;
 SetValve();
 SetPower();
}
//****************** END OF ClrAll
//**************************************************************************
//Program - Loads in New Address for Probe.
//*************************************************************************
void Program(void)
{
// char *pointer;
 switch(Buffer[0])
 {
  case '1':
//   pointer=ADDR1;          //-- Re-Program Probe Address 1
   break;

  case '2':
//   pointer=ADDR2;          //-- Re-Program Probe Address 2
   break;

  default:
   return;
 }
}
//****************** END OF Program
//**************************************************************************
//
//**************************************************************************


//****************** END OF






