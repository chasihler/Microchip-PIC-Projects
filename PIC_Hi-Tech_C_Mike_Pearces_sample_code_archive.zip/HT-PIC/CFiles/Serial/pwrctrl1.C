//****************************************************************
//                       PWRCTRL1.C
//
// This program is a serial communication between Dallas Temp Probes
// PC and Phase Controler.
//
// This will be used to determine the required calculations and
// code for driving Chris Fergusons Reactor Temperature.
//
// Author: Michael Pearce
//         Electronics Workshop,
//         Chemistry Department, University of Canterbury
//
// Started: 24 July 1998
//
//****************************************************************

#include <pic.h>

//-- Define all things for serial and 1-wire --
#define	XTAL	8000000           //-- For serial
#define	XTAL_FREQ	8MHZ         //-- For delay us

//-- Valve Status Values
#define VON  0xFF
#define VOFF 0x0A

//-- Delay routine specifically for 8Mhz
#define	DelayUs(x)	{ unsigned char _dcntZ; \
			  _dcntZ =(unsigned char)( (x)/1.5); \
			  while(--_dcntZ != 0) \
				  continue; }


//-- 1-wire Pin setup
#define D_PIN_PORT PORTA       //-- Port A pin 3 For 1-wire Bus
#define D_PIN_NUM 1
#define D_TRIS_PORT TRISA
#define _D_MATCHROM_

//-- Serial Port Set up
#define SerialPorts
static bit	TxData @ (unsigned)&PORTA*8+4;		/* bit4 in port A */
static bit	RxData @ (unsigned)&PORTA*8+3;		/* bit3 in port A */
static bit S_TRIS @ (unsigned)&TRISA*8+4;  // Output Tris Bit
#define	INIT_PORT	S_TRIS = 0		 	/* set up I/O direction */

//-- Include Required header files --
#include "michaels.h"
#include "1wire002.c"
#include "serial.c"

//-- Functions Used
void ReadTemperature(void),SendToPC(void),ReadFromPC(void),SetPower(void);
void SetValve(void),Delay(void);

static bit ZeroCross @ PORTBIT(PORTB,0);
static bit OFF       @ PORTBIT(PORTB,4);
static bit PLUS      @ PORTBIT(PORTB,1);
static bit VALVEBIT  @ PORTBIT(PORTB,7);
static bit VALVETRIS @ PORTBIT(TRISB,7);


//-- Store the addresses for the 2 Dallas Probes in use
//-- ADDR1 = Inlet Temperature     ADDR2 = Internal Temperature
const char  ADDR1[8]={0x10,0x80,0x9c,0x0e,0x00,0x00,0x00,0x92};
const char  ADDR2[8]={0x10,0x1d,0x8d,0x0e,0x00,0x00,0x00,0xd8};
static unsigned char DATA1[9],DATA2[9];
static char POWER;
static char VALVE;

//**************************************************************************
//main
//**************************************************************************
void main(void)
{
	PORTB=0xFF;       // All outputs HIGH
 TRISB=0xED;       // RB1 and RB4 are outputs. Rest ar inputs
 POWER=0;          // Initial Power setting =0%;
 VALVE=VOFF;          // Initial Valve Setting
 VALVEBIT=1;       // Lower the Output Bit so when toggled it goes low
 VALVETRIS=0;      // High Impedance Mode on Valve Bit
 
 while(1)
 {
	 SetValve();
  SetPower();
  Delay();
  ReadTemperature();
  SendToPC();
  ReadFromPC();
 }
}
//****************** END OF main

//**************************************************************************
// ReadTemperature - Reads two temperature probes
//**************************************************************************
void ReadTemperature(void)
{
 int count;
 D_Reset();           // Reset The Bus
 D_Write(0xCC);       // Skip ROM
 D_Write(0x44);       // Convert T Command

 for(count=0;count<5000;count++)
 {
  DelayUs(100);       // 5000 * 100us = 0.5 seconds
 }

 //-- Read First Device
 D_Reset();           // Reset the Bus Again
 D_MatchRom(ADDR1);
 D_Write(0xBE);      // Read Scratch Pad Command
 for(count=0;count<9;count++)
 {
  DATA1[count]=D_Read();
 }

 //-- Read Second Device
 D_Reset();           // Reset the Bus Again
 D_MatchRom(&ADDR2[0]);
 D_Write(0xBE);      // Read Scratch Pad Command
 for(count=0;count<9;count++)
 {
  DATA2[count]=D_Read();
 }
}
//****************** END OF Read Temperature

//**************************************************************************
// SendToPC - Sends All Data to the PC
//**************************************************************************
void SendToPC(void)
{
 char count;
 //-- Indicate Start of Data
 putch('S');

 //-- Send First Probes Data
 for(count=0;count<8;count++)
 {
  putch(DATA1[count]);
 }

 //-- Send Second probes Data
 for(count=0;count<8;count++)
 {
  putch(DATA2[count]);
 }

 //-- Send Power and Valve Settings
 putch(POWER);
 putch(VALVE);
 //-- Send End of message Character
 putch('E');

}
//****************** END OF SendToPC

//**************************************************************************
//ReadFromPC
//**************************************************************************
void ReadFromPC(void)
{
	char CheckSum=1,Retry=10;
 while(CheckSum !=0 && (Retry--) >0) //-- Keep Going until timeout or good
 {
  if(getch()=='S')
  {
  	DelayUs(100);
   POWER=getch();            //-- Get Power setting
   VALVE=getch();            //-- Get Valve Status
   CheckSum=getch();
   DelayUs(100);             //-- Give a small gap to allow to end properly
   getch();                  //-- Get last character 'E'
   if(POWER > 100) POWER=0;  //-- For Serial system that can't handle NULL's
  }
  CheckSum-=(POWER+VALVE);   //-- If valid CheckSum then result= zero
  if(CheckSum !=0)
  {
	  putch('R');               //-- Send Repeat Command if invalid checksum
	 }
	 else
	 {
		 putch('O');              //-- Send OK Command if good Checksum
	 }
 } 
}
//****************** END OF ReadFromPC

//**************************************************************************
//SetPower
//**************************************************************************
void SetPower(void)
{
	 char count;

	 //-- Endsure POWER is in range
	 if(POWER > 100) POWER=100;
	 
  //-- Wait for zero cross
  while(ZeroCross==1);
  while(ZeroCross==0);
   //-- Reset Device
  OFF=0;
  DelayUs(40);
  OFF=1;

  //-- Pulse POWER% number of times
  for(count=0;count<POWER;count++)
  {
   DelayUs(36);
   PLUS=0;
   DelayUs(36);
   PLUS=1;
  }
}
//****************** END OF SetPower
//**************************************************************************
// SetValve - Toggles the Valve Acuator
//**************************************************************************
void SetValve(void)
{
	 if(VALVE == VON)
	 {
		 VALVEBIT=0;     //-- only turn valve on if a '1' is present
	 }
	 else
	 {
		 if(VALVE == VOFF)
		 {
		  VALVEBIT=1;     //-- Other wise turn the valve OFF.
		 }
		 //-- Do nothing if not correct value
	 }
}

//**************************************************************************
// Delay
//**************************************************************************
void Delay(void)
{
	int count;
	for(count=0;count<5000;count++)
	{
		DelayUs(100);
	}
}
//****************** END OF Delay

//**************************************************************************
//
//**************************************************************************


//****************** END OF





