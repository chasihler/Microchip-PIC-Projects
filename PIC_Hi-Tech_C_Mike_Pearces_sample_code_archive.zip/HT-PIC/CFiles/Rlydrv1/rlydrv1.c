//***************************************************************************
//                               rlydrv1.c
//
// This program uses a PIC12C50x to drive 4 solid state relays.
// Input is via serial Bus on One Input Pin.
// In Initial Circuit a pin is shared with a Dallas 1-wire system.
// Serial Protocol is RS-232 Based but Positive 5 volt Logic.
// Baud Rate of 2400 Baud is used and 1 data byte sent.
//  Byte arrangement: 
//            MSB aaahdddd LSB
//  Where a=Serial address, h=high/low byte and d=data
//  In case of this device only need one nibble of data for control.
//  The nibble is modified to match ouput pins then output to port.
//
//
// Author: Michael Pearce
//         Electronics Workshop, Chemistry Department
//         University of Canterbury.
//
// Started: 16 November 1998
//
//------------------------------- UPDATES -----------------------------------
//
//
//***************************************************************************

#include <pic.h>

#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))

static bit  RELAY0    @ BITNUM(GPIO, 0);  //- Relay 0
static bit  RELAY1    @ BITNUM(GPIO, 1);  //- Relay 1
static bit  RELAY2    @ BITNUM(GPIO, 2);  //- Relay 2
static bit  RELAY3    @ BITNUM(GPIO, 4);  //- Relay 3
static bit  INPUT0    @ BITNUM(GPIO, 3);  //- Input 0
static bit  INPUT1    @ BITNUM(GPIO, 5);  //- Input 1


void main (void)
{
	char data;
	GPIO = 0xFF;    //-- All pins in High Position (OFF)
	TRIS = 0x28;    //-- Configure pins input/output modes

	while(1)
	{
		//data=getch();          //-- Read data from serial port
		//data=process(data);    //-- Check address and shuffle bits
	 //GPIO=data;             //-- output it to the serial port
	}
	
}








