//--------------------------------------
//             GYMTIME1.C
//
// Repeating Timer For Gym Circuits
// Switchable from 30 sec to 60 sec in 5 sec intervals
//
//  Using HiTech - C Compiler
//
// Author: M.O.Pearce
//
// Started: 13 - October -1998
//--------------------------------------

//-- Pin assignments as follow --

//== OUTPUTS ==
// GP5 - Buzzer Output

//== INPUTS ==
// GP0,1,2,3 - Speed Input (Multiply by 5 and add 30)

//== UN USED ==
// GP4  



#include <pic.h>
#include "delay.h"
#include "delay.c"

#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))

//-- Timer Settings --
//-- Allows 20 to 95sec Range in 5 sec steps --
#define RESOLUTION 5
#define MINCOUNT   20    
#define BuzDly     2


static bit  Buzzer  @ BITNUM(GPIO, 5);  //- Buzzer output Pin
//static bit  BuzzerT @ BITNUM(TRIS, 5);  //- Tris reg for Buzz

unsigned char TimeLoad;

void RunAuto(void),DelaySecond(void),MakeSound(void);

//*****************************************************
//  Main - Start of the program
//*****************************************************
void main (void)
{
 OPTION=0xDF;               //- 
 TRIS = 0xFF;               //- Set all pins to High Impedance
 Buzzer=0;                  //- Buzzer = 0 for initial output mode

 TimeLoad=GPIO;             //- Read Switch Settings
 TimeLoad &= 0x0F;          //- Mask the unused pins out
 TimeLoad *=RESOLUTION;     //- Multiply by Resolution required
 TimeLoad +=MINCOUNT;       //- Add the minumum Delay

 RunAuto();
}
//********** END OF main

//*****************************************************
// RunAuto - Runs the delays
//*****************************************************
void RunAuto(void)
{
	unsigned char count;
	while(1)
	{
		MakeSound();
		for(count=0;count<TimeLoad-BuzDly;count++)
		{
			DelaySecond();
		}
	}
}
//********** END OF RunAuto

//*****************************************************
//DelaySecond
//*****************************************************
void DelaySecond(void)
{
	unsigned char tenth;
	for(tenth=0;tenth<10;tenth++)
	{
		DelayMs(100);
	}
}
//********** END OF DelaySecond

//*****************************************************
//MakeSound
//*****************************************************
void MakeSound(void)
{
	unsigned char BuzzTime,Loop;
	//BuzzerT=0;                  //-Enable Output
	TRIS=0xDF;
 for(Loop=0;Loop<2*BuzDly;Loop++) //- 500mS * 2 * BuzDly = BuzDly Seconds
 {
	 for(BuzzTime=0;BuzzTime<250;BuzzTime++) //- 250 x 2mS = 500mS
	 {
		 Buzzer=0;                //- Low For 1mS
		 DelayMs(1);
		 Buzzer=1;                //- High For 1mS
		 DelayMs(1);              //- Thus 500Hz Buzzer Output
	 } 
 }
// BuzzerT=1;                  //-Disable Output
 TRIS=0xFF;
}
//********** END OF MakeSound

