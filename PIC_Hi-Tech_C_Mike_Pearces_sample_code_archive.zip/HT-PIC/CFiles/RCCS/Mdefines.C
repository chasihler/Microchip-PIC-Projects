//***********************************************************
//                      mdefines.C
//                     Version 1.00
//                 For the RCCS Project
//
// Defines for menus_01.c
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 23 Feburary 1999
//
//************** Version Notes and Bug Fixes ****************
// Version 1.00 - 23021999 - Menu System
//
//***********************************************************


#ifndef TRUE
 #define TRUE 1
#endif

#ifndef FALSE
 #define FALSE 0
#endif

#define KeyAddr   PORTC
#define KeyInPort PORTB

#define KEYDELAY    100           //-- us Delay between addressing and reading

#define LINE1 0         // LCD RAM position for Start of line 1
#define LINE2 0x40      // LCD RAM position for start of line 2
#define DISPLAYLEN 20   // Number of characters the LCD can display
#define MAXSTRING 40    // Maximum width of LCD
#define SCROLLDELAY 85  // Number of delay times between screen scrolls  
#define SCROLLOFF 0     // Does not auto scroll the display
#define SCROLLON  1     // Automatically scrolls the display


#define MAXSPEED 1000        //-- Maximum Controled Motor Speed
#define MINSPEED 100         //-- Minimum Controled Motor Speed
#define MAXTEMPERATURE  90   //-- Maximum Controled Temperature
#define MINTEMPERATURE  40   //-- Minimum Controled Temperature

//*********** KEY CODES **************
#define K0     0x12
#define K1     0x01
#define K2     0x11
#define K3     0x21
#define K4     0x04
#define K5     0x14
#define K6     0x24
#define K7     0x08
#define K8     0x18
#define K9     0x28
#define KSTAR  0x02
#define KHASH  0x22

// --- Key Codes Used for menu Items ---
// --- General ---
#define KHELP  0
#define KENTER '#'
#define KESC   '*'

// --- Main Menu ---
#define KSETUP 1
#define KRUN   2
#define KCLEAN 3

// --- Setup Menu ---
#define KSTIR  1
#define KTEMP  2
#define KPUMP  3
#define KTIME  4
#define KLOG   5
#define KRESET 6

// --- Setup: Stir ---
#define KPUMP1 1
#define KPUMP2 2

// --- Setup: Stir: Pump ---
#define KSTIME 1
#define KTTIME 2
#define KRATE  3

// --- Run Menu ---
#define KSTART      1
#define KDELAYEDRUN 2
#define KMANUALRUN  3
#define KADJUSTTIME 4

// --- Run: Start ---
// --- Run: Total ---
// --- Run: Restart ---

// --- Log Menu ---

// --- RESET Menu ---

// --- Clean Menu ---
// KSTART K1  - predefined


//******************* DEFAULT VALUES FOR VARIABLES *********************

#define RTIMEOUT    0xFF      //-- key code for Timeout occured while running
#define RTIMEOUTDLY 5         //-- Timeout  of 5 seconds if no key pressed
#define DRUNMODE    0         //-- Initially not running
#define DRUNTIME    720       //-- Standard Run Time used (720 min = 12 Hrs)

#define DTARGETTEMPERATURE 80 //-- Target temperature in degrees C

#define DPUMP1START 10        //-- Time from Process START to starting pump
#define DPUMP2START 10
#define DPUMP1TIME  5         //-- How long to keep adding solution
#define DPUMP2TIME  5
#define DPUMP1RATE  30        //-- amount of Strokes/Minute
#define DPUMP2RATE  30

#define DLOGDELAY   0         //-- Delay in sec between logging information
                              //    0 = logging disabled

#define DSTIRRERSPEED 350     //-- Stirrer speed in RPM















