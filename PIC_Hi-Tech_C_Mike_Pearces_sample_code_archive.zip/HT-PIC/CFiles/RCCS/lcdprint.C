//**********************************************************************
//                           lcdprint.c
//                          Version 1.00
//
// Some additional printing and scrolling functions for the LCD.
//
//
//**********************************************************************
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 23 Feburary 1999
//
//************** Version Notes and Bug Fixes ****************
// Version 1.00 - 23021999 - lcd_print, lcd_scroll
//
//***********************************************************
#define SCROLL_LEFT   0
#define SCROLL_RIGHT  1
#define CURSOR_OFF    0
#define CURSOR_ON     1

void lcd_print(char x,const char *s);   //-- prints starting at x
void lcd_scroll(char Direction);         //-- scrolls LCD to left or Right
void lcd_home(void);                    //-- homes the LCD
void lcd_cursor(char onoff);             //-- turns cursor on or off

//*************************************************************************
//lcd_print  -  prints starting at location x
//*************************************************************************
void lcd_print(char x,const char *s)
{
 lcd_goto(x);
 lcd_puts(s);
}
//****************** END OF lcd_print

//*************************************************************************
//lcd_scroll - scrolls LCD to left or Right
//*************************************************************************
void lcd_scroll(char Direction)
{
 LCD_RS=0;     //-- write command
 if(Direction==SCROLL_LEFT)
 {
  lcd_write(0x18);        //- S/C=1 R/L=0   => Scroll LEFT
 }
 else
 {
  lcd_write(0x1b);        //- S/C=1 R/L=1   => Scroll RIGHT
 }
 DelayMs(1);
}
//****************** END OF lcd_scroll

//*************************************************************************
//lcd_home - sends LCD to the Home Position
//*************************************************************************
void lcd_home(void)
{
 LCD_RS=0;                //-- write command
 lcd_write(0x02);         //-- Home Everything
 DelayMs(2);
}
//****************** END OF lcd_home

//*************************************************************************
//lcd_cursor - turns cursor on or off
//*************************************************************************
void lcd_cursor(char onoff)
{
 LCD_RS=0;
 if(onoff==CURSOR_OFF)          //-   0000 1DCB
 {                              //- D= Display C= Cursor B=Blink
  lcd_write(0x0C);              //- D on/off= 1 C on/off=0 B on/off=0
 }
 else
 {
  lcd_write(0x0F);              //- D=1 C=1 B=1   => Cursor ON + Blink
 }
 DelayMs(1);
}
//****************** END OF lcd_cursor





