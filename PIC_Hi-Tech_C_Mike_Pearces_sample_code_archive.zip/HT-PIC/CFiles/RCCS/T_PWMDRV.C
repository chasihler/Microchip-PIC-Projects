//***********************************************************
//                      T_PWMDRV.C
//                     Version 1.00
// 
//       TEST VERSION TO SEE IF PCB FUNCTIONAL
//
// Software to drive UOC-MOTORCTRL-001 using PWM
// Uses 16 bit value for RPM Required.
// Data loaded in via PSP and stored (16 Bit Value).
// Also Data read out is current RPM (16 Bit Value).
// 
// Uses PIC16C64 
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 16 December 1998
//
//************** Version Notes and Bug Fixes ****************
// Version 1.00 - 16121998 - PWM Control of motor 
//
//***********************************************************
//#define DEBUG

#include <pic.h>
#define  XTAL_FREQ 20MHZ
#define  TIMER_0_RELOAD   0xFF - 10   //- 20/4/16/10 = 31250 ...
#define  SECOND_TIME_UP   31250       // ....Interrupts Per Second
#define  MAXPOWER         0xFFFF      //- Turns PWM FULL ON
#define  MAXPOWERSTEP     0x1000      //- Maximum Power Increase size

#define BITNUM(adr, bit)       ((unsigned)(&adr)*8+(bit))
static bit  STALL   @ BITNUM(PORTC, 0);  //- Stall Indicator pin
static bit  TSTALL  @ BITNUM(TRISC, 0);  //- Stall Indicator TRIS
static bit  PWMOUT  @ BITNUM(TRISC, 2);  //- PWM Output pin

static bit  UPIN    @ BITNUM(PORTB, 7);  //-- Faster
static bit  DPIN    @ BITNUM(PORTB, 6);  //-- Slower


unsigned int SpeedCounter=0,SecondCounter=0;
unsigned int CurrentSpeed=1,TargetSpeed=0,TempI;
unsigned char TempC,DataIn,DataOut;


typedef struct
{
 unsigned char L;
 unsigned char H;
}BYTES;

union
{
 unsigned int Word;
 BYTES B;
}POWER;


bit TimeToCheck; //-- Indicates that 1 second is up
bit NewDataIn;   //-- Indicates New data has been read from Master
bit NewDataOut;  //-- Indicates Master has read data in buffer
bit OverflowDataIn;

//***********************************************************
//main
//***********************************************************
void main(void)
{
 //-- Set Up Options --
 OPTION=0x03;   // 0000 0011 - Tmr0 = Internal, Divide by 16.

 POWER.Word=1000;   //-- DEBUG ONLY ###########################
 	
 //-- Set Up Variables --
 TimeToCheck=0;

 TargetSpeed=1000;       //-- DEBUG ONLY ################################

 //-- Set up I/O Ports --
 STALL=0;
 TSTALL=0;
 TRISB=0xFF;  //-- Port B as inputs

 //-- Set Up PWM ---
 PWMOUT=0;           //-- TRIS the PWM pin for output
 CCPR1L=0;           //-- PWM OFF
 CCP1CON=0x0C;       //-- 0000 1100 PWM Mode ON
 T2CON=0x06;         //-- 0000 0100 Tmr2 on Pre = 2     (PWM = 4.88Khz)
 PR2=0xFF;           //-- Longest Period.     
 
  
 //-- Set up PSP --

 //-- Set Up Interrupts --
 INTCON=0;      //-- Turn all Interrupts OFF
 PIE1=0;       //-- Turn other interrupts OFF
// PSPIE=1;    //-- PSP
// INTE=1;     //-- Input interrupt Pin
// T0IE=1;     //-- Timer 0 Interrupt
 //PEIE=1;     //-- Pheripheral Devices
 GIE=1;      //-- Global Interrupt
 

 //-- Main Loop --
 while(1) 
 {
	 if(!UPIN)
	 {
		 if(POWER.Word < (MAXPOWER-10))
		 {
    POWER.Word+=10;
		 }
   while(!UPIN);
	 }
	 if(!DPIN)
	 {
		 if(POWER.Word > 10)
		 {
		  POWER.Word-=10;
		 }
		 while(!DPIN);
	 }
	 
  CCPR1L=POWER.B.H;               //-- Use High Byte as 8 bit Power Value
  TempC=(POWER.B.L >> 2) & 0x30 ; //-- Get High Nibble of Low Byte
  CCP1CON &=0x0f;                 //-- Clear High Res Bits
  CCP1CON |=TempC;                //-- Load Hig Res Bits to Control Register
 }
}
//*********** END OF main

//***********************************************************
//TheInterrupt - Handles all the interrupt procedures
//***********************************************************
interrupt void TheInterrupt(void)
{
 //-- Check for PSP Interrupt --
 if(PSPIF)
 {
  if(IBF)     //-- New Data Arrived - do something with it
  {
	  if(NewDataIn)
	  {
		  OverflowDataIn=1;  //-- Data has not been read from second buffer
 	                     //   so an overflow has occured
	  }
	  else
	  {
		  if(!OverflowDataIn) //-- if overlowed - do not write the data!!
		  {
     NewDataIn=1;    //-- Set New data bit to indicate that New Data has arrived 
     DataIn=PORTD;   //-- Read the data in from the buffer write to secondary buf
		  }
	  }
  }
  else
  {
   if(!OBF)  //-- Data has been read - load the next byte into register
   {
     NewDataOut=1;    //-- Indicate that data has been read from port
     PORTD=DataOut;   //-- Load the next byte to the port
   }
  }
  PSPIF=0;
 }

 //-- Check for External Interrupt for Optical Sensor --
 if(INTF)   //-- Increase the counter
 {
  SpeedCounter++; 
  INTF=0;
 }
 
 //-- Check for Timer0 Overflow for 1 second timer --
 if(T0IF)  //-- 20MHz / 16 / 10 = 31250 counts
 {
  SecondCounter++;
  TMR0=TIMER_0_RELOAD;
  if(SecondCounter >= SECOND_TIME_UP)
  {
   TimeToCheck=1;
  }
  T0IF=0;
 }

 
}

//*********** END OF TheInterrupt

//***********************************************************
//
//***********************************************************

//*********** END OF 

//***********************************************************
//
//***********************************************************

//*********** END OF 

//***********************************************************
//
//***********************************************************

//*********** END OF 

//***********************************************************
//
//***********************************************************

//*********** END OF 

//***********************************************************
//
//***********************************************************

//*********** END OF 




