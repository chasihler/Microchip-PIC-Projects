//***********************************************************
//                      RCCS_LCD.C
//                     Version 1.00
// 
// Software to drive the LCD Control Pannel that interfaces
// with the PC, Temperature Control System, and Motor Drive.
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 4 December 1998
//
//************** Version Notes and Bug Fixes ****************
// Version 1.00 - 04121998 - Basic Control of Motor and LCD
//
//***********************************************************
//#define DEBUG

#include <pic.h>
#define 	XTAL_FREQ 20MHZ

#include <stdlib.h>
#include <stdio.h>
#include "delay.h"
#include "delay.c"
#include "lcd.h"
#include "lcd.c"

#ifdef DEBUG
 char DBG_TempC;
 void putch(char c)
 {
  lcd_write(c);
  DelayMs(1);
 }
#endif


#define KeyAddr   PORTC
#define KeyInPort PORTB

#define KEYDELAY    100           //-- us Delay between addressing and reading

#define LINE1 0       // LCD RAM position for Start of line 1
#define LINE2 40      // LCD RAM position for start of line 2
#define MAXSTRING 22  // Maximum String length

#define SETSPEED 4  // Key Codes for Menu Items
#define RUN      1
#define STOPALL  2
#define CLEAN    3

#define MAXSPEED 1000        //-- Maximum Controled Motor Speed
#define MINSPEED 100         //-- Minimum Controled Motor Speed
#define MAXTEMPERATURE  90   //-- Maximum Controled Temperature
#define MINTEMPERATURE  40   //-- Minimum Controled Temperature

//*********** KEY CODES **************
#define K0     0x12
#define K1     0x01
#define K2     0x11
#define K3     0x21
#define K4     0x04
#define K5     0x14
#define K6     0x24
#define K7     0x08
#define K8     0x18
#define K9     0x28
#define KSTAR  0x02
#define KHASH  0x22



//*********** FUNCTIONS **************
char getch(void),kb_hit(void);
char getche(void);
void gets(char *str,char Num);


void SetTheSpeed(void),SetTheTemperature(void),RunTheProcess(void);
void StopAll(void),CleaningProcess(void);
void pause(unsigned int time);


//************ VARIABLES *************
char temps[MAXSTRING],temp;
char KeyCode,LastKey=0;           //-- Value returned from Keypad 
int  tempi;

unsigned int  TargetSpeed=0,CurrentSpeed=0;

char TargetTemperature=0;

bit RUNNING=0,KbHitFlag=0;


//***********************************************************
//main
//***********************************************************
void main(void)
{
 pause(1);
 //-- Configure Ports
 TRISB=0xF0;          //-- In  from Keypad and output to LCD
 TRISA=0xCF;          //-- LCD Control Lines as output
 TRISC=0xF8;          //-- PC0 to PC2 are outputs to Keypad
 lcd_init();
 
 //-- Opening Display
 lcd_clear();
 lcd_puts("RCCS Firmware V0.00");
 lcd_goto(LINE2);
 lcd_puts("By M.O.Pearce");
 pause(3);

 //-- Main Menu
  
 while(1)
 {
  lcd_clear();
  lcd_goto(LINE2);
  lcd_puts("1SET 2RUN 3STP 4CLN");
 
  if(RUNNING)
  {
	  while(!kb_hit())
	  {
		  lcd_goto(LINE1);
    printf("Motor = %dRPM   ",CurrentSpeed);
    CurrentSpeed++;
    DelayMs(100);
	  }
  }
  else
  {
	  lcd_goto(LINE1);
   lcd_puts("Motor Stopped. ");
  }
  switch(getch())
  {
   case '1':
    SetTheSpeed();                  //-- Configure the motor Speed
    break;

   case '2':
    RunTheProcess();                //-- Start the Motor Running
    break;

   case '4':
    CleaningProcess();              //-- Run the cleaning cycles
    break;

   case '3':
    StopAll();                      //-- Stop The Motor
    break;

   default:
    lcd_goto(LINE2);
    lcd_puts("Unknown Command!");
   // beep(2);
    pause(1);
    break;
  }
 }
}
//************ END OF main

//***********************************************************
//SetTheSpeed - Set the Motor Speed
//***********************************************************
void SetTheSpeed(void)
{
 lcd_clear();
 lcd_puts("Enter Target RPM:");
 lcd_goto(LINE2);
 gets(temps,4);                        //-- Max of 4 digits
 tempi=atoi(temps);
 pause(1);
 if(tempi > MAXSPEED)
 {
  tempi=MAXSPEED;
 }
 else
 {
  if(tempi < MINSPEED)
  {
   if(tempi >0)
   {
    tempi=MINSPEED;
   }
  }
 }
 TargetSpeed=tempi; 
}
//************ END OFSetTheSpeed

//***********************************************************
//RunTheProcess - Runs the Motor 
//***********************************************************
void RunTheProcess(void)
{
 //-- Upload Target Speed to Motor Control
 
 //-- Allow the devices to run by lowering the ENABLE lines
 
 //-- Tell user that are Running the Process
 lcd_clear();
 lcd_puts("Running Process..");
 RUNNING=1;
 pause(1);
}
//************ END OF RunTheProcess

//***********************************************************
//StopAll - Stops All Outputs - Motor and Heater
//***********************************************************
void StopAll(void)
{
  lcd_goto(LINE2);
  lcd_puts("Stopping All...");
  RUNNING=0;
  //-- Set ENABLE lines High and Disable both Controllers
  pause(2);  //-- wait 2 seconds for things to stop
}
//************ END OF StopAll

//***********************************************************
//CleaningProcess - Runs Motor etc for cleaning
//***********************************************************
void CleaningProcess(void)
{
 lcd_clear();
 lcd_puts("Cleaning Cycle");
 //-- Heater to OFF --
 //-- Motor to MAX SPEED --
 //-- Wait for user to stop
 //-- Stop the motor
 pause(2);

}
//************ END OF CleaningProcess

//***********************************************************
//getche - gets the key pressed with echo
//***********************************************************
char getche(void)
{
	char gtempc;
	gtempc=getch();
	putch(gtempc);
	return(gtempc);
}

//***********************************************************
//getch - gets the key pressed
//***********************************************************
char getch(void)
{
	 if(KbHitFlag==0)
	 {
	  while(!kb_hit());    //-- Wait for a key to be pressed
	 }
	 KbHitFlag=0;          //-- Indicate that Key has been read!!!
#ifdef DEBUG
	 lcd_clear();              //-- clear the display
	 lcd_puts("DEBUG: Key = ");
	 DBG_TempC= ((KeyCode & 0xF0) >> 4) +'0';
  putch(DBG_TempC);
  DBG_TempC=(KeyCode &0x0F) + '0';
  putch(DBG_TempC) ;
	 pause(3);                 //-- Display it for 3 seconds
	 lcd_clear();
#endif
 switch(KeyCode)            //-- convert to usable characters
 {
	 case K0:
	  KeyCode='0';
	  break;

	 case K1:
	  KeyCode='1';
	  break;

	 case K2:
	  KeyCode='2';
	  break;

	 case K3:
	  KeyCode='3';
	  break;

	 case K4:
	  KeyCode='4';
	  break;

	 case K5:
	  KeyCode='5';
	  break;

	 case K6:
	  KeyCode='6';
	  break;

	 case K7:
	  KeyCode='7';
	  break;

	 case K8:
	  KeyCode='8';
	  break;

	 case K9:
	  KeyCode='9';
	  break;

	 case KSTAR:
	  KeyCode='*';
	  break;

	 case KHASH:
	  KeyCode='#';
	  break;

	 default:
	  KeyCode=0;
 }
	return(KeyCode);
}
//************ END OF getch();

//***********************************************************
//pause - Delays in seconds
//***********************************************************
void pause(unsigned int time)
{
	char QS;
 do
 {
	 for(QS=4;QS>0;QS--)
	 {
		 DelayMs(250);
	 }
 }while(--time);
}
//************ END OF  

//***********************************************************
//kbhit - Scans the keyboard  - returns 1 if key pressed
//***********************************************************
char kb_hit(void)
{
	unsigned char line,data,result=0;
	KbHitFlag=0;
	for(line=0;line <8;line++)
	{
		KeyAddr=line;      //-- Set Row To Read
		DelayUs(KEYDELAY);
		data = KeyInPort;  //-- Read in the data
		data = data >> 4;  //-- shift to lower nibble
		data	|= 0xF0;      //-- set upper nibble to 1s
		data ^= 0xFF;      //-- invert everything (XOR)
		if(data !=0)
		{
			result=line<<4;   //-- Put line number in upper nibble
			result+=data;     //-- Put Row Bit pattern in lower nibble
			line=10;          //-- Terminate the loop
		}
	}
 DelayUs(KEYDELAY);  //-- We Bit More Delay
 KeyCode=result;
 if(result==0 || LastKey==result) //-- if null or last key not released
 {
	  LastKey=result;
	  return(0);     //-- Return "No Key Hit"
 }
 LastKey=result;
 KbHitFlag=1;     //-- Indicate to getch that key already hit
 return(1);       //-- Return "Key Was Hit
}
//************ END OF kbhit


//***********************************************************
//gets - get string - limit of Num Characters
//***********************************************************
void gets(char *str,char Num)
{
	char count=0,gtc;
 while(count < Num)
 {
	 gtc=getche();
	 switch(gtc)
	 {
		 case '#':           //-- ENTER OPTION
		  temps[count]=0;
		  count=Num;
		  break;

		 case '*':           //-- CANCEL OPTION
		  temps[0]=0;        //-- delete the string
		  count=Num;
		  break;

		 default:
		  temps[count]=gtc;
	   count++;
	 }
 }
 temps[count]=0;
}
//************ END OF gets

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  

//***********************************************************
//
//***********************************************************

//************ END OF  




