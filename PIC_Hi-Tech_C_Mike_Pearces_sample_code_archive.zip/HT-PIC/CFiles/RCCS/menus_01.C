//***********************************************************
//                      menus_01.C
//                     Version 1.00
//                 For the RCCS Project
//
// This is the Master control Software that interfaces with
// the LCD, and Keypad to get information from the user to
// control the stirrer motor speed, temperature control system,
// monomer pumps and Serial Logging.
//
//
// Author: Michael Pearce
//         Chemistry Department, University of Canterbury
//
// Started: 23 Feburary 1999
//
//************** Version Notes and Bug Fixes ****************
// Version 1.00 - 23021999 - Menu System
//
//***********************************************************

#include <pic.h>
#define 	XTAL_FREQ 20MHZ

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "delay.h"
#include "delay.c"
#include "lcd.h"
#include "lcd.c"

#include "mdefines.c"
#include "lcdprint.c"

//********************* GLOBAL VARIABLES *********************
char SecondCount=0,MinuteCount=0,HourCount=0;
bit  RunMode=FALSE,ExitToRun=FALSE,ScrollDivider=0,InRunDisplay=FALSE;
bit  CoolMode=FALSE;
int  RunTime;
char TargetTemp;
int  Pump1Start;
int  Pump2Start;
int  Pump1Time;
int  Pump2Time;
char Pump1Rate;
char Pump2Rate;
char LogDelay;
int  StirSpeed;
char KeyHit;
char IntStr[6]; //String used to print from within the interrupt

//--------- Actual Value Variables -------
char RemainHours=9,RemainMinutes=7,RemainSeconds=0;
int  CurrentStirSpeed=1234;
char CurrentTemperature=81;
char CurrentPumpA=12;
char CurrentPumpB=15;
bit ShowTick=FALSE;                //-- Tells when to update display

//----------------------------------------

char RTimeOutDelay=RTIMEOUTDLY;
bit  KbHitFlag;
char KeyCode,LastKey=0;

//**************** FUNCTIONS ******************
void SetDefaults(void);
void InitComms(void),InitStirrer(void),InitHeater(void),InitPumps(void);

void pause(char dly);
char GetItem(char x,char Scrolling);
unsigned int GetData(const char *s,char num,unsigned int OldData);
char kb_hit(void),getch(void);
char mstrlen(const char *s);


void ShowCooling(void);
void ShowRunning(void);
void MenuMain(void),MenuSetup(void),MenuRun(void),MenuClean(void);

//*************************************************************************
//main
//*************************************************************************
void main(void)
{
 OPTION=0x00;

 //-- Configure Interrupts --
 GIE=0;
 INTE=1; //-- Enable External INT pin (1 second counter).

 //-- Configure Ports --
 TRISB=0xF0;  //-- Input from Keypad, output to LCD
 TRISA=0xCF;  //-- LCD Control Lines as output
 TRISC=0xF8;  //-- PC0 to PC2 are outputs to Keypad
 
 //-- Initialise All internal and external systems
 lcd_init();
 lcd_clear();
 lcd_print(LINE1,"INITIALISING:");
 pause(1);
 lcd_goto(LINE2);
 InitComms();                     //-- Init all comms between all devices
 InitStirrer();                   //-- Init Stirrer Controller
 InitHeater();                    //-- Init Heater Controller
 InitPumps();                     //-- Init Pump Timers etc

 lcd_cursor(CURSOR_OFF);
 //-- Opening Display --
 lcd_clear();
 lcd_print(LINE1,"RCCS System Firmware");
 lcd_print(LINE2,"Ver 1.00  M.O.Pearce");
 pause(1);

 SetDefaults();         //-- Set global variables to default values

 //###################### DEBUG #################
 INTE=0;
 PEIE=1;    //-- enable peripherial Interrupts - i.e. enable the timer
 TMR1IE=1;  //-- enable timer interrupt
 GIE=1;     //-- enable global interrupt
 TMR1CS=0;  //-- timer into internal mode
 T1CKPS1=1; //-- Set prescaler to 8
 T1CKPS0=1; //  this sets interrupt to around 0.1 Seconds
 TMR1ON=1;  //-- turn timer on
 

 //##############################################
 //--- Main Loop ---
 while(1)
 {
  if(RunMode)
  {
   ShowRunning();
   RunMode=0; //-- Ensure Run Mode is Stopped
  }
  else
  {
	  if(CoolMode)
	  {
    //-- Cool the reactor System down to complete process --
    ShowCooling();
    CoolMode=0; //-- Ensure Cool Mode is Stopped
	  }
	  else
	  {
    MenuMain();
	  }
  }
 }
}
//****************** END OF main

//*************************************************************************
// SysInterrupt - Services all the system interrupts
//*************************************************************************
void interrupt SysInterrupt(void)
{
 //-- One Second Interrupt --
// if(INTF)
// {
//	 INTF=0;
 if(TMR1IF)
 {
	 TMR1IF=0;    //-- Use Timer 1 overflow to get here
	 if(RunMode)
	 {
		 ShowTick=1;
 	 //-- Increase Timer if Running --
		 SecondCount++;
		 if(SecondCount==60)
		 {
			 SecondCount=0;
			 MinuteCount++;
			 if(MinuteCount==60)
			 {
				 MinuteCount=0;
				 HourCount++;
			 }
		 }
		 //-- Decrement Timer if in Run Mode --
		 RemainSeconds--;
		 if(RemainSeconds==0xFF)
		 {
			 RemainSeconds=59;
			 RemainMinutes--;
			 if(RemainMinutes==0xFF)
			 {
				 RemainMinutes=59;
				 RemainHours--;
				 if(RemainHours>=0xFE)
				 {
					 RemainHours=0;
					 RemainMinutes=0;
					 RemainSeconds=0;
					 RunMode=FALSE;          //-- If Hours Rolled around then Run has 
					 CoolMode=TRUE;          //-- finished - It's time to cool things down!
					 ExitToRun=1;            //-- Force drop out from text menus etc
				 }
			 }
		 }
		 //-- Get Current Speed and Temperature --
		 CurrentStirSpeed=0;
		 CurrentTemperature=18;
		 CurrentPumpA=0;
		 CurrentPumpB=0; 

		 //-- Do Required Pump Actions --
		 
		 //-- Check Timeouts etc --

		 //-- Update the Display --
		}
 }
 //-- Serial Interrupt --
}

//****************** END OF SysInterrupt


//*************************************************************************
// SetDefaults - sets the default values of the global variables
//*************************************************************************
void SetDefaults(void)
{
	ExitToRun=FALSE;
 RunMode=DRUNMODE;
 RunTime=DRUNTIME;

 TargetTemp=DTARGETTEMPERATURE;

 Pump1Start=DPUMP1START;
 Pump2Start=DPUMP2START;
 Pump1Time=DPUMP1TIME;
 Pump2Time=DPUMP2TIME;
 Pump1Rate=DPUMP1RATE;
 Pump2Rate=DPUMP2RATE;

 LogDelay=DLOGDELAY;

 StirSpeed=DSTIRRERSPEED;

}
//****************** END OF SetDefaults

//*************************************************************************
//MenuMain
//*************************************************************************
void MenuMain(void)
{
	char NotDone=TRUE;
	while(NotDone)
	{
  lcd_clear();
  lcd_print(LINE1,"MAIN MENU");
  lcd_print(LINE2,"1-Setup 2-Run 3-Wash");
  switch( GetItem(3,SCROLLOFF) )
  {
   case KSETUP:
    MenuSetup();
    break;

   case KRUN:
    MenuRun();
    break;

   case KCLEAN:
    MenuClean();
    break;

   case KESC:
   case RTIMEOUT:
    NotDone=FALSE;
    break;

   default:
    break;
  }
  if(ExitToRun) NotDone=FALSE;
	}
}
//****************** END OF MenuMain

//*************************************************************************
//MenuSetup
//*************************************************************************
void MenuSetup(void)
{
 char NotDone=TRUE;
 while(NotDone)
 {
  lcd_clear();
  lcd_print(LINE1,"SETUP:");
  lcd_print(LINE1+20,"SETUP:");
  lcd_print(LINE2,"1-Stir 2-Temp 3-Pump 4-Time 5-Log 6-Rst");
  switch(GetItem(6,SCROLLON))
  {
   case KSTIR:
    lcd_print(LINE1+7,"Stirrer");
    StirSpeed=GetData("TARGET",4,StirSpeed);
    break;

   case KTEMP:
    lcd_print(LINE1+7,"Temperature");
    TargetTemp=(char)GetData("TARGET",2,TargetTemp);
    break;

   case KPUMP:
    //MenuPump();
    break;

   case KTIME:
    lcd_print(LINE1+7,"Time");
    RunTime=GetData("Run Time",4,RunTime);
    RemainHours=(char)(RunTime/60);
    RemainMinutes=(char)(RunTime-(int)(RemainHours*60));
    RemainSeconds=59;    
    break;

   case KLOG:
    lcd_print(LINE1+7,"Log");
    LogDelay=GetData("Time",4,LogDelay);
    break;

   case KRESET:
    lcd_print(LINE1+7,"RESETTING");
    SetDefaults();
    pause(1);
    break;

   case KESC:
    NotDone=FALSE;
    break;

   case RTIMEOUT:
    //-- If system running and key not been hit for a while then force return
    //   to the RUNNING display.
    NotDone=FALSE;
    break;

   default:
    break;
  }
  if(ExitToRun) NotDone=FALSE;
 }
}
//****************** END OF MenuSetup
//*************************************************************************
//MenuRun
//*************************************************************************
void MenuRun(void)
{
 char NotDone=TRUE;
 while(NotDone)
 {
  lcd_clear();
  lcd_print(LINE1,"RUN:");
  lcd_print(LINE1+20,"RUN:");
  lcd_print(LINE2,"1-Start 2-Delay 3-Manual 4-Adjust Time");
  switch(GetItem(4,SCROLLON))
  {
   case KSTART:
    RunMode=TRUE;
    ExitToRun=TRUE;
    break;

   case KDELAYEDRUN:
    break;

   case KMANUALRUN:
    //MenuPump();
    break;

   case KADJUSTTIME:
    break;

   case KESC:
    NotDone=FALSE;
    break;

   case RTIMEOUT:
    //-- If system running and key not been hit for a while then force return
    //   to the RUNNING display.
    NotDone=FALSE;
    break;

   default:
    break;
  }
  if(ExitToRun) NotDone=FALSE;
 }
}
//****************** END OF MenuRun


//*************************************************************************
//ShowRunning - Displays Current information about the Run
//*************************************************************************
void ShowRunning(void)
{
 char NotDone=TRUE;
	ExitToRun=FALSE;        //-- Got here so cancel the order
 //-- Configure Initial Values and send to drivers --

 //-- Loop til All done or user Esc
 while(NotDone)
 {
	 lcd_clear();
  lcd_print(LINE1,"RPM:____ TEMP:__._\xDF\C");
  lcd_print(LINE2,"PA__._ PB__._  __:__");
  InRunDisplay=1;
  ShowTick=1;
  switch(GetItem(3,SCROLLOFF))
  {
   case KENTER:
    InRunDisplay=0;
    MenuMain();
    ExitToRun=FALSE;
    break;

   case KESC:
    InRunDisplay=0;
    lcd_clear();
    lcd_print(LINE1,"STOP THE RUN??");
    lcd_print(LINE2,"1-YES 2-NO");
    if(GetItem(2,SCROLLOFF)==1)
    {
     RunMode=FALSE;
     NotDone=FALSE;
    }
    break;

   default:
    break;
  }
  InRunDisplay=0;    
  if(RunMode==0) NotDone=FALSE; //-- If Runmode finished then Exit
  if(ExitToRun)ExitToRun=0;     //-- Dont ga any further back since r here
 }
}
//****************** END OF ShowRunning

//*************************************************************************
//Show Cooling - Does Quit cooling of the reactor
//*************************************************************************
void ShowCooling(void)
{
 //-- Configure Initial Values and send to drivers --

 //-- Loop til All done or user Esc
 while(CoolMode)
 {
	 lcd_clear();
  lcd_print(LINE1,"Cooling Reactor...");
  lcd_print(LINE2,"Temperature = xx.x\xDF\C");
  
  switch(GetItem(3,SCROLLOFF))
  {
   case KENTER:
    break;

   case KESC:
    lcd_clear();
    lcd_print(LINE1,"STOP COOLING??");
    lcd_print(LINE2,"1-YES 2-NO");
    if(GetItem(2,SCROLLOFF)==1)
    {
     CoolMode=FALSE;
    }
    break;

   default:
    break;
  }
 }
}
//****************** END OF Show Cooling



//*************************************************************************
//MenuClean - Gives the cleaning options
//*************************************************************************
void MenuClean(void)
{
	lcd_clear();
	lcd_print(LINE1,"Washing Time!!");
	lcd_print(LINE2,"1-Flush 2-Spin");
	pause(2);

}
//****************** END OF MenuClean

//*************************************************************************
//InitComms - Sets up all the communication paths between this controller
//            and Serial/Motor Drive/Heater Control etc.
//*************************************************************************
void InitComms(void)
{

 lcd_puts("COMS-");
 DelayMs(250);
}
//****************** END OF InitComms

//*************************************************************************
//InitStirrer - communicates with motor control and sets speed to zero
//*************************************************************************
void InitStirrer(void)
{

 lcd_puts("STIR-");
 DelayMs(250);
}
//****************** END OF InitStirrer

//*************************************************************************
//InitHeater - Communicates with Heateer control and sets output to zero
//*************************************************************************
void InitHeater(void)
{

 lcd_puts("HEAT-");
 DelayMs(250);
}
//****************** END OF InitHeater

//*************************************************************************
// InitPumps - Inits Timer etc used to generate the pump pulses
//*************************************************************************
void InitPumps(void)
{

 lcd_puts("PUMPS");
 DelayMs(250);
}
//****************** END OF InitPumps

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
// Scans the keyboard for a Key to be hit then released
//*************************************************************************
bit CheckKey(void)
{
	if(kb_hit())
	{
		KeyHit=getch();
		return(1);
	}
	return(0);
}
//****************** END OF CheckKey

//*************************************************************************
//GetData - reads in and converts number from user
//*************************************************************************
unsigned int GetData(const char *s,char num,unsigned int OldData)
{
 unsigned char Left,NotDone=TRUE,tempc,temps[6]="",count=0;
 unsigned	int Result;

	Left=LINE2+1+mstrlen(s);      //-- starting position for cursor (after the '>')
	sprintf(temps,"%u  ",OldData);  //-- Convert number to character display
	
	lcd_cursor(CURSOR_ON);        //-- Turn Cursor on 
	lcd_home();                   //-- Set to home position and Normalise display
	
// lcd_print(LINE2,"DEBUG:");
// printf("Left=%u   ",Left);
// getch();
 
	lcd_print(LINE2,s);             //-- display the input type title
	putch('>');                     //-- separate title from data
	//-- Print the current Number
	puts(temps);                    //-- display number
	lcd_puts("                  ");//-- blank rest of display

	//-- Set cursor at start of number
 lcd_goto(Left);
	
 //-- read in the number - of specified length.
 while(NotDone)
 {
	 tempc=getch();
	 switch(tempc)
	 {
		 case KESC:
		  NotDone=FALSE;
		  Result=OldData;
		  break;

		 default:
		  if(count<num)         //-- If not finished the line then display and record
		  {
 		  putch(tempc+'0');
 		  temps[count]=tempc+'0';
 	// temps[count+1]=0;   //-- do not terminate cause want to keep rest intact
 		  count++;
 		  break;
		  }                   //-- if data full then data is complete!! so ENTER it.

		 case KENTER:
		  NotDone=FALSE;
		  Result=atoi(temps);
		  break;
	 }
 }
 lcd_cursor(CURSOR_OFF);
	return(Result);
}
//****************** END OF GetData

//*************************************************************************
//pause
//*************************************************************************
void pause(char dly)
{
	while(dly>0)
	{
		dly--;
		DelayMs(249);
		DelayMs(249);
		DelayMs(249);
		DelayMs(249);
	}
}
//****************** END OF pause

//*************************************************************************
//GetItem - Gets user input - returns if in range 1-x - also scrolls
//*************************************************************************
char GetItem(char x,char Scrolling)
{
 char count=0xFF,NotDone=1;
 while(NotDone)
 {
  //-- Check the Keyboard and process the required data --
  if(CheckKey())
  {
   switch(KeyHit)
   {
	   case 0:
	    lcd_clear();
	    lcd_print(LINE1,"HELP:");
	    lcd_print(LINE2,"*=ESC #=ENTER 0=HELP");
	    pause(4);
     NotDone=FALSE;
     break;

	   case KESC:
	   case KENTER:
	    return(KeyHit);

    default:
     if(KeyHit <=x)
     {
	     return(KeyHit);
     }
   }
   if(KeyHit == KESC)
   {
    return(KESC);
   }
   if(KeyHit == KENTER)
   {
    return(KENTER);
   }
  }
  //-- If scrolling is ON then Scroll the Data --
  if(Scrolling==SCROLLON)
  {
	  if(ScrollDivider==1)  //-- Divide the rate by two
	  {
		  ScrollDivider=0;
    if( --count < 1)
    {
     count=SCROLLDELAY;
     lcd_scroll(SCROLL_LEFT);
    }
	  }
	  else
	  {
		  ScrollDivider=1;
	  }
  }
  //-- Check if in the "Run Display" if so then display current Information
  if(InRunDisplay && ShowTick)
  {
	  ShowTick=0;
   //  lcd_print(LINE1,"RPM:____ TEMP:__._\xDF\C");
   //  lcd_print(LINE2,"PA__._ PB__._  __:__");

   sprintf(IntStr,"%04u",CurrentStirSpeed);
   lcd_print(LINE1+4,IntStr);
// lcd_goto(LINE1+4);
// printf("%04u",CurrentStirSpeed);
 
   sprintf(IntStr,"%02u",CurrentTemperature);
   lcd_print(LINE1+14,IntStr);
//  lcd_goto(LINE1+14);
//  printf("%02u",CurrentTemperature);
  
   sprintf(IntStr,"%02u",CurrentPumpA);
   lcd_print(LINE2+2,IntStr);

   sprintf(IntStr,"%02u",CurrentPumpB);
   lcd_print(LINE2+9,IntStr);

   sprintf(IntStr,"%02u:%02u",RemainHours,RemainMinutes);
   lcd_print(LINE2+15,IntStr);
  }
  //-- If quick exit to run menu required then do so --
  if(ExitToRun) NotDone=FALSE;
 }
 return(0);
}
//****************** END OF GetItem

//***********************************************************
//kbhit - Scans the keyboard  - returns 1 if key pressed
//***********************************************************
char kb_hit(void)
{
	unsigned char line,data,result=0;
	KbHitFlag=0;
	for(line=0;line <8;line++)
	{
		KeyAddr=line;      //-- Set Row To Read
		DelayUs(KEYDELAY);
		data = KeyInPort;  //-- Read in the data
		data = data >> 4;  //-- shift to lower nibble
		data	|= 0xF0;      //-- set upper nibble to 1s
		data ^= 0xFF;      //-- invert everything (XOR)
		if(data !=0)
		{
			result=line<<4;   //-- Put line number in upper nibble
			result+=data;     //-- Put Row Bit pattern in lower nibble
			line=10;          //-- Terminate the loop
		}
	}
 DelayUs(KEYDELAY);  //-- We Bit More Delay
 KeyCode=result;
 if(result==0 || LastKey==result) //-- if null or last key not released
 {
	  LastKey=result;
	  return(0);     //-- Return "No Key Hit"
 }
 RTimeOutDelay=RTIMEOUTDLY;   //-- Reset Timeout delay if key was hit
 LastKey=result;
 KbHitFlag=1;     //-- Indicate to getch that key already hit
 return(1);       //-- Return - Key Was Hit
}
//************ END OF kbhit
//***********************************************************
//getch - gets the key pressed
//***********************************************************
char getch(void)
{
	 if(KbHitFlag==0)
	 {
	  while(!kb_hit());    //-- Wait for a key to be pressed
	 }
	 KbHitFlag=0;          //-- Indicate that Key has been read!!!
#ifdef DEBUG
	 lcd_clear();              //-- clear the display
	 lcd_puts("DEBUG: Key = ");
	 DBG_TempC= ((KeyCode & 0xF0) >> 4) +'0';
  putch(DBG_TempC);
  DBG_TempC=(KeyCode &0x0F) + '0';
  putch(DBG_TempC) ;
	 pause(3);                 //-- Display it for 3 seconds
	 lcd_clear();
#endif
 switch(KeyCode)            //-- convert to usable characters
 {
	 case K0:
	  KeyCode=0;
	  break;

	 case K1:
	  KeyCode=1;
	  break;

	 case K2:
	  KeyCode=2;
	  break;

	 case K3:
	  KeyCode=3;
	  break;

	 case K4:
	  KeyCode=4;
	  break;

	 case K5:
	  KeyCode=5;
	  break;

	 case K6:
	  KeyCode=6;
	  break;

	 case K7:
	  KeyCode=7;
	  break;

	 case K8:
	  KeyCode=8;
	  break;

	 case K9:
	  KeyCode=9;
	  break;

	 case KSTAR:
	  KeyCode='*';
	  break;

	 case KHASH:
	  KeyCode='#';
	  break;

	 default:
	  KeyCode=0;
 }
	return(KeyCode);
}
//************ END OF getch();

//*************************************************************************
//mstrlen
//*************************************************************************
char mstrlen(const char *s)
{
	char count=0;
	while(*s++)count++;
	return(count);
}
//****************** END OF mstrlen

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF

//*************************************************************************
//
//*************************************************************************


//****************** END OF








