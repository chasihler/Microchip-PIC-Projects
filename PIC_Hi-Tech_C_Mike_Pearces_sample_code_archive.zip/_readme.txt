Hi,

This sample Hi-Tech C code was supplied by Mike Pearce, of the University of
Canterbury, New Zealand. He is an excellent programmer for PIC micros, and
manages to make them do things that I barely thought were possible. This archive
gives you a window into the way he does his code, and perhaps you can learn a
few tricks from him :) Enjoy!

Archive contains sample projects in Hi-Tech C for:

* Battery Charger for 8 Ni-Cad battery packs
* Disco Light Driver For the PIC12C50x
* Repeating Timer For Gym Circuits, switchable from 30 sec to 60 sec in 5 sec intervals
* Program for using a PIC16C64 to control the heating/cooling for the PVC Reactor
* Software to replace logic driving the Liquid Nitrogen Filler system, uses PIC12C508
* Motor control software to drive UOC-MOTORCTRL-001 using PWM.
* A program for the PIC12C50x to drive 4 solid state relays, uses RS232 and Dallas 1-wire system.
* Program is a serial communication between Dallas Temp Probes PC and Phase Controler.
* Basic code that turns the 16F84 into a EEPROM to get things up and running.

Low-level routines in Hi-Tech C for:

* Delays
* Bit-level interface to EEPROM
* Dallas 1-wire interface
* Interfacing to LCD module
* Bit-level interface to I2C

Regards,
Shane.

PICuWEB - program PIC micros with C
Lots of sample code, FAQ, tips, tricks, and more.
http://www.workingtex.com/htpic